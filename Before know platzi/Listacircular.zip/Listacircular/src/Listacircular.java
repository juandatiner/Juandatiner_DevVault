
import Nodo.Nodo;



public class Listacircular {

    private Nodo inicio;
    private Nodo ultimo;
    private int tamano;
    
    public Listacircular(){
        inicio= null;
        ultimo= null;
        tamano= 0;
    }
    
    public void agregar(int valor){
        Nodo nuevo = new Nodo();
        nuevo.setValor(valor);
        if(inicio == null){
            inicio = nuevo;
            ultimo = nuevo;
            nuevo.setSiguiente(inicio);
        } else {
            ultimo.setSiguiente(nuevo);
            nuevo.setSiguiente(inicio);
            ultimo = nuevo;
        }
        tamano++;
    }
    
    public void imprimir(){
        if(inicio != null){
            Nodo actual = inicio;
            do{
                System.out.print(actual.getValor() + " ");
                actual = actual.getSiguiente();
            } while(actual != inicio);
            System.out.println();
        }
    }
    
    public void ordenarLista(){
        Nodo actual = inicio, siguiente = null;
        int temp;
        if (inicio == null) {
            return;
        }
        do {
            siguiente = actual.getSiguiente();
            while(siguiente != inicio) {
                if(actual.getValor() > siguiente.getValor()) {
                    temp = actual.getValor();
                    actual.setValor(siguiente.getValor());
                    siguiente.setValor(temp);
                }
                siguiente = siguiente.getSiguiente();
            }
            actual = actual.getSiguiente();
        } while(actual != inicio);
    }



public static void main(String[] args) {
    Listacircular lista = new Listacircular();
    lista.agregar(10);
    lista.agregar(5);
    lista.agregar(20);
    lista.agregar(3);
    lista.agregar(15);
    System.out.println("Lista original:");
    lista.imprimir();
    lista.ordenarLista();
    System.out.println("Lista ordenada:");
    lista.imprimir();

}
}

