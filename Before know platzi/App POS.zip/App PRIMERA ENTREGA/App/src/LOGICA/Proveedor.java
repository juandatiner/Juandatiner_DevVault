package LOGICA; // Se define el paquete al que pertenece la clase

import java.sql.CallableStatement; // Se importa CallableStatement para ejecutar procedimientos almacenados
import DATOS.Conexion; // Se importa la clase Conexion del paquete DATOS
import java.sql.Connection; // Se importa Connection para establecer la conexión con la base de datos
import java.sql.ResultSet; // Se importa ResultSet para procesar los resultados de las consultas SQL
import java.sql.SQLException; // Se importa SQLException para manejar excepciones relacionadas con SQL
import javax.swing.JOptionPane; // Se importa JOptionPane para mostrar mensajes al usuario
import javax.swing.table.DefaultTableModel; // Se importa DefaultTableModel para manejar los datos de una tabla

public class Proveedor {
    
    Conexion enlace = new Conexion(); // Se crea una instancia de la clase Conexion
    Connection connect = enlace.conectar(); // Se establece la conexión con la base de datos y se asigna a la variable connect
    
    // Método para ingresar un nuevo proveedor en la base de datos
    public void IngresarProveedor(int IdentificacionProveedor, String EmpresaProveedor, String DireccionProveedor, String TelefonoProveedor, String EmailProveedor) { 

        try (CallableStatement ingresar = connect.prepareCall("{call InsertarProveedor(?, ?, ?, ?, ?)}")) { 

            ingresar.setInt(1, IdentificacionProveedor); 
            ingresar.setString(2, EmpresaProveedor); 
            ingresar.setString(3, DireccionProveedor); 
            ingresar.setString(4, TelefonoProveedor); 
            ingresar.setString(5, EmailProveedor); 

            ingresar.execute(); // Se ejecuta el procedimiento
            JOptionPane.showMessageDialog(null, "Proveedor ingresado correctamente"); // Se muestra un mensaje de éxito al usuario

        } catch(SQLException e){ // Se captura cualquier excepción SQL
            // Si ocurre un error al ingresar el proveedor
            if (e.getSQLState().equals("23000") && e.getErrorCode()==1062) {
                // Si el error es por clave duplicada, se muestra un mensaje de advertencia
                Object enunciado = "Ya existe un Proveedor con Identificación: "+ IdentificacionProveedor; // Se define el mensaje de advertencia
                JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia al usuario
            } else {
                // Si ocurre otro tipo de error, se muestra un mensaje de advertencia
                Object enunciado = "No se logró ingresar al Proveedor"; // Se define el mensaje de advertencia
                JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia al usuario
            }
            
        }   

    }
    
    // Método para mostrar todos los proveedores en una tabla
    public void MostrarProveedores(String datosProveedor [], DefaultTableModel tablaProveedor) { 

        try (CallableStatement mostrar = connect.prepareCall("{call MostrarProveedores()}")) { 

            ResultSet resultado = mostrar.executeQuery(); 

            while(resultado.next()) { // Se itera sobre cada fila del resultado

                // Se obtienen los datos de cada columna y se asignan al arreglo datosProveedor
                datosProveedor [0] = resultado.getString(1); 
                datosProveedor [1] = resultado.getString(2); 
                datosProveedor [2] = resultado.getString(3); 
                datosProveedor [3] = resultado.getString(4);
                datosProveedor [4] = resultado.getString(5); 
                datosProveedor [5] = resultado.getString(6); 
                tablaProveedor.addRow(datosProveedor); // Se agrega una nueva fila a la tabla con los datos del proveedor

            }

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null," Revise su conexión y vuelva a intentar"); // Se muestra un mensaje de error al usuario
        } 
    }
    
    // Método para actualizar los datos de un proveedor en la base de datos
    public void ActualizarProveedor(int pIdProveedor, String pEmpresa, String pDireccion, String pTelefono, String pCorreoElectronico, String pObservaciones) { 

        try (CallableStatement actualizar = connect.prepareCall("{call EditarProveedor(?, ?, ?, ?, ?, ?)}")) { 
            
            actualizar.setInt(1, pIdProveedor);
            actualizar.setString(2, pEmpresa); 
            actualizar.setString(3, pDireccion); 
            actualizar.setString(4, pTelefono); 
            actualizar.setString(5, pCorreoElectronico);
            actualizar.setString(6, pObservaciones);

            actualizar.execute(); // Se ejecuta el procedimiento
            ResultSet resultSet = actualizar.getResultSet(); // Se obtiene el resultado del procedimiento
            if (resultSet.next()) { // Si hay un resultado disponible
                String mensaje = resultSet.getString("Mensaje"); // Se obtiene el mensaje del resultado
                JOptionPane.showMessageDialog(null, mensaje); // Se muestra el mensaje al usuario
            }

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null," Error al actualizar el Proveedor"); // Se muestra un mensaje de error al usuario
        } 
    }
    
    // Método para eliminar un proveedor de la base de datos
    public void EliminarProveedor(String valor) { 

        try (CallableStatement eliminar = connect.prepareCall("{call EliminarProveedor(?)}")) { 

            eliminar.setString(1,valor); // Se establece el parámetro del procedimiento

            eliminar.executeUpdate(); // Se ejecuta el procedimiento
            JOptionPane.showMessageDialog(null," Proveedor Eliminado correctamente"); // Se muestra un mensaje de éxito al usuario

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null, e + " No se logró eliminar el Proveedor"); // Se muestra un mensaje de error al usuario
        } 
    }
}

