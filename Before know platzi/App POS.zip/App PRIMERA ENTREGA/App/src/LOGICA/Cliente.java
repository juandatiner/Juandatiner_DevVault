
package LOGICA; // Se define el paquete LOGICA

import java.sql.CallableStatement; // Se importa CallableStatement para ejecutar procedimientos almacenados
import DATOS.Conexion; // Se importa la clase Conexion del paquete DATOS
import java.sql.Connection; // Se importa Connection para establecer la conexión con la base de datos
import java.sql.ResultSet; // Se importa ResultSet para procesar los resultados de las consultas SQL
import java.sql.SQLException; // Se importa SQLException para manejar excepciones relacionadas con SQL
import javax.swing.JOptionPane; // Se importa JOptionPane para mostrar mensajes al usuario
import javax.swing.table.DefaultTableModel; // Se importa DefaultTableModel para manejar los datos de una tabla

public class Cliente { // Se define la clase Cliente

    Conexion enlace = new Conexion(); // Se crea una instancia de la clase Conexion
    Connection connect = enlace.conectar(); // Se establece la conexión con la base de datos y se asigna a la variable connect

    public void IngresarCliente(int DocumentoCliente, String NombreCliente, String EmailCliente, String DireccionCliente, String CelularCliente) { // Se define el método IngresarCliente

        try (CallableStatement ingresar = connect.prepareCall("{call InsertarCliente(?, ?, ?, ?, ?)}")) { // Se prepara la llamada al procedimiento almacenado InsertarCliente

            ingresar.setInt(1, DocumentoCliente); // Se establece el primer parámetro (DocumentoCliente) del procedimiento
            ingresar.setString(2, NombreCliente); // Se establece el segundo parámetro (NombreCliente) del procedimiento
            ingresar.setString(3, EmailCliente); // Se establece el tercer parámetro (EmailCliente) del procedimiento
            ingresar.setString(4, DireccionCliente); // Se establece el cuarto parámetro (DireccionCliente) del procedimiento
            ingresar.setString(5, CelularCliente); // Se establece el quinto parámetro (CelularCliente) del procedimiento

            ingresar.execute(); // Se ejecuta el procedimiento
            JOptionPane.showMessageDialog(null, "Cliente ingresado correctamente"); // Se muestra un mensaje de éxito al usuario

        } catch(SQLException e){ // Se captura cualquier excepción SQL
            if (e.getSQLState().equals("23000") && e.getErrorCode()==1062) {
                Object enunciado = "Ya existe un Cliente con el Documento: "+DocumentoCliente; // Se define el mensaje de advertencia
                JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia al usuario
            }else{
                Object enunciado = "No se logró ingresar al Cliente"; // Se define el mensaje de advertencia
                JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia al usuario
            }
            
        }   

    }

    public void MostrarClientes(String datosCliente [], DefaultTableModel tablaCliente) { // Se define el método MostrarClientes

        try (CallableStatement mostrar = connect.prepareCall("{call MostrarClientes()}")) { // Se prepara la llamada al procedimiento almacenado MostrarClientes

            ResultSet resultado = mostrar.executeQuery(); // Se ejecuta el procedimiento y se obtiene el resultado

            while(resultado.next()) { // Se itera sobre cada fila del resultado

                datosCliente [0] = resultado.getString(1); // Se obtiene el valor de la primera columna y se asigna al primer elemento del arreglo datos
                datosCliente [1] = resultado.getString(2); // Se obtiene el valor de la segunda columna y se asigna al segundo elemento del arreglo datos
                datosCliente [2] = resultado.getString(3); // Se obtiene el valor de la tercera columna y se asigna al tercer elemento del arreglo datos
                datosCliente [3] = resultado.getString(4); // Se obtiene el valor de la cuarta columna y se asigna al cuarto elemento del arreglo datos
                datosCliente [4] = resultado.getString(5); // Se obtiene el valor de la quinta columna y se asigna al quinto elemento del arreglo datos
                datosCliente [5] = resultado.getString(6); // Se obtiene el valor de la sexta columna y se asigna al sexto elemento del arreglo datos
                tablaCliente.addRow(datosCliente); // Se agrega una fila a la tabla con los valores obtenidos

            }

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null," Revise su conexión y vuelva a intentar"); // Se muestra un mensaje de error al usuario
        } 
    }

    public void ActualizarCliente(int pDocumento, String pNombre, String pCorreoElectronico, String pDireccion, String pCelular) { // Se define el método ActualizarCliente

        try (CallableStatement actualizar = connect.prepareCall("{call EditarCliente(?, ?, ?, ?, ?)}")) { // Se prepara la llamada al procedimiento almacenado EditarCliente

            actualizar.setInt(1, pDocumento); // Se establece el primer parámetro (pDocumento) del procedimiento
            actualizar.setString(2, pNombre); // Se establece el segundo parámetro (pNombre) del procedimiento
            actualizar.setString(3, pCorreoElectronico); // Se establece el tercer parámetro (pCorreoElectronico) del procedimiento
            actualizar.setString(4, pDireccion); // Se establece el cuarto parámetro (pDireccion) del procedimiento
            actualizar.setString(5, pCelular); // Se establece el quinto parámetro (pCelular) del procedimiento

            actualizar.execute(); // Se ejecuta el procedimiento
            ResultSet resultSet = actualizar.getResultSet(); // Se obtiene el resultado del procedimiento
            if (resultSet.next()) { // Si hay un resultado disponible
                String mensaje = resultSet.getString("Mensaje"); // Se obtiene el mensaje del resultado
                JOptionPane.showMessageDialog(null, mensaje); // Se muestra el mensaje al usuario
            }

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null," Error al actualizar el Cliente"); // Se muestra un mensaje de error al usuario
        } 
    }

    public void EliminarCliente(String valor) { // Se define el método EliminarCliente

        try (CallableStatement eliminar = connect.prepareCall("{call EliminarCliente(?)}")) { // Se prepara la llamada al procedimiento almacenado EliminarCliente

            eliminar.setString(1,valor); // Se establece el parámetro del procedimiento

            eliminar.executeUpdate(); // Se ejecuta el procedimiento
            JOptionPane.showMessageDialog(null," Cliente Eliminado correctamente"); // Se muestra un mensaje de éxito al usuario

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null, e + " No se logró eliminar el Cliente"); // Se muestra un mensaje de error al usuario
        } 
    }
}