
package LOGICA; // Se define el paquete al que pertenece la clase

import java.sql.CallableStatement; // Se importa CallableStatement para ejecutar procedimientos almacenados
import DATOS.Conexion; // Se importa la clase Conexion del paquete DATOS
import java.sql.Connection; // Se importa Connection para establecer la conexión con la base de datos
import java.sql.ResultSet; // Se importa ResultSet para procesar los resultados de las consultas SQL
import java.sql.SQLException; // Se importa SQLException para manejar excepciones relacionadas con SQL
import javax.swing.JOptionPane; // Se importa JOptionPane para mostrar mensajes al usuario
import javax.swing.table.DefaultTableModel; // Se importa DefaultTableModel para manejar los datos de una tabla

public class Empleado {
    
    Conexion enlace = new Conexion(); // Se crea una instancia de la clase Conexion
    Connection connect = enlace.conectar(); // Se establece la conexión con la base de datos y se asigna a la variable connect
    
    // Método para ingresar un nuevo empleado en la base de datos
    public void IngresarEmpleado(int IdentificacionEmpleado, String NombreEmpleado, String CargoEmpleado, double SalarioEmpleado, String EmailEmpleado, String DireccionEmpleado, String CelularEmpleado){
        
        try (CallableStatement ingresar = connect.prepareCall("{call InsertarEmpleado(?, ?, ?, ?, ?, ?, ?)}")) { 

            ingresar.setInt(1, IdentificacionEmpleado); 
            ingresar.setString(2, NombreEmpleado); 
            ingresar.setString(3, CargoEmpleado); 
            ingresar.setDouble(4, SalarioEmpleado); 
            ingresar.setString(5, EmailEmpleado);
            ingresar.setString(6, DireccionEmpleado);
            ingresar.setString(7, CelularEmpleado);

            ingresar.execute(); // Se ejecuta el procedimiento
            JOptionPane.showMessageDialog(null, "Empleado ingresado correctamente"); // Se muestra un mensaje de éxito al usuario

        } catch(SQLException e){ // Se captura cualquier excepción SQL
            // Si ocurre un error al ingresar el empleado
            if (e.getSQLState().equals("23000") && e.getErrorCode()==1062) {
                // Si el error es por clave duplicada, se muestra un mensaje de advertencia
                Object enunciado = "Ya existe un Empleado con la Identificación: "+IdentificacionEmpleado; // Se define el mensaje de advertencia
                JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia al usuario
            } else {
                // Si ocurre otro tipo de error, se muestra un mensaje de advertencia
                Object enunciado = "No se logró ingresar al Empleado"; // Se define el mensaje de advertencia
                JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia al usuario
            }
        }
    }
    
    // Método para mostrar todos los empleados en una tabla
    public void MostrarEmpleados(String datosEmpleado [], DefaultTableModel tablaEmpleado) { 

        try (CallableStatement mostrar = connect.prepareCall("{call MostrarEmpleados()}")) { 

            ResultSet resultado = mostrar.executeQuery(); // Se ejecuta el procedimiento y se obtiene el resultado

            while(resultado.next()) { // Se itera sobre cada fila del resultado

                // Se obtienen los datos de cada columna y se asignan al arreglo datosEmpleado
                datosEmpleado [0] = resultado.getString(1); 
                datosEmpleado [1] = resultado.getString(2); 
                datosEmpleado [2] = resultado.getString(3); 
                datosEmpleado [3] = resultado.getString(4); 
                datosEmpleado [4] = resultado.getString(5); 
                datosEmpleado [5] = resultado.getString(6);
                datosEmpleado [6] = resultado.getString(7);
                datosEmpleado [7] = resultado.getString(8);
                datosEmpleado [8] = resultado.getString(10);
                
                // Se agrega una nueva fila a la tabla con los datos del empleado
                tablaEmpleado.addRow(datosEmpleado); 

            }

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null," Revise su conexión y vuelva a intentar"); // Se muestra un mensaje de error al usuario
        } 
    }
    
    // Método para actualizar los datos de un empleado en la base de datos
    public void ActualizarEmpleado(int pIdentificacion, String pNombre, String pCargo, double pSalario, String pCorreoElectronico, String pDireccion, String pCelular) { 

        try (CallableStatement actualizar = connect.prepareCall("{call EditarEmpleado(?, ?, ?, ?, ?, ?, ?)}")) { 

            actualizar.setInt(1, pIdentificacion); 
            actualizar.setString(2, pNombre); 
            actualizar.setString(3, pCargo); 
            actualizar.setDouble(4, pSalario); 
            actualizar.setString(5, pCorreoElectronico);
            actualizar.setString(6, pDireccion);
            actualizar.setString(7, pCelular);

            actualizar.execute(); // Se ejecuta el procedimiento
            ResultSet resultSet = actualizar.getResultSet(); // Se obtiene el resultado del procedimiento
            if (resultSet.next()) { // Si hay un resultado disponible
                String mensaje = resultSet.getString("Mensaje"); // Se obtiene el mensaje del resultado
                JOptionPane.showMessageDialog(null, mensaje); // Se muestra el mensaje al usuario
            }

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null," Error al actualizar al empleado"); // Se muestra un mensaje de error al usuario
        } 
    }
    
    // Método para eliminar un empleado de la base de datos
    public void EliminarEmpleado(String valor) { 

        try (CallableStatement eliminar = connect.prepareCall("{call EliminarEmpleado(?)}")) { 

            eliminar.setString(1,valor); 

            eliminar.executeUpdate(); // Se ejecuta el procedimiento
            JOptionPane.showMessageDialog(null," Empleado Eliminado correctamente"); // Se muestra un mensaje de éxito al usuario

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null, e + " No se logró eliminar el Empleado"); // Se muestra un mensaje de error al usuario
        } 
    }
            
}