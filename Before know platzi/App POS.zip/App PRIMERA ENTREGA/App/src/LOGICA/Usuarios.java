package LOGICA; // Se define el paquete al que pertenece la clase

import java.sql.CallableStatement; // Se importa CallableStatement para ejecutar procedimientos almacenados
import DATOS.Conexion; // Se importa la clase Conexion del paquete DATOS
import java.sql.Connection; // Se importa Connection para establecer la conexión con la base de datos
import java.sql.ResultSet; // Se importa ResultSet para procesar los resultados de las consultas SQL
import java.sql.SQLException; // Se importa SQLException para manejar excepciones relacionadas con SQL
import javax.swing.JOptionPane; // Se importa JOptionPane para mostrar mensajes al usuario
import javax.swing.table.DefaultTableModel; // Se importa DefaultTableModel para manejar los datos de una tabla

public class Usuarios {
    
    Conexion enlace = new Conexion(); // Se crea una instancia de la clase Conexion
    Connection connect = enlace.conectar(); // Se establece la conexión con la base de datos y se asigna a la variable connect   
    
    // Método para ingresar un nuevo usuario en la base de datos
    public void IngresarUsuarios(String Usuario, String Contraseña, boolean PermisoClientes, 
            boolean PermisoEmpleados, boolean PermisoVentas, boolean PermisoCompras, 
            boolean PermisoInventario, boolean PermisoFinanzas, boolean PermisoProveedores, boolean PermisoMetodos) { 

        try (CallableStatement ingresar = connect.prepareCall("{call InsertarUsuario(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) { 

            // Se establecen los parámetros del procedimiento
            ingresar.setString(1, Usuario); 
            ingresar.setString(2, Contraseña);
            ingresar.setBoolean(3, PermisoClientes);
            ingresar.setBoolean(4, PermisoEmpleados);
            ingresar.setBoolean(5, PermisoVentas);
            ingresar.setBoolean(6, PermisoCompras);
            ingresar.setBoolean(7, PermisoInventario);
            ingresar.setBoolean(8, PermisoFinanzas);
            ingresar.setBoolean(9, PermisoProveedores);
            ingresar.setBoolean(10, PermisoMetodos);

            ingresar.execute(); // Se ejecuta el procedimiento
            JOptionPane.showMessageDialog(null, "Usuario ingresado correctamente"); // Se muestra un mensaje de éxito al usuario

        } catch(SQLException e){ // Se captura cualquier excepción SQL
            if (e.getSQLState().equals("23000") && e.getErrorCode()==1062) {
                // Si el error es por clave duplicada, se muestra un mensaje de advertencia
                Object enunciado = "Ya existe el Usuario : "+ Usuario; // Se define el mensaje de advertencia
                JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia al usuario
            }else{
                // Si ocurre otro tipo de error, se muestra un mensaje de advertencia
                Object enunciado = "No se logró ingresar el Usuario"; // Se define el mensaje de advertencia
                JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia al usuario
            }  
        }   
    }
    
    // Método para mostrar todos los usuarios en una tabla
    public void MostrarUsuarios(String datosUsuario [], boolean permisosUsuario[], DefaultTableModel tablaUsuario) { 

        try (CallableStatement mostrar = connect.prepareCall("{call MostrarUsuarios()}")) { 

            ResultSet resultado = mostrar.executeQuery(); 

            while(resultado.next()) { // Se itera sobre cada fila del resultado

                // Se obtienen los datos de cada columna y se asignan al arreglo datosUsuario
                datosUsuario [0] = resultado.getString(1); 
                datosUsuario [1] = resultado.getString(2); 
                datosUsuario [2] = resultado.getString(3);
                permisosUsuario [0] = resultado.getBoolean(4); 
                permisosUsuario [1] = resultado.getBoolean(5); 
                permisosUsuario [2] = resultado.getBoolean(6); 
                permisosUsuario [3] = resultado.getBoolean(7); 
                permisosUsuario [4] = resultado.getBoolean(8); 
                permisosUsuario [5] = resultado.getBoolean(9); 
                permisosUsuario [6] = resultado.getBoolean(10); 
                permisosUsuario [7] = resultado.getBoolean(11); 
                tablaUsuario.addRow(datosUsuario); // Se agrega una nueva fila a la tabla con los datos del usuario

            }

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null," Revise su conexión y vuelva a intentar"); // Se muestra un mensaje de error al usuario
        } 
    }
    
    // Método para actualizar los datos de un usuario en la base de datos
    public void ActualizarUsuario(int pIdUsuario, String pUsuario, String pHash, boolean pPermisoClientes, 
            boolean pPermisoEmpleados, boolean pPermisoVentas, boolean pPermisoCompras, boolean pPermisoInventario, 
            boolean pPermisoFinanzas, boolean pPermisoProveedores, boolean pPermisoMetodos) { 

        try (CallableStatement actualizar = connect.prepareCall("{call EditarUsuario(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) { 
            
            // Se establecen los parámetros del procedimiento
            actualizar.setInt(1, pIdUsuario);
            actualizar.setString(2, pUsuario); 
            actualizar.setString(3, pHash);
            actualizar.setBoolean(4, pPermisoClientes);
            actualizar.setBoolean(5, pPermisoEmpleados);
            actualizar.setBoolean(6, pPermisoVentas);
            actualizar.setBoolean(7, pPermisoCompras);
            actualizar.setBoolean(8, pPermisoInventario);
            actualizar.setBoolean(9, pPermisoFinanzas);
            actualizar.setBoolean(10, pPermisoProveedores);
            actualizar.setBoolean(11, pPermisoMetodos);
            

            actualizar.execute(); // Se ejecuta el procedimiento
            ResultSet resultSet = actualizar.getResultSet(); // Se obtiene el resultado del procedimiento
            if (resultSet.next()) { // Si hay un resultado disponible
                String mensaje = resultSet.getString("Mensaje"); // Se obtiene el mensaje del resultado
                JOptionPane.showMessageDialog(null, mensaje); // Se muestra el mensaje al usuario
            }

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null," Error al actualizar el Usuario"); // Se muestra un mensaje de error al usuario
        } 
    }
    
    // Método para eliminar un usuario de la base de datos
    public void EliminarUsuario(String valor) { 

        try (CallableStatement eliminar = connect.prepareCall("{call EliminarUsuario(?)}")) { 

            eliminar.setString(1,valor); // Se establece el parámetro del procedimiento

            eliminar.executeUpdate(); // Se ejecuta el procedimiento
            JOptionPane.showMessageDialog(null," Usuario Eliminado correctamente"); // Se muestra un mensaje de éxito al usuario

        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null, e + " No se logró eliminar el Usuario"); // Se muestra un mensaje de error al usuario
        } 
    }
    
}