
package INTERFAZ;

import DATOS.Conexion;
import LOGICA.Usuarios;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;



public class LOGIN extends javax.swing.JFrame {
//import com.twilio.Twilio;
//import com.twilio.rest.verify.v2.service.Verification;
//
//public class Example {
//  // Find your Account Sid and Token at twilio.com/console
//  public static final String ACCOUNT_SID = "AC12ff2aa5ee73848c798ba40860828dd4";
//  public static final String AUTH_TOKEN = "2790ddf09434e3f8d2f7485ecad1bc36";
//
//  public static void main(String[] args) {
//    Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
//    Verification verification = Verification.creator(
//            "VA79c99dada01b4fe7dc2db8ad09190c0b",
//            "+573057495562",
//            "sms")
//        .create();
//
//    System.out.println(verification.getSid());
//  }
//}
  
    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar();
    Usuarios usuarios = new Usuarios();   
    
    public LOGIN() {
        initComponents();
    }

    public void Limpiar(){
        usuarioInicio.setText("Ingrese su nombre de usuario");
        usuarioInicio.setForeground(Color.gray);
        contraseñaInicio.setText("************");
        contraseñaInicio.setForeground(Color.gray);
    }
    
    public void Credenciales(String Usuario, String Hash){
        try(PreparedStatement statement = connect.prepareStatement("SELECT Hash FROM Usuario WHERE Usuario = ?")) {
            // Consulta SQL para recuperar la contraseña del usuario proporcionado           
            
            statement.setString(1, Usuario);

            // Ejecutar la consulta y obtener el resultado
            ResultSet resultado = statement.executeQuery();

            // Verificar si se encontró el usuario en la base de datos
            if (resultado.next()) {
                // Obtener la contraseña almacenada en la base de datos
                String hashAlmacenado = resultado.getString("Hash");

                // Comparar la contraseña proporcionada con la almacenada
                if (Hash.equals(hashAlmacenado)) {                                       
                    this.setVisible(false);
                    Permisos(Usuario);
                } else {
                    Object enunciado = "Contraseña Incorrecta";
                    JOptionPane.showMessageDialog(null, enunciado , "Error",JOptionPane.ERROR_MESSAGE);
                }
            } else {
                Object enunciado = "Usuario No encontrado";
                JOptionPane.showMessageDialog(null, enunciado , "Error",JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null, e + " No se logró acceder a las credenciales"); // Se muestra un mensaje de error al usuario
        } 
    }
    
    
    public void Permisos (String Usuario){
        
        
        try(PreparedStatement statement = connect.prepareStatement("SELECT PermisoClientes, PermisoEmpleados, PermisoVentas, "
                + "PermisoCompras, PermisoInventario, PermisoFinanzas, PermisoProveedores, PermisoMetodos FROM Usuario WHERE Usuario = ?")) {
            // Consulta SQL para recuperar los permisos del usuario proporcionado           
            
            statement.setString(1, Usuario);

            // Ejecutar la consulta y obtener el resultado
            ResultSet resultado = statement.executeQuery();

            // Verificar si se encontró el usuario en la base de datos
            if (resultado.next()) {
                // Obtener los permisos almacenados en la base de datos
                
                boolean Clientes = resultado.getBoolean("PermisoClientes");
                boolean Empleados = resultado.getBoolean("PermisoEmpleados");
                boolean Ventas = resultado.getBoolean("PermisoVentas");
                boolean Compras = resultado.getBoolean("PermisoCompras");
                boolean Inventario = resultado.getBoolean("PermisoInventario");
                boolean Finanzas = resultado.getBoolean("PermisoFinanzas");
                boolean Proveedores = resultado.getBoolean("PermisoProveedores");
                boolean Metodos = resultado.getBoolean("PermisoMetodos");
                
                Inicio home = new Inicio();
                home.setVisible(true);
                home.btnClientes.setVisible(Clientes);
                home.btnEmpleados.setVisible(Empleados);
                home.btnVentas.setVisible(Ventas);
                home.btnCompras.setVisible(Compras);
                home.btnInventario.setVisible(Inventario);
                home.btnFinanzas.setVisible(Finanzas);
                home.btnProveedores.setVisible(Proveedores);
                home.btnMetodosPago.setVisible(Metodos);     
                home.btnUsuarios.setVisible(false);
                // Comparar los permisos proporcionados con los almacenados
                
            } else {
                Object enunciado = "Error";
                JOptionPane.showMessageDialog(null, enunciado , "Error",JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) { // Se captura cualquier excepción SQL
            JOptionPane.showMessageDialog(null, e + " No se logró acceder a los permisos"); // Se muestra un mensaje de error al usuario
        } 
    }
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        usuarioInicio = new javax.swing.JTextField();
        contraseñaInicio = new javax.swing.JPasswordField();
        botonIngresarLogin = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel1.setText("Contraseña");

        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel2.setText("INICIAR SESIÓN");

        jLabel3.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel3.setText("Usuario");

        usuarioInicio.setForeground(java.awt.Color.gray);
        usuarioInicio.setText("Ingrese su nombre de usuario");
        usuarioInicio.setBorder(null);
        usuarioInicio.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                usuarioInicioFocusGained(evt);
            }
        });
        usuarioInicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                usuarioInicioMousePressed(evt);
            }
        });
        usuarioInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuarioInicioActionPerformed(evt);
            }
        });

        contraseñaInicio.setForeground(java.awt.Color.gray);
        contraseñaInicio.setText("************");
        contraseñaInicio.setBorder(null);
        contraseñaInicio.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                contraseñaInicioFocusGained(evt);
            }
        });
        contraseñaInicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                contraseñaInicioMousePressed(evt);
            }
        });

        botonIngresarLogin.setBackground(new java.awt.Color(0, 153, 204));
        botonIngresarLogin.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonIngresarLogin.setForeground(new java.awt.Color(255, 255, 255));
        botonIngresarLogin.setText("INGRESAR");
        botonIngresarLogin.setBorder(null);
        botonIngresarLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonIngresarLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonIngresarLoginActionPerformed(evt);
            }
        });
        botonIngresarLogin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                botonIngresarLoginKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botonIngresarLoginKeyReleased(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/logo bolso (1).jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(botonIngresarLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)
                        .addComponent(jLabel3)
                        .addComponent(jLabel1)
                        .addComponent(contraseñaInicio)
                        .addComponent(usuarioInicio, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 337, Short.MAX_VALUE)
                        .addComponent(jSeparator2)))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77)
                .addComponent(jLabel2)
                .addGap(70, 70, 70)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(usuarioInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(contraseñaInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(botonIngresarLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/fondo finanzas.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel5)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void botonIngresarLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonIngresarLoginActionPerformed

   
    if (usuarioInicio.getText().equals("admin") && String.valueOf(contraseñaInicio.getPassword()).equals("999")) {
        Inicio home = new Inicio();
        home.setVisible(true);
        this.setVisible(false);
    }else{
        try {
       String Usuario = usuarioInicio.getText();
       String Hash = String.valueOf(contraseñaInicio.getPassword());
        if (Usuario.equals("") || Hash.equals("")) {
            Object enunciado = "Ingrese todos los campos";
            JOptionPane.showMessageDialog(null, enunciado , "Error",JOptionPane.ERROR_MESSAGE);
            Limpiar();
        }else{
            Credenciales(Usuario, Hash);
            Limpiar();
        }      
        
        }catch(Exception e){
        
            Object enunciado = "Vuelva a intentarlo";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
            Limpiar();
    }
    }
        
    
    
    
//    else if (usuarioInicio.getText().equals()) {
//        Inicio home = new Inicio();            
//        home.setVisible(true);
//        home.btnClientes.setVisible(false);
//        home.btnEmpleados.setVisible(false);
//        home.btnVentas.setVisible(false);
//        home.btnCompras.setVisible(false);
//        home.btnInventario.setVisible(false);
//        home.btnFinanzas.setVisible(false);
//        home.btnProveedores.setVisible(false);
//        home.btnMetodosPago.setVisible(false);
//        this.setVisible(false);
//
//    }
//    
    
    }//GEN-LAST:event_botonIngresarLoginActionPerformed

    private void botonIngresarLoginKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonIngresarLoginKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
            botonIngresarLogin.doClick();
        }
    }//GEN-LAST:event_botonIngresarLoginKeyPressed

    private void botonIngresarLoginKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonIngresarLoginKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_botonIngresarLoginKeyReleased

    private void usuarioInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuarioInicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usuarioInicioActionPerformed

    private void usuarioInicioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usuarioInicioMousePressed
        if (this.usuarioInicio.getText().equals("Ingrese su nombre de usuario")) {
            this.usuarioInicio.setText("");
            this.usuarioInicio.setForeground(Color.black);
        }
        
        if (String.valueOf(this.contraseñaInicio.getPassword()).equals("")) {
            this.contraseñaInicio.setText("************");
            this.contraseñaInicio.setForeground(Color.gray);
        }
    }//GEN-LAST:event_usuarioInicioMousePressed

    private void contraseñaInicioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contraseñaInicioMousePressed
        if (String.valueOf(this.contraseñaInicio.getPassword()).equals("************")) {
            this.contraseñaInicio.setText("");
            this.contraseñaInicio.setForeground(Color.black);
        }
        
        if (this.usuarioInicio.getText().isEmpty()) {
            this.usuarioInicio.setText("Ingrese su nombre de usuario");
            this.usuarioInicio.setForeground(Color.gray);
        }
    }//GEN-LAST:event_contraseñaInicioMousePressed

    private void usuarioInicioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_usuarioInicioFocusGained
        if (this.usuarioInicio.getText().equals("Ingrese su nombre de usuario")) {
            this.usuarioInicio.setText("");
            this.usuarioInicio.setForeground(Color.black);
        }
        
        if (String.valueOf(this.contraseñaInicio.getPassword()).equals("")) {
            this.contraseñaInicio.setText("************");
            this.contraseñaInicio.setForeground(Color.gray);
        }
    }//GEN-LAST:event_usuarioInicioFocusGained

    private void contraseñaInicioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_contraseñaInicioFocusGained
        if (String.valueOf(this.contraseñaInicio.getPassword()).equals("************")) {
            this.contraseñaInicio.setText("");
            this.contraseñaInicio.setForeground(Color.black);
        }
        
        if (this.usuarioInicio.getText().isEmpty()) {
            this.usuarioInicio.setText("Ingrese su nombre de usuario");
            this.usuarioInicio.setForeground(Color.gray);
        }
    }//GEN-LAST:event_contraseñaInicioFocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LOGIN().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonIngresarLogin;
    private javax.swing.JPasswordField contraseñaInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField usuarioInicio;
    // End of variables declaration//GEN-END:variables
}
