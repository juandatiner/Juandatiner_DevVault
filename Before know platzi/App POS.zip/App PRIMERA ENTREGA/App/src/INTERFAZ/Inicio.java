package INTERFAZ; // Se define el paquete al que pertenece la clase

import DATOS.Conexion; // Se importa la clase Conexion del paquete DATOS
import LOGICA.*; // Se importan todas las clases del paquete LOGICA
import java.awt.Color; // Se importa Color para manipular los colores de la interfaz
import java.awt.Component;
import javax.swing.JOptionPane; // Se importa JOptionPane para mostrar mensajes al usuario
import java.sql.Connection; // Se importa Connection para establecer la conexión con la base de datos
import javax.swing.RowFilter; // Se importa RowFilter para filtrar filas en una tabla
import javax.swing.table.DefaultTableModel; // Se importa DefaultTableModel para manejar los datos de una tabla
import javax.swing.table.TableRowSorter; // Se importa TableRowSorter para ordenar filas en una tabla
import java.awt.event.KeyEvent; // Se importa KeyEvent para manejar eventos de teclado
import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

public class Inicio extends javax.swing.JFrame { // Se define la clase Inicio como una subclase de javax.swing.JFrame
    
    Conexion enlace = new Conexion(); // Se crea una instancia de la clase Conexion
    Connection connect = enlace.conectar(); // Se establece la conexión con la base de datos y se asigna a la variable connect
    Cliente Cliente = new Cliente(); // Se crea una instancia de la clase Cliente
    Empleado Empleado = new Empleado(); // Se crea una instancia de la clase Empleado
    Proveedor Proveedor = new Proveedor(); // Se crea una instancia de la clase Proveedor
    MetodosPago Metodos = new MetodosPago(); // Se crea una instancia de la clase MetodosPago
    Usuarios Usuarios = new Usuarios(); // Se crea una instancia de la clase Usuarios

    TableRowSorter<DefaultTableModel>sorter; // Se declara un TableRowSorter para ordenar las filas de las tablas
    
    // Constructor de la clase Inicio
    public Inicio() {
        initComponents(); // Se inicializan los componentes de la interfaz
        this.setAlwaysOnTop(false); // Se deshabilita la propiedad "always on top" de la ventana
        probarconexion(); // Se verifica la conexión con la base de datos al iniciar la ventana
        mostrarClientes();  // Se muestra la tabla de clientes al iniciar la ventana
        mostrarEmpleados(); // Se muestra la tabla de empleados al iniciar la ventana
        mostrarProveedores(); // Se muestra la tabla de proveedores al iniciar la ventana
        mostrarMetodos(); // Se muestra la tabla de métodos de pago al iniciar la ventana
        mostrarUsuarios(); // Se muestra la tabla de usuarios al iniciar la ventana
        this.setExtendedState(Inicio.MAXIMIZED_BOTH);// Ampliar la ventana al maximo de la pantalla
    }
    
    // Método para verificar la conexión con la base de datos
    public void probarconexion (){
        if(connect == null){ // Si no se establece conexión
            Object enunciado = "No se logró la conexión"; // Se define el mensaje de advertencia
            JOptionPane.showMessageDialog(null, enunciado, "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia
            System.exit(0); // Se sale del programa
        }else{
            Object enunciado = "Conexión con éxito"; // Se define el mensaje de éxito
            JOptionPane.showMessageDialog(null, enunciado); // Se muestra el mensaje de éxito
        }
    }
    
    // Método para mostrar la tabla de clientes
    public void mostrarClientes (){        
        DefaultTableModel TablaCliente = new DefaultTableModel(); // Se crea un DefaultTableModel para la tabla de clientes
        TablaCliente.addColumn("DOCUMENTO");
        TablaCliente.addColumn("NOMBRE");
        TablaCliente.addColumn("EMAIL");
        TablaCliente.addColumn("DIRECCION");
        TablaCliente.addColumn("CELULAR");
        TablaCliente.addColumn("PUNTOS");
        tablaCliente.setModel(TablaCliente); // Se establece el modelo de la tabla
        
        String [] datosCliente = new String[6]; // Se crea un arreglo para almacenar los datos de un cliente
        Cliente.MostrarClientes(datosCliente, TablaCliente); // Se obtienen los datos de los clientes
        tablaCliente.setModel(TablaCliente); // Se establece el modelo de la tabla
        
        // Método PARA FILTRAR
        tablaCliente.setAutoCreateRowSorter(true); // Se habilita la creación automática de RowSorter
        sorter = new TableRowSorter<>(TablaCliente); // Se crea un TableRowSorter para la tabla
        tablaCliente.setRowSorter(sorter); // Se establece el RowSorter en la tabla
    }
    
    public void mostrarEmpleados (){
        
        DefaultTableModel TablaEmpleado = new DefaultTableModel(); // Se crea un modelo de tabla para los empleados
        TablaEmpleado.addColumn("ID"); // Se agrega la columna "ID" al modelo
        TablaEmpleado.addColumn("NOMBRE"); // Se agrega la columna "NOMBRE" al modelo
        TablaEmpleado.addColumn("CARGO"); // Se agrega la columna "CARGO" al modelo
        TablaEmpleado.addColumn("SALARIO"); // Se agrega la columna "SALARIO" al modelo
        TablaEmpleado.addColumn("EMAIL"); // Se agrega la columna "EMAIL" al modelo
        TablaEmpleado.addColumn("DIRECCION"); // Se agrega la columna "DIRECCION" al modelo
        TablaEmpleado.addColumn("CELULAR"); // Se agrega la columna "CELULAR" al modelo
        TablaEmpleado.addColumn("F. CONTRATACION"); // Se agrega la columna "F. CONTRATACION" al modelo
        TablaEmpleado.addColumn("N° VENTAS"); // Se agrega la columna "N° VENTAS" al modelo
        tablaEmpleado.setModel(TablaEmpleado); // Se establece el modelo en la tabla

        String [] datosEmpleado = new String[9]; // Se crea un arreglo para almacenar los datos de un empleado
        Empleado.MostrarEmpleados(datosEmpleado, TablaEmpleado); // Se obtienen los datos de los empleados
        tablaEmpleado.setModel(TablaEmpleado); // Se establece el modelo en la tabla

        // Método PARA FILTRAR
        tablaEmpleado.setAutoCreateRowSorter(true); // Se habilita la creación automática de RowSorter
        sorter = new TableRowSorter<>(TablaEmpleado); // Se crea un TableRowSorter para la tabla
        tablaEmpleado.setRowSorter(sorter); // Se establece el RowSorter en la tabla
    }

    public void mostrarProveedores (){

        DefaultTableModel TablaProveedor = new DefaultTableModel(); // Se crea un modelo de tabla para los proveedores
        TablaProveedor.addColumn("IDENTIFICACION"); // Se agrega la columna "IDENTIFICACION" al modelo
        TablaProveedor.addColumn("EMPRESA"); // Se agrega la columna "EMPRESA" al modelo
        TablaProveedor.addColumn("DIRECCION"); // Se agrega la columna "DIRECCION" al modelo
        TablaProveedor.addColumn("TELEFONO"); // Se agrega la columna "TELEFONO" al modelo
        TablaProveedor.addColumn("EMAIL"); // Se agrega la columna "EMAIL" al modelo
        TablaProveedor.addColumn("OBSERVACIONES"); // Se agrega la columna "OBSERVACIONES" al modelo
        tablaProveedor.setModel(TablaProveedor); // Se establece el modelo en la tabla

        String [] datosProveedor = new String[6]; // Se crea un arreglo para almacenar los datos de un proveedor
        Proveedor.MostrarProveedores(datosProveedor, TablaProveedor); // Se obtienen los datos de los proveedores
        tablaProveedor.setModel(TablaProveedor); // Se establece el modelo en la tabla

        // Método PARA FILTRAR
        tablaProveedor.setAutoCreateRowSorter(true); // Se habilita la creación automática de RowSorter
        sorter = new TableRowSorter<>(TablaProveedor); // Se crea un TableRowSorter para la tabla
        tablaProveedor.setRowSorter(sorter); // Se establece el RowSorter en la tabla
    }

    public void mostrarMetodos (){

        DefaultTableModel TablaMetodos = new DefaultTableModel(); // Se crea un modelo de tabla para los métodos de pago
        TablaMetodos.addColumn("ID"); // Se agrega la columna "ID" al modelo
        TablaMetodos.addColumn("NOMBRE"); // Se agrega la columna "NOMBRE" al modelo
        TablaMetodos.addColumn("DETALLES"); // Se agrega la columna "DETALLES" al modelo
        tablaMetodo.setModel(TablaMetodos); // Se establece el modelo en la tabla

        String [] datosMetodos = new String[3]; // Se crea un arreglo para almacenar los datos de un método de pago
        Metodos.MostrarMetodos(datosMetodos, TablaMetodos); // Se obtienen los datos de los métodos de pago
        tablaMetodo.setModel(TablaMetodos); // Se establece el modelo en la tabla

        // Método PARA FILTRAR
        tablaMetodo.setAutoCreateRowSorter(true); // Se habilita la creación automática de RowSorter
        sorter = new TableRowSorter<>(TablaMetodos); // Se crea un TableRowSorter para la tabla
        tablaMetodo.setRowSorter(sorter); // Se establece el RowSorter en la tabla
    }
    
    public class CheckboxRenderer extends JCheckBox implements TableCellRenderer {

    public CheckboxRenderer() {
        setHorizontalAlignment(JCheckBox.CENTER);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        if (value instanceof Boolean) {
            setSelected((Boolean) value);
        }
        return this;
    }
    }
    
    public void mostrarUsuarios() {
        DefaultTableModel TablaUsuarios = new DefaultTableModel();
        TablaUsuarios.addColumn("ID");
        TablaUsuarios.addColumn("USER");
        TablaUsuarios.addColumn("PSW");
        TablaUsuarios.addColumn("P.C");
        TablaUsuarios.addColumn("P.E");
        TablaUsuarios.addColumn("P.V");
        TablaUsuarios.addColumn("P.Co");
        TablaUsuarios.addColumn("P.I");
        TablaUsuarios.addColumn("P.F");
        TablaUsuarios.addColumn("P.P");
        TablaUsuarios.addColumn("P.M");
        tablaUsuario.setModel(TablaUsuarios);

        String[] datosUsuario = new String[11];
        boolean[] permisosUsuario = new boolean[8];
        Usuarios.MostrarUsuarios(datosUsuario, permisosUsuario, TablaUsuarios);
        tablaUsuario.setModel(TablaUsuarios);

        // Asigna el renderizador de celdas personalizado a las columnas de permisos (columnas 3 a 10)
        for (int i = 3; i <= 10; i++) {
            tablaUsuario.getColumnModel().getColumn(i).setCellRenderer(new CheckboxRenderer());
        }

        tablaUsuario.setAutoCreateRowSorter(true);
        sorter = new TableRowSorter<>(TablaUsuarios);
        tablaUsuario.setRowSorter(sorter);
    }
    
    private void filtrarClientes (){
        
        try{
            sorter.setRowFilter(RowFilter.regexFilter(filtroCliente.getText().toUpperCase()));
        }catch(Exception e){

        }
    }
    
    private void filtrarEmpleados (){
        
        try{
            sorter.setRowFilter(RowFilter.regexFilter(filtroEmpleado.getText().toUpperCase()));
        }catch(Exception e){

        }
    }
    
    private void filtrarProveedores (){
        
        try{
            sorter.setRowFilter(RowFilter.regexFilter(filtroProveedor.getText().toUpperCase()));
        }catch(Exception e){

        }
    }
    
    private void filtrarMetodos (){
        
        try{
            sorter.setRowFilter(RowFilter.regexFilter(filtroMetodo.getText().toUpperCase()));
        }catch(Exception e){

        }
    }
    
    private void filtrarUsuarios (){
        
        try{
            sorter.setRowFilter(RowFilter.regexFilter(filtroUsuario.getText().toUpperCase()));
        }catch(Exception e){

        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelIzquierdo = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        panelVentas = new javax.swing.JPanel();
        btnVentas = new javax.swing.JButton();
        panelHome = new javax.swing.JPanel();
        btnHome = new javax.swing.JButton();
        panelClientes = new javax.swing.JPanel();
        btnClientes = new javax.swing.JButton();
        panelCompras = new javax.swing.JPanel();
        btnCompras = new javax.swing.JButton();
        panelInventario = new javax.swing.JPanel();
        btnInventario = new javax.swing.JButton();
        panelFinanzas = new javax.swing.JPanel();
        btnFinanzas = new javax.swing.JButton();
        panelSalir = new javax.swing.JPanel();
        btnSalir = new javax.swing.JButton();
        PanelSuperior = new javax.swing.JPanel();
        panelEmpleados = new javax.swing.JPanel();
        btnEmpleados = new javax.swing.JButton();
        panelProveedores = new javax.swing.JPanel();
        btnProveedores = new javax.swing.JButton();
        panelMetodos = new javax.swing.JPanel();
        btnMetodosPago = new javax.swing.JButton();
        panelConexion = new javax.swing.JPanel();
        btnUsuarios = new javax.swing.JButton();
        Escritorio = new javax.swing.JPanel();
        Pestañas = new javax.swing.JTabbedPane();
        InterfazInicio = new javax.swing.JPanel();
        InterfazClientes = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        botonCancelarCliente = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtDocumentoCliente = new javax.swing.JTextField();
        txtNombreCliente = new javax.swing.JTextField();
        txtEmailCliente = new javax.swing.JTextField();
        txtCelularCliente = new javax.swing.JTextField();
        txtDireccionCliente = new javax.swing.JTextField();
        botonGuardarCliente = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCliente = new javax.swing.JTable();
        botonActualizarCliente = new javax.swing.JButton();
        botonEliminarCliente = new javax.swing.JButton();
        filtroCliente = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        InterfazVentas = new javax.swing.JPanel();
        InterfazCompras = new javax.swing.JPanel();
        InterfazInventario = new javax.swing.JPanel();
        InterfazFinanzas = new javax.swing.JPanel();
        InterfazEmpleados = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel17 = new javax.swing.JLabel();
        botonCancelarEmpleado = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        txtIdentificacionEmpleado = new javax.swing.JTextField();
        txtNombreEmpleado = new javax.swing.JTextField();
        txtCargoEmpleado = new javax.swing.JTextField();
        txtEmailEmpleado = new javax.swing.JTextField();
        txtSalarioEmpleado = new javax.swing.JTextField();
        botonGuardarEmpleado = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        txtCelularEmpleado = new javax.swing.JTextField();
        txtDireccionEmpleado = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaEmpleado = new javax.swing.JTable();
        botonActualizarEmpleado = new javax.swing.JButton();
        botonEliminarEmpleado = new javax.swing.JButton();
        filtroEmpleado = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        InterfazProveedores = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        botonCancelarProveedor = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtIdentificacionProveedor = new javax.swing.JTextField();
        txtEmpresaProveedor = new javax.swing.JTextField();
        txtDireccionProveedor = new javax.swing.JTextField();
        txtEmailProveedor = new javax.swing.JTextField();
        txtTelefonoProveedor = new javax.swing.JTextField();
        botonGuardarProveedor = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaProveedor = new javax.swing.JTable();
        botonActualizarProveedor = new javax.swing.JButton();
        botonEliminarProveedor = new javax.swing.JButton();
        filtroProveedor = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        InterfazMetodos = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jSeparator7 = new javax.swing.JSeparator();
        jLabel26 = new javax.swing.JLabel();
        botonCancelarMetodo = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        txtNombreMetodo = new javax.swing.JTextField();
        txtDetallesMetodo = new javax.swing.JTextField();
        botonGuardarMetodo = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jSeparator8 = new javax.swing.JSeparator();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablaMetodo = new javax.swing.JTable();
        botonActualizarMetodo = new javax.swing.JButton();
        botonEliminarMetodo = new javax.swing.JButton();
        filtroMetodo = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        InterfazUsuarios = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jSeparator9 = new javax.swing.JSeparator();
        jLabel30 = new javax.swing.JLabel();
        botonCancelarUsuario = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        botonGuardarusuario = new javax.swing.JButton();
        txtContraseñaUsuario = new javax.swing.JPasswordField();
        CheckClientes = new javax.swing.JCheckBox();
        CheckEmpleados = new javax.swing.JCheckBox();
        CheckVentas = new javax.swing.JCheckBox();
        CheckCompras = new javax.swing.JCheckBox();
        CheckInventario = new javax.swing.JCheckBox();
        CheckProveedores = new javax.swing.JCheckBox();
        CheckFinanzas = new javax.swing.JCheckBox();
        CheckMetodos = new javax.swing.JCheckBox();
        jLabel42 = new javax.swing.JLabel();
        jSeparator11 = new javax.swing.JSeparator();
        jPanel11 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablaUsuario = new javax.swing.JTable();
        botonActualizarUsuario = new javax.swing.JButton();
        botonEliminarUsuario = new javax.swing.JButton();
        filtroUsuario = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        PanelIzquierdo.setBackground(new java.awt.Color(28, 32, 32));

        jPanel1.setBackground(new java.awt.Color(28, 32, 32));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        panelVentas.setBackground(new java.awt.Color(28, 32, 32));

        btnVentas.setBackground(new java.awt.Color(0, 0, 0));
        btnVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/ventas.png"))); // NOI18N
        btnVentas.setBorderPainted(false);
        btnVentas.setContentAreaFilled(false);
        btnVentas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnVentas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnVentasMouseMoved(evt);
            }
        });
        btnVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVentasMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnVentasMouseExited(evt);
            }
        });
        btnVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVentasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelVentasLayout = new javax.swing.GroupLayout(panelVentas);
        panelVentas.setLayout(panelVentasLayout);
        panelVentasLayout.setHorizontalGroup(
            panelVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelVentasLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        panelVentasLayout.setVerticalGroup(
            panelVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelVentasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        panelHome.setBackground(new java.awt.Color(28, 32, 32));
        panelHome.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                panelHomeMouseMoved(evt);
            }
        });
        panelHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelHomeMouseExited(evt);
            }
        });

        btnHome.setBackground(new java.awt.Color(0, 0, 0));
        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/tienda.png"))); // NOI18N
        btnHome.setBorderPainted(false);
        btnHome.setContentAreaFilled(false);
        btnHome.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHome.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnHomeMouseMoved(evt);
            }
        });
        btnHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnHomeMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnHomeMouseExited(evt);
            }
        });
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelHomeLayout = new javax.swing.GroupLayout(panelHome);
        panelHome.setLayout(panelHomeLayout);
        panelHomeLayout.setHorizontalGroup(
            panelHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelHomeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnHome, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelHomeLayout.setVerticalGroup(
            panelHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelHomeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelClientes.setBackground(new java.awt.Color(28, 32, 32));

        btnClientes.setBackground(new java.awt.Color(0, 0, 0));
        btnClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/apreton-de-manos (1).png"))); // NOI18N
        btnClientes.setBorderPainted(false);
        btnClientes.setContentAreaFilled(false);
        btnClientes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnClientes.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnClientesMouseMoved(evt);
            }
        });
        btnClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnClientesMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnClientesMouseExited(evt);
            }
        });
        btnClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClientesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelClientesLayout = new javax.swing.GroupLayout(panelClientes);
        panelClientes.setLayout(panelClientesLayout);
        panelClientesLayout.setHorizontalGroup(
            panelClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelClientesLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        panelClientesLayout.setVerticalGroup(
            panelClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelClientesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnClientes)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        panelCompras.setBackground(new java.awt.Color(28, 32, 32));

        btnCompras.setBackground(new java.awt.Color(0, 0, 0));
        btnCompras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/carrito-de-compras.png"))); // NOI18N
        btnCompras.setBorderPainted(false);
        btnCompras.setContentAreaFilled(false);
        btnCompras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCompras.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnComprasMouseMoved(evt);
            }
        });
        btnCompras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnComprasMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnComprasMouseExited(evt);
            }
        });
        btnCompras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelComprasLayout = new javax.swing.GroupLayout(panelCompras);
        panelCompras.setLayout(panelComprasLayout);
        panelComprasLayout.setHorizontalGroup(
            panelComprasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelComprasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnCompras, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelComprasLayout.setVerticalGroup(
            panelComprasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelComprasLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(btnCompras)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        panelInventario.setBackground(new java.awt.Color(28, 32, 32));

        btnInventario.setBackground(new java.awt.Color(0, 0, 0));
        btnInventario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/inventario.png"))); // NOI18N
        btnInventario.setBorderPainted(false);
        btnInventario.setContentAreaFilled(false);
        btnInventario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnInventario.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnInventarioMouseMoved(evt);
            }
        });
        btnInventario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnInventarioMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnInventarioMouseExited(evt);
            }
        });

        javax.swing.GroupLayout panelInventarioLayout = new javax.swing.GroupLayout(panelInventario);
        panelInventario.setLayout(panelInventarioLayout);
        panelInventarioLayout.setHorizontalGroup(
            panelInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelInventarioLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnInventario, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelInventarioLayout.setVerticalGroup(
            panelInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelInventarioLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(btnInventario)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        panelFinanzas.setBackground(new java.awt.Color(28, 32, 32));

        btnFinanzas.setBackground(new java.awt.Color(0, 0, 0));
        btnFinanzas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/contabilidad.png"))); // NOI18N
        btnFinanzas.setBorderPainted(false);
        btnFinanzas.setContentAreaFilled(false);
        btnFinanzas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFinanzas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnFinanzasMouseMoved(evt);
            }
        });
        btnFinanzas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFinanzasMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnFinanzasMouseExited(evt);
            }
        });
        btnFinanzas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinanzasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelFinanzasLayout = new javax.swing.GroupLayout(panelFinanzas);
        panelFinanzas.setLayout(panelFinanzasLayout);
        panelFinanzasLayout.setHorizontalGroup(
            panelFinanzasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFinanzasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnFinanzas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelFinanzasLayout.setVerticalGroup(
            panelFinanzasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFinanzasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnFinanzas)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        panelSalir.setBackground(new java.awt.Color(28, 32, 32));

        btnSalir.setBackground(new java.awt.Color(0, 0, 0));
        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/flecha-derecha-de-linea-recta-delgada.png"))); // NOI18N
        btnSalir.setBorderPainted(false);
        btnSalir.setContentAreaFilled(false);
        btnSalir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSalir.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnSalirMouseMoved(evt);
            }
        });
        btnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalirMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnSalirMouseExited(evt);
            }
        });
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelSalirLayout = new javax.swing.GroupLayout(panelSalir);
        panelSalir.setLayout(panelSalirLayout);
        panelSalirLayout.setHorizontalGroup(
            panelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelSalirLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        panelSalirLayout.setVerticalGroup(
            panelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSalirLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSalir)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout PanelIzquierdoLayout = new javax.swing.GroupLayout(PanelIzquierdo);
        PanelIzquierdo.setLayout(PanelIzquierdoLayout);
        PanelIzquierdoLayout.setHorizontalGroup(
            PanelIzquierdoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelIzquierdoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelIzquierdoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelClientes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelVentas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelIzquierdoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(panelHome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(panelCompras, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelInventario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelFinanzas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        PanelIzquierdoLayout.setVerticalGroup(
            PanelIzquierdoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelIzquierdoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panelHome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panelClientes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(panelVentas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelCompras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelInventario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panelFinanzas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panelSalir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        PanelSuperior.setBackground(new java.awt.Color(255, 255, 255));
        PanelSuperior.setForeground(new java.awt.Color(204, 204, 204));

        panelEmpleados.setBackground(new java.awt.Color(255, 255, 255));

        btnEmpleados.setBackground(new java.awt.Color(0, 0, 0));
        btnEmpleados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/cajero (2).png"))); // NOI18N
        btnEmpleados.setBorderPainted(false);
        btnEmpleados.setContentAreaFilled(false);
        btnEmpleados.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEmpleados.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnEmpleadosMouseMoved(evt);
            }
        });
        btnEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEmpleadosMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEmpleadosMouseExited(evt);
            }
        });
        btnEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEmpleadosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelEmpleadosLayout = new javax.swing.GroupLayout(panelEmpleados);
        panelEmpleados.setLayout(panelEmpleadosLayout);
        panelEmpleadosLayout.setHorizontalGroup(
            panelEmpleadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelEmpleadosLayout.createSequentialGroup()
                .addContainerGap(7, Short.MAX_VALUE)
                .addComponent(btnEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelEmpleadosLayout.setVerticalGroup(
            panelEmpleadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelEmpleadosLayout.createSequentialGroup()
                .addGap(0, 12, Short.MAX_VALUE)
                .addComponent(btnEmpleados))
        );

        panelProveedores.setBackground(new java.awt.Color(255, 255, 255));

        btnProveedores.setBackground(new java.awt.Color(0, 0, 0));
        btnProveedores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/parque-industrial.png"))); // NOI18N
        btnProveedores.setBorderPainted(false);
        btnProveedores.setContentAreaFilled(false);
        btnProveedores.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnProveedores.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnProveedoresMouseMoved(evt);
            }
        });
        btnProveedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnProveedoresMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnProveedoresMouseExited(evt);
            }
        });

        javax.swing.GroupLayout panelProveedoresLayout = new javax.swing.GroupLayout(panelProveedores);
        panelProveedores.setLayout(panelProveedoresLayout);
        panelProveedoresLayout.setHorizontalGroup(
            panelProveedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelProveedoresLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnProveedores)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelProveedoresLayout.setVerticalGroup(
            panelProveedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelProveedoresLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnProveedores))
        );

        panelMetodos.setBackground(new java.awt.Color(255, 255, 255));

        btnMetodosPago.setBackground(new java.awt.Color(0, 0, 0));
        btnMetodosPago.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/billetera.png"))); // NOI18N
        btnMetodosPago.setBorderPainted(false);
        btnMetodosPago.setContentAreaFilled(false);
        btnMetodosPago.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnMetodosPago.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnMetodosPagoMouseMoved(evt);
            }
        });
        btnMetodosPago.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnMetodosPagoMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnMetodosPagoMouseExited(evt);
            }
        });

        javax.swing.GroupLayout panelMetodosLayout = new javax.swing.GroupLayout(panelMetodos);
        panelMetodos.setLayout(panelMetodosLayout);
        panelMetodosLayout.setHorizontalGroup(
            panelMetodosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMetodosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnMetodosPago)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelMetodosLayout.setVerticalGroup(
            panelMetodosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMetodosLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnMetodosPago))
        );

        panelConexion.setBackground(new java.awt.Color(255, 255, 255));

        btnUsuarios.setBackground(new java.awt.Color(0, 0, 0));
        btnUsuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/INTERFAZ/Imagenes/mas.png"))); // NOI18N
        btnUsuarios.setBorderPainted(false);
        btnUsuarios.setContentAreaFilled(false);
        btnUsuarios.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnUsuarios.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                btnUsuariosMouseMoved(evt);
            }
        });
        btnUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnUsuariosMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnUsuariosMouseExited(evt);
            }
        });

        javax.swing.GroupLayout panelConexionLayout = new javax.swing.GroupLayout(panelConexion);
        panelConexion.setLayout(panelConexionLayout);
        panelConexionLayout.setHorizontalGroup(
            panelConexionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelConexionLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelConexionLayout.setVerticalGroup(
            panelConexionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelConexionLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnUsuarios))
        );

        javax.swing.GroupLayout PanelSuperiorLayout = new javax.swing.GroupLayout(PanelSuperior);
        PanelSuperior.setLayout(PanelSuperiorLayout);
        PanelSuperiorLayout.setHorizontalGroup(
            PanelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelSuperiorLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panelEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panelProveedores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelMetodos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelConexion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10))
        );
        PanelSuperiorLayout.setVerticalGroup(
            PanelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelSuperiorLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(PanelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelConexion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelMetodos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelProveedores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        Escritorio.setBackground(new java.awt.Color(255, 255, 255));

        Pestañas.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);
        Pestañas.setEnabled(false);

        InterfazInicio.setBackground(new java.awt.Color(204, 255, 51));

        javax.swing.GroupLayout InterfazInicioLayout = new javax.swing.GroupLayout(InterfazInicio);
        InterfazInicio.setLayout(InterfazInicioLayout);
        InterfazInicioLayout.setHorizontalGroup(
            InterfazInicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1548, Short.MAX_VALUE)
        );
        InterfazInicioLayout.setVerticalGroup(
            InterfazInicioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 795, Short.MAX_VALUE)
        );

        Pestañas.addTab("", InterfazInicio);

        InterfazClientes.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 1, 32)); // NOI18N
        jLabel2.setText("NUEVO");

        botonCancelarCliente.setBackground(new java.awt.Color(255, 51, 51));
        botonCancelarCliente.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonCancelarCliente.setForeground(new java.awt.Color(255, 255, 255));
        botonCancelarCliente.setText("CANCELAR");
        botonCancelarCliente.setBorder(null);
        botonCancelarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCancelarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarClienteActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel4.setText("Documento:");

        jLabel5.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel5.setText("Nombre:");

        jLabel7.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel7.setText("Email:");

        jLabel10.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel10.setText("Celular:");

        jLabel11.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel11.setText("Dirección:");

        txtDocumentoCliente.setForeground(java.awt.Color.gray);
        txtDocumentoCliente.setText("Ingresa el Documento");
        txtDocumentoCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDocumentoClienteFocusGained(evt);
            }
        });
        txtDocumentoCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDocumentoClienteMousePressed(evt);
            }
        });
        txtDocumentoCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDocumentoClienteActionPerformed(evt);
            }
        });

        txtNombreCliente.setForeground(java.awt.Color.gray);
        txtNombreCliente.setText("Ingresa el Nombre");
        txtNombreCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtNombreClienteFocusGained(evt);
            }
        });
        txtNombreCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtNombreClienteMousePressed(evt);
            }
        });

        txtEmailCliente.setForeground(java.awt.Color.gray);
        txtEmailCliente.setText("Ingresa el Email");
        txtEmailCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtEmailClienteFocusGained(evt);
            }
        });
        txtEmailCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtEmailClienteMousePressed(evt);
            }
        });
        txtEmailCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailClienteActionPerformed(evt);
            }
        });

        txtCelularCliente.setForeground(java.awt.Color.gray);
        txtCelularCliente.setText("Ingresa el Celular");
        txtCelularCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCelularClienteFocusGained(evt);
            }
        });
        txtCelularCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtCelularClienteMousePressed(evt);
            }
        });

        txtDireccionCliente.setForeground(java.awt.Color.gray);
        txtDireccionCliente.setText("Ingresa la Dirección");
        txtDireccionCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDireccionClienteFocusGained(evt);
            }
        });
        txtDireccionCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDireccionClienteMousePressed(evt);
            }
        });

        botonGuardarCliente.setBackground(new java.awt.Color(51, 153, 0));
        botonGuardarCliente.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonGuardarCliente.setForeground(new java.awt.Color(255, 255, 255));
        botonGuardarCliente.setText("GUARDAR");
        botonGuardarCliente.setBorder(null);
        botonGuardarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonGuardarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarClienteActionPerformed(evt);
            }
        });
        botonGuardarCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                botonGuardarClienteKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botonGuardarClienteKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(192, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(169, 169, 169))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(botonCancelarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(botonGuardarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel7)
                            .addComponent(jLabel11)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtCelularCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDireccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEmailCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDocumentoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtDocumentoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtEmailCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtDireccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtCelularCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonCancelarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonGuardarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel1.setText("CLIENTES");

        tablaCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tablaCliente);

        botonActualizarCliente.setBackground(new java.awt.Color(229, 229, 0));
        botonActualizarCliente.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonActualizarCliente.setForeground(new java.awt.Color(255, 255, 255));
        botonActualizarCliente.setText("Actualizar");
        botonActualizarCliente.setBorder(null);
        botonActualizarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonActualizarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarClienteActionPerformed(evt);
            }
        });

        botonEliminarCliente.setBackground(new java.awt.Color(239, 18, 29));
        botonEliminarCliente.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonEliminarCliente.setForeground(new java.awt.Color(255, 255, 255));
        botonEliminarCliente.setText("Eliminar");
        botonEliminarCliente.setBorder(null);
        botonEliminarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonEliminarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarClienteActionPerformed(evt);
            }
        });

        filtroCliente.setForeground(java.awt.Color.gray);
        filtroCliente.setText("Ingresa la busqueda");
        filtroCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                filtroClienteFocusGained(evt);
            }
        });
        filtroCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                filtroClienteMousePressed(evt);
            }
        });
        filtroCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtroClienteActionPerformed(evt);
            }
        });
        filtroCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                filtroClienteKeyReleased(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        jLabel3.setText("Filtrar:");

        jLabel6.setText("*Recuerde  que no se puede actualizar por Documento");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(316, 316, 316))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(154, 154, 154)
                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 693, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(filtroCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 723, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonActualizarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonEliminarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonActualizarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(botonEliminarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(217, 217, 217))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filtroCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6)
                        .addGap(8, 8, 8)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(27, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout InterfazClientesLayout = new javax.swing.GroupLayout(InterfazClientes);
        InterfazClientes.setLayout(InterfazClientesLayout);
        InterfazClientesLayout.setHorizontalGroup(
            InterfazClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazClientesLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        InterfazClientesLayout.setVerticalGroup(
            InterfazClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazClientesLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(InterfazClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        Pestañas.addTab("", InterfazClientes);

        InterfazVentas.setBackground(new java.awt.Color(0, 255, 204));

        javax.swing.GroupLayout InterfazVentasLayout = new javax.swing.GroupLayout(InterfazVentas);
        InterfazVentas.setLayout(InterfazVentasLayout);
        InterfazVentasLayout.setHorizontalGroup(
            InterfazVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1548, Short.MAX_VALUE)
        );
        InterfazVentasLayout.setVerticalGroup(
            InterfazVentasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 795, Short.MAX_VALUE)
        );

        Pestañas.addTab("", InterfazVentas);

        InterfazCompras.setBackground(new java.awt.Color(204, 0, 0));

        javax.swing.GroupLayout InterfazComprasLayout = new javax.swing.GroupLayout(InterfazCompras);
        InterfazCompras.setLayout(InterfazComprasLayout);
        InterfazComprasLayout.setHorizontalGroup(
            InterfazComprasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1548, Short.MAX_VALUE)
        );
        InterfazComprasLayout.setVerticalGroup(
            InterfazComprasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 795, Short.MAX_VALUE)
        );

        Pestañas.addTab("", InterfazCompras);

        InterfazInventario.setBackground(new java.awt.Color(153, 255, 255));

        javax.swing.GroupLayout InterfazInventarioLayout = new javax.swing.GroupLayout(InterfazInventario);
        InterfazInventario.setLayout(InterfazInventarioLayout);
        InterfazInventarioLayout.setHorizontalGroup(
            InterfazInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1548, Short.MAX_VALUE)
        );
        InterfazInventarioLayout.setVerticalGroup(
            InterfazInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 795, Short.MAX_VALUE)
        );

        Pestañas.addTab("", InterfazInventario);

        InterfazFinanzas.setBackground(new java.awt.Color(51, 51, 255));

        javax.swing.GroupLayout InterfazFinanzasLayout = new javax.swing.GroupLayout(InterfazFinanzas);
        InterfazFinanzas.setLayout(InterfazFinanzasLayout);
        InterfazFinanzasLayout.setHorizontalGroup(
            InterfazFinanzasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1548, Short.MAX_VALUE)
        );
        InterfazFinanzasLayout.setVerticalGroup(
            InterfazFinanzasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 795, Short.MAX_VALUE)
        );

        Pestañas.addTab("", InterfazFinanzas);

        InterfazEmpleados.setBackground(new java.awt.Color(255, 255, 255));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel17.setFont(new java.awt.Font("Tw Cen MT", 1, 32)); // NOI18N
        jLabel17.setText("NUEVO");

        botonCancelarEmpleado.setBackground(new java.awt.Color(255, 51, 51));
        botonCancelarEmpleado.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonCancelarEmpleado.setForeground(new java.awt.Color(255, 255, 255));
        botonCancelarEmpleado.setText("CANCELAR");
        botonCancelarEmpleado.setBorder(null);
        botonCancelarEmpleado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCancelarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarEmpleadoActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel18.setText("Identificacion:");

        jLabel19.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel19.setText("Nombre:");

        jLabel20.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel20.setText("Cargo:");

        jLabel21.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel21.setText("Email:");

        jLabel22.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel22.setText("Salario:");

        txtIdentificacionEmpleado.setForeground(java.awt.Color.gray);
        txtIdentificacionEmpleado.setText("Ingresa la Identificación");
        txtIdentificacionEmpleado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtIdentificacionEmpleadoFocusGained(evt);
            }
        });
        txtIdentificacionEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtIdentificacionEmpleadoMousePressed(evt);
            }
        });
        txtIdentificacionEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdentificacionEmpleadoActionPerformed(evt);
            }
        });

        txtNombreEmpleado.setForeground(java.awt.Color.gray);
        txtNombreEmpleado.setText("Ingresa el Nombre");
        txtNombreEmpleado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtNombreEmpleadoFocusGained(evt);
            }
        });
        txtNombreEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtNombreEmpleadoMousePressed(evt);
            }
        });

        txtCargoEmpleado.setForeground(java.awt.Color.gray);
        txtCargoEmpleado.setText("Ingresa el Cargo");
        txtCargoEmpleado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCargoEmpleadoFocusGained(evt);
            }
        });
        txtCargoEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtCargoEmpleadoMousePressed(evt);
            }
        });
        txtCargoEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCargoEmpleadoActionPerformed(evt);
            }
        });

        txtEmailEmpleado.setForeground(java.awt.Color.gray);
        txtEmailEmpleado.setText("Ingresa el Email");
        txtEmailEmpleado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtEmailEmpleadoFocusGained(evt);
            }
        });
        txtEmailEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtEmailEmpleadoMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                txtEmailEmpleadoMouseReleased(evt);
            }
        });

        txtSalarioEmpleado.setForeground(java.awt.Color.gray);
        txtSalarioEmpleado.setText("000000.00");
        txtSalarioEmpleado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtSalarioEmpleadoFocusGained(evt);
            }
        });
        txtSalarioEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtSalarioEmpleadoMousePressed(evt);
            }
        });

        botonGuardarEmpleado.setBackground(new java.awt.Color(51, 153, 0));
        botonGuardarEmpleado.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonGuardarEmpleado.setForeground(new java.awt.Color(255, 255, 255));
        botonGuardarEmpleado.setText("GUARDAR");
        botonGuardarEmpleado.setBorder(null);
        botonGuardarEmpleado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonGuardarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarEmpleadoActionPerformed(evt);
            }
        });
        botonGuardarEmpleado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                botonGuardarEmpleadoKeyPressed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel25.setText("Celular:");

        jLabel27.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel27.setText("Direccion:");

        txtCelularEmpleado.setForeground(java.awt.Color.gray);
        txtCelularEmpleado.setText("Ingresa el Celular");
        txtCelularEmpleado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCelularEmpleadoFocusGained(evt);
            }
        });
        txtCelularEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtCelularEmpleadoMousePressed(evt);
            }
        });

        txtDireccionEmpleado.setForeground(java.awt.Color.gray);
        txtDireccionEmpleado.setText("Ingresa la Dirección");
        txtDireccionEmpleado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDireccionEmpleadoFocusGained(evt);
            }
        });
        txtDireccionEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDireccionEmpleadoMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(192, Short.MAX_VALUE)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(169, 169, 169))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(botonCancelarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(botonGuardarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(jLabel25)
                            .addComponent(jLabel22)
                            .addComponent(jLabel19)
                            .addComponent(jLabel27))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmailEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSalarioEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCargoEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombreEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdentificacionEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCelularEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDireccionEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(txtIdentificacionEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombreEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCargoEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSalarioEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEmailEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21))
                .addGap(19, 19, 19)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel27)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(txtDireccionEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCelularEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel25))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonCancelarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonGuardarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel23.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel23.setText("EMPLEADOS");

        tablaEmpleado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(tablaEmpleado);

        botonActualizarEmpleado.setBackground(new java.awt.Color(229, 229, 0));
        botonActualizarEmpleado.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonActualizarEmpleado.setForeground(new java.awt.Color(255, 255, 255));
        botonActualizarEmpleado.setText("Actualizar");
        botonActualizarEmpleado.setBorder(null);
        botonActualizarEmpleado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonActualizarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarEmpleadoActionPerformed(evt);
            }
        });

        botonEliminarEmpleado.setBackground(new java.awt.Color(239, 18, 29));
        botonEliminarEmpleado.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonEliminarEmpleado.setForeground(new java.awt.Color(255, 255, 255));
        botonEliminarEmpleado.setText("Eliminar");
        botonEliminarEmpleado.setBorder(null);
        botonEliminarEmpleado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonEliminarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarEmpleadoActionPerformed(evt);
            }
        });

        filtroEmpleado.setForeground(java.awt.Color.gray);
        filtroEmpleado.setText("Ingresa la busqueda");
        filtroEmpleado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                filtroEmpleadoFocusGained(evt);
            }
        });
        filtroEmpleado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                filtroEmpleadoMousePressed(evt);
            }
        });
        filtroEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtroEmpleadoActionPerformed(evt);
            }
        });
        filtroEmpleado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                filtroEmpleadoKeyReleased(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        jLabel24.setText("Filtrar:");

        jLabel39.setText("*Recuerde  que no se puede actualizar por Identificación");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(154, 154, 154)
                                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 693, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(filtroEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(155, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jScrollPane3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonActualizarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonEliminarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(341, 341, 341))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonActualizarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(botonEliminarEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(217, 217, 217))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filtroEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(27, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout InterfazEmpleadosLayout = new javax.swing.GroupLayout(InterfazEmpleados);
        InterfazEmpleados.setLayout(InterfazEmpleadosLayout);
        InterfazEmpleadosLayout.setHorizontalGroup(
            InterfazEmpleadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazEmpleadosLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        InterfazEmpleadosLayout.setVerticalGroup(
            InterfazEmpleadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazEmpleadosLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(InterfazEmpleadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        Pestañas.addTab("", InterfazEmpleados);

        InterfazProveedores.setBackground(new java.awt.Color(255, 255, 255));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel8.setFont(new java.awt.Font("Tw Cen MT", 1, 32)); // NOI18N
        jLabel8.setText("NUEVO");

        botonCancelarProveedor.setBackground(new java.awt.Color(255, 51, 51));
        botonCancelarProveedor.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonCancelarProveedor.setForeground(new java.awt.Color(255, 255, 255));
        botonCancelarProveedor.setText("CANCELAR");
        botonCancelarProveedor.setBorder(null);
        botonCancelarProveedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCancelarProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarProveedorActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel9.setText("Identificación:");

        jLabel12.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel12.setText("Empresa:");

        jLabel13.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel13.setText("Dirección:");

        jLabel14.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel14.setText("Email:");

        jLabel15.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel15.setText("Teléfono:");

        txtIdentificacionProveedor.setForeground(java.awt.Color.gray);
        txtIdentificacionProveedor.setText("Ingresa la Identificación");
        txtIdentificacionProveedor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtIdentificacionProveedorFocusGained(evt);
            }
        });
        txtIdentificacionProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtIdentificacionProveedorMousePressed(evt);
            }
        });
        txtIdentificacionProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdentificacionProveedorActionPerformed(evt);
            }
        });

        txtEmpresaProveedor.setForeground(java.awt.Color.gray);
        txtEmpresaProveedor.setText("Ingresa la Empresa");
        txtEmpresaProveedor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtEmpresaProveedorFocusGained(evt);
            }
        });
        txtEmpresaProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtEmpresaProveedorMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtEmpresaProveedorMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtEmpresaProveedorMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                txtEmpresaProveedorMouseReleased(evt);
            }
        });
        txtEmpresaProveedor.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtEmpresaProveedorInputMethodTextChanged(evt);
            }
        });
        txtEmpresaProveedor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEmpresaProveedorKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtEmpresaProveedorKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEmpresaProveedorKeyTyped(evt);
            }
        });

        txtDireccionProveedor.setForeground(java.awt.Color.gray);
        txtDireccionProveedor.setText("Ingresa la Dirección");
        txtDireccionProveedor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDireccionProveedorFocusGained(evt);
            }
        });
        txtDireccionProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDireccionProveedorMousePressed(evt);
            }
        });
        txtDireccionProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionProveedorActionPerformed(evt);
            }
        });

        txtEmailProveedor.setForeground(java.awt.Color.gray);
        txtEmailProveedor.setText("Ingresa el Email");
        txtEmailProveedor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtEmailProveedorFocusGained(evt);
            }
        });
        txtEmailProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtEmailProveedorMousePressed(evt);
            }
        });

        txtTelefonoProveedor.setForeground(java.awt.Color.gray);
        txtTelefonoProveedor.setText("Ingresa el Teléfono");
        txtTelefonoProveedor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtTelefonoProveedorFocusGained(evt);
            }
        });
        txtTelefonoProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtTelefonoProveedorMousePressed(evt);
            }
        });

        botonGuardarProveedor.setBackground(new java.awt.Color(51, 153, 0));
        botonGuardarProveedor.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonGuardarProveedor.setForeground(new java.awt.Color(255, 255, 255));
        botonGuardarProveedor.setText("GUARDAR");
        botonGuardarProveedor.setBorder(null);
        botonGuardarProveedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonGuardarProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarProveedorActionPerformed(evt);
            }
        });
        botonGuardarProveedor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                botonGuardarProveedorKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(192, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(169, 169, 169))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(botonCancelarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(botonGuardarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13)
                            .addComponent(jLabel15)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmailProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTelefonoProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDireccionProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEmpresaProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdentificacionProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtIdentificacionProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txtEmpresaProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtDireccionProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(txtTelefonoProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(txtEmailProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonCancelarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonGuardarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel16.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel16.setText("PROVEEDORES");

        tablaProveedor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(tablaProveedor);

        botonActualizarProveedor.setBackground(new java.awt.Color(229, 229, 0));
        botonActualizarProveedor.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonActualizarProveedor.setForeground(new java.awt.Color(255, 255, 255));
        botonActualizarProveedor.setText("Actualizar");
        botonActualizarProveedor.setBorder(null);
        botonActualizarProveedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonActualizarProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarProveedorActionPerformed(evt);
            }
        });

        botonEliminarProveedor.setBackground(new java.awt.Color(239, 18, 29));
        botonEliminarProveedor.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonEliminarProveedor.setForeground(new java.awt.Color(255, 255, 255));
        botonEliminarProveedor.setText("Eliminar");
        botonEliminarProveedor.setBorder(null);
        botonEliminarProveedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonEliminarProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarProveedorActionPerformed(evt);
            }
        });

        filtroProveedor.setForeground(java.awt.Color.gray);
        filtroProveedor.setText("Ingresa la busqueda");
        filtroProveedor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                filtroProveedorFocusGained(evt);
            }
        });
        filtroProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                filtroProveedorMousePressed(evt);
            }
        });
        filtroProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtroProveedorActionPerformed(evt);
            }
        });
        filtroProveedor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                filtroProveedorKeyReleased(evt);
            }
        });

        jLabel37.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        jLabel37.setText("Filtrar:");

        jLabel38.setText("*Recuerde que no se puede actualizar por Identificación");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel38)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(154, 154, 154)
                                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 693, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(filtroProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 723, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonActualizarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonEliminarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel16)
                .addGap(309, 309, 309))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonActualizarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(botonEliminarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(217, 217, 217))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filtroProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel38)
                        .addGap(8, 8, 8)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(27, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout InterfazProveedoresLayout = new javax.swing.GroupLayout(InterfazProveedores);
        InterfazProveedores.setLayout(InterfazProveedoresLayout);
        InterfazProveedoresLayout.setHorizontalGroup(
            InterfazProveedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazProveedoresLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        InterfazProveedoresLayout.setVerticalGroup(
            InterfazProveedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazProveedoresLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(InterfazProveedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        Pestañas.addTab("", InterfazProveedores);

        InterfazMetodos.setBackground(new java.awt.Color(255, 255, 255));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel26.setFont(new java.awt.Font("Tw Cen MT", 1, 32)); // NOI18N
        jLabel26.setText("NUEVO");

        botonCancelarMetodo.setBackground(new java.awt.Color(255, 51, 51));
        botonCancelarMetodo.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonCancelarMetodo.setForeground(new java.awt.Color(255, 255, 255));
        botonCancelarMetodo.setText("CANCELAR");
        botonCancelarMetodo.setBorder(null);
        botonCancelarMetodo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCancelarMetodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarMetodoActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel28.setText("Nombre:");

        jLabel29.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel29.setText("Detalles:");

        txtNombreMetodo.setForeground(java.awt.Color.gray);
        txtNombreMetodo.setText("Ingresa el Nombre");
        txtNombreMetodo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtNombreMetodoFocusGained(evt);
            }
        });
        txtNombreMetodo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtNombreMetodoMousePressed(evt);
            }
        });
        txtNombreMetodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreMetodoActionPerformed(evt);
            }
        });

        txtDetallesMetodo.setForeground(java.awt.Color.gray);
        txtDetallesMetodo.setText("Ingresa los Detalles");
        txtDetallesMetodo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDetallesMetodoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDetallesMetodoFocusLost(evt);
            }
        });
        txtDetallesMetodo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtDetallesMetodoMousePressed(evt);
            }
        });

        botonGuardarMetodo.setBackground(new java.awt.Color(51, 153, 0));
        botonGuardarMetodo.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonGuardarMetodo.setForeground(new java.awt.Color(255, 255, 255));
        botonGuardarMetodo.setText("GUARDAR");
        botonGuardarMetodo.setBorder(null);
        botonGuardarMetodo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonGuardarMetodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarMetodoActionPerformed(evt);
            }
        });
        botonGuardarMetodo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                botonGuardarMetodoKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(botonCancelarMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(botonGuardarMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(18, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(169, 169, 169))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel29)
                    .addComponent(jLabel28))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtDetallesMetodo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreMetodo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombreMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel28))
                .addGap(98, 98, 98)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDetallesMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel29))
                .addGap(199, 199, 199)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonCancelarMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonGuardarMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel33.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel33.setText("MÉTODOS DE PAGO");

        tablaMetodo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(tablaMetodo);

        botonActualizarMetodo.setBackground(new java.awt.Color(229, 229, 0));
        botonActualizarMetodo.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonActualizarMetodo.setForeground(new java.awt.Color(255, 255, 255));
        botonActualizarMetodo.setText("Actualizar");
        botonActualizarMetodo.setBorder(null);
        botonActualizarMetodo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonActualizarMetodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarMetodoActionPerformed(evt);
            }
        });

        botonEliminarMetodo.setBackground(new java.awt.Color(239, 18, 29));
        botonEliminarMetodo.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonEliminarMetodo.setForeground(new java.awt.Color(255, 255, 255));
        botonEliminarMetodo.setText("Eliminar");
        botonEliminarMetodo.setBorder(null);
        botonEliminarMetodo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonEliminarMetodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarMetodoActionPerformed(evt);
            }
        });

        filtroMetodo.setForeground(java.awt.Color.gray);
        filtroMetodo.setText("Ingresa la busqueda");
        filtroMetodo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                filtroMetodoFocusGained(evt);
            }
        });
        filtroMetodo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                filtroMetodoMousePressed(evt);
            }
        });
        filtroMetodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtroMetodoActionPerformed(evt);
            }
        });
        filtroMetodo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                filtroMetodoKeyReleased(evt);
            }
        });

        jLabel34.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        jLabel34.setText("Filtrar:");

        jLabel35.setText("*Recuerde que solo puede actualizar los detalles");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel35)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(154, 154, 154)
                                .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 693, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(filtroMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 723, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonActualizarMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonEliminarMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 541, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(159, 159, 159))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonActualizarMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(botonEliminarMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(217, 217, 217))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filtroMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel35)
                        .addGap(8, 8, 8)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(27, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout InterfazMetodosLayout = new javax.swing.GroupLayout(InterfazMetodos);
        InterfazMetodos.setLayout(InterfazMetodosLayout);
        InterfazMetodosLayout.setHorizontalGroup(
            InterfazMetodosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazMetodosLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        InterfazMetodosLayout.setVerticalGroup(
            InterfazMetodosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazMetodosLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(InterfazMetodosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        Pestañas.addTab("", InterfazMetodos);

        InterfazUsuarios.setBackground(new java.awt.Color(255, 255, 255));

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel30.setFont(new java.awt.Font("Tw Cen MT", 1, 32)); // NOI18N
        jLabel30.setText("NUEVO");

        botonCancelarUsuario.setBackground(new java.awt.Color(255, 51, 51));
        botonCancelarUsuario.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonCancelarUsuario.setForeground(new java.awt.Color(255, 255, 255));
        botonCancelarUsuario.setText("CANCELAR");
        botonCancelarUsuario.setBorder(null);
        botonCancelarUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCancelarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarUsuarioActionPerformed(evt);
            }
        });

        jLabel31.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel31.setText("Usuario:");

        jLabel32.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel32.setText("Contraseña:");

        txtUsuario.setForeground(java.awt.Color.gray);
        txtUsuario.setText("Ingresa el Usuario");
        txtUsuario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtUsuarioFocusGained(evt);
            }
        });
        txtUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtUsuarioMousePressed(evt);
            }
        });
        txtUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsuarioActionPerformed(evt);
            }
        });

        botonGuardarusuario.setBackground(new java.awt.Color(51, 153, 0));
        botonGuardarusuario.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonGuardarusuario.setForeground(new java.awt.Color(255, 255, 255));
        botonGuardarusuario.setText("GUARDAR");
        botonGuardarusuario.setBorder(null);
        botonGuardarusuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonGuardarusuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarusuarioActionPerformed(evt);
            }
        });
        botonGuardarusuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                botonGuardarusuarioKeyPressed(evt);
            }
        });

        txtContraseñaUsuario.setForeground(java.awt.Color.gray);
        txtContraseñaUsuario.setText("************");
        txtContraseñaUsuario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtContraseñaUsuarioFocusGained(evt);
            }
        });
        txtContraseñaUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtContraseñaUsuarioMousePressed(evt);
            }
        });

        CheckClientes.setFont(new java.awt.Font("Jokerman", 0, 18)); // NOI18N
        CheckClientes.setText("Clientes");
        CheckClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckClientesActionPerformed(evt);
            }
        });
        CheckClientes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CheckClientesKeyPressed(evt);
            }
        });

        CheckEmpleados.setFont(new java.awt.Font("Jokerman", 0, 18)); // NOI18N
        CheckEmpleados.setText("Empleados");
        CheckEmpleados.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CheckEmpleadosKeyPressed(evt);
            }
        });

        CheckVentas.setFont(new java.awt.Font("Jokerman", 0, 18)); // NOI18N
        CheckVentas.setText("Ventas");
        CheckVentas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CheckVentasKeyPressed(evt);
            }
        });

        CheckCompras.setFont(new java.awt.Font("Jokerman", 0, 18)); // NOI18N
        CheckCompras.setText("Compras");
        CheckCompras.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CheckComprasKeyPressed(evt);
            }
        });

        CheckInventario.setFont(new java.awt.Font("Jokerman", 0, 18)); // NOI18N
        CheckInventario.setText("Inventario");
        CheckInventario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CheckInventarioKeyPressed(evt);
            }
        });

        CheckProveedores.setFont(new java.awt.Font("Jokerman", 0, 18)); // NOI18N
        CheckProveedores.setText("Proveedores");
        CheckProveedores.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CheckProveedoresKeyPressed(evt);
            }
        });

        CheckFinanzas.setFont(new java.awt.Font("Jokerman", 0, 18)); // NOI18N
        CheckFinanzas.setText("Finanzas");
        CheckFinanzas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CheckFinanzasKeyPressed(evt);
            }
        });

        CheckMetodos.setFont(new java.awt.Font("Jokerman", 0, 18)); // NOI18N
        CheckMetodos.setText("Métodos \nde Pago");
        CheckMetodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckMetodosActionPerformed(evt);
            }
        });
        CheckMetodos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CheckMetodosKeyPressed(evt);
            }
        });

        jLabel42.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        jLabel42.setText("Permisos");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(169, 169, 169))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jSeparator11, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel32)
                                    .addComponent(jLabel31))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                                    .addComponent(txtContraseñaUsuario)))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(85, 85, 85)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(CheckClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(CheckInventario)
                                            .addComponent(CheckVentas)
                                            .addComponent(CheckProveedores))
                                        .addGap(56, 56, 56)
                                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(CheckCompras)
                                            .addComponent(CheckFinanzas)
                                            .addComponent(CheckEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(CheckMetodos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addComponent(botonCancelarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(40, 40, 40)
                                        .addComponent(botonGuardarusuario, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(194, 194, 194)
                        .addComponent(jLabel42)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31))
                .addGap(46, 46, 46)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(txtContraseñaUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(jSeparator11, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel42)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CheckClientes)
                    .addComponent(CheckEmpleados))
                .addGap(40, 40, 40)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CheckVentas)
                    .addComponent(CheckCompras))
                .addGap(46, 46, 46)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CheckInventario)
                    .addComponent(CheckFinanzas))
                .addGap(40, 40, 40)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CheckProveedores)
                    .addComponent(CheckMetodos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 98, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonCancelarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonGuardarusuario, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel36.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel36.setText("USUARIOS");

        tablaUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(tablaUsuario);

        botonActualizarUsuario.setBackground(new java.awt.Color(229, 229, 0));
        botonActualizarUsuario.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonActualizarUsuario.setForeground(new java.awt.Color(255, 255, 255));
        botonActualizarUsuario.setText("Actualizar");
        botonActualizarUsuario.setBorder(null);
        botonActualizarUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonActualizarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarUsuarioActionPerformed(evt);
            }
        });

        botonEliminarUsuario.setBackground(new java.awt.Color(239, 18, 29));
        botonEliminarUsuario.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 18)); // NOI18N
        botonEliminarUsuario.setForeground(new java.awt.Color(255, 255, 255));
        botonEliminarUsuario.setText("Eliminar");
        botonEliminarUsuario.setBorder(null);
        botonEliminarUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonEliminarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarUsuarioActionPerformed(evt);
            }
        });

        filtroUsuario.setForeground(java.awt.Color.gray);
        filtroUsuario.setText("Ingresa la busqueda");
        filtroUsuario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                filtroUsuarioFocusGained(evt);
            }
        });
        filtroUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                filtroUsuarioMousePressed(evt);
            }
        });
        filtroUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtroUsuarioActionPerformed(evt);
            }
        });
        filtroUsuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                filtroUsuarioKeyReleased(evt);
            }
        });

        jLabel40.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        jLabel40.setText("Filtrar:");

        jLabel41.setText("*Recuerde que el usuario no puede actualizarce");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(jLabel41)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGap(154, 154, 154)
                                .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 693, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(filtroUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 723, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonActualizarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonEliminarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))))
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(369, 369, 369)
                .addComponent(jLabel36)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonActualizarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(botonEliminarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(217, 217, 217))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filtroUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel41)
                        .addGap(8, 8, 8)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(87, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout InterfazUsuariosLayout = new javax.swing.GroupLayout(InterfazUsuarios);
        InterfazUsuarios.setLayout(InterfazUsuariosLayout);
        InterfazUsuariosLayout.setHorizontalGroup(
            InterfazUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazUsuariosLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        InterfazUsuariosLayout.setVerticalGroup(
            InterfazUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InterfazUsuariosLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(InterfazUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Pestañas.addTab("", InterfazUsuarios);

        javax.swing.GroupLayout EscritorioLayout = new javax.swing.GroupLayout(Escritorio);
        Escritorio.setLayout(EscritorioLayout);
        EscritorioLayout.setHorizontalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Pestañas)
                .addGap(63, 63, 63))
        );
        EscritorioLayout.setVerticalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Pestañas)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PanelIzquierdo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PanelSuperior, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Escritorio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelIzquierdo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PanelSuperior, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Escritorio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        
    }//GEN-LAST:event_btnHomeActionPerformed

    private void btnEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEmpleadosActionPerformed
        
    }//GEN-LAST:event_btnEmpleadosActionPerformed

    private void btnClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClientesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnClientesActionPerformed

    private void btnHomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseClicked
        Pestañas.setSelectedIndex(0);
    }//GEN-LAST:event_btnHomeMouseClicked

    private void btnClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClientesMouseClicked
        Pestañas.setSelectedIndex(1);
    }//GEN-LAST:event_btnClientesMouseClicked

    private void btnHomeMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseMoved
       panelHome.setBackground(new Color(51,51,51));
    }//GEN-LAST:event_btnHomeMouseMoved

    private void panelHomeMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelHomeMouseMoved
        
    }//GEN-LAST:event_panelHomeMouseMoved

    private void panelHomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelHomeMouseExited
        
    }//GEN-LAST:event_panelHomeMouseExited

    private void btnHomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseExited
        panelHome.setBackground(new Color(28,32,32));
    }//GEN-LAST:event_btnHomeMouseExited

    private void btnClientesMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClientesMouseMoved
        panelClientes.setBackground(new Color(51,51,51));
    }//GEN-LAST:event_btnClientesMouseMoved

    private void btnClientesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClientesMouseExited
        panelClientes.setBackground(new Color(28,32,32));
    }//GEN-LAST:event_btnClientesMouseExited

    private void btnVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVentasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnVentasActionPerformed

    private void btnVentasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVentasMouseClicked
        Pestañas.setSelectedIndex(2);
    }//GEN-LAST:event_btnVentasMouseClicked

    private void btnVentasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVentasMouseExited
        panelVentas.setBackground(new Color(28,32,32));
    }//GEN-LAST:event_btnVentasMouseExited

    private void btnVentasMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVentasMouseMoved
        panelVentas.setBackground(new Color(51,51,51));
    }//GEN-LAST:event_btnVentasMouseMoved

    private void btnComprasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnComprasMouseClicked
        Pestañas.setSelectedIndex(3);
    }//GEN-LAST:event_btnComprasMouseClicked

    private void btnComprasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnComprasMouseExited
        panelCompras.setBackground(new Color(28,32,32));
    }//GEN-LAST:event_btnComprasMouseExited

    private void btnComprasMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnComprasMouseMoved
        panelCompras.setBackground(new Color(51,51,51));
    }//GEN-LAST:event_btnComprasMouseMoved

    private void btnInventarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnInventarioMouseClicked
        Pestañas.setSelectedIndex(4);
    }//GEN-LAST:event_btnInventarioMouseClicked

    private void btnInventarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnInventarioMouseExited
        panelInventario.setBackground(new Color(28,32,32));
    }//GEN-LAST:event_btnInventarioMouseExited

    private void btnInventarioMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnInventarioMouseMoved
        panelInventario.setBackground(new Color(51,51,51));
    }//GEN-LAST:event_btnInventarioMouseMoved

    private void btnFinanzasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFinanzasMouseClicked
        Pestañas.setSelectedIndex(5);
    }//GEN-LAST:event_btnFinanzasMouseClicked

    private void btnFinanzasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFinanzasMouseExited
        panelFinanzas.setBackground(new Color(28,32,32));
    }//GEN-LAST:event_btnFinanzasMouseExited

    private void btnFinanzasMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFinanzasMouseMoved
        panelFinanzas.setBackground(new Color(51,51,51));
    }//GEN-LAST:event_btnFinanzasMouseMoved

    private void btnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseClicked
        
        LOGIN login = new LOGIN();
        this.setVisible(false);
        login.setVisible(true);
        
        
    }//GEN-LAST:event_btnSalirMouseClicked

    private void btnSalirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseExited
        panelSalir.setBackground(new Color(28,32,32));
    }//GEN-LAST:event_btnSalirMouseExited

    private void btnSalirMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseMoved
        panelSalir.setBackground(new Color(51,51,51));
    }//GEN-LAST:event_btnSalirMouseMoved

    private void btnEmpleadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmpleadosMouseClicked
        Pestañas.setSelectedIndex(6);
    }//GEN-LAST:event_btnEmpleadosMouseClicked

    private void btnEmpleadosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmpleadosMouseExited
        panelEmpleados.setBackground(new Color(255,255,255));
    }//GEN-LAST:event_btnEmpleadosMouseExited

    private void btnEmpleadosMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEmpleadosMouseMoved
        panelEmpleados.setBackground(new Color(240,240,240));
    }//GEN-LAST:event_btnEmpleadosMouseMoved

    private void btnProveedoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnProveedoresMouseClicked
        Pestañas.setSelectedIndex(7);
    }//GEN-LAST:event_btnProveedoresMouseClicked

    private void btnProveedoresMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnProveedoresMouseExited
        panelProveedores.setBackground(new Color(255,255,255));
    }//GEN-LAST:event_btnProveedoresMouseExited

    private void btnProveedoresMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnProveedoresMouseMoved
        panelProveedores.setBackground(new Color(240,240,240));
    }//GEN-LAST:event_btnProveedoresMouseMoved

    private void btnMetodosPagoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMetodosPagoMouseClicked
        Pestañas.setSelectedIndex(8);
    }//GEN-LAST:event_btnMetodosPagoMouseClicked

    private void btnMetodosPagoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMetodosPagoMouseExited
        panelMetodos.setBackground(new Color(255,255,255));
    }//GEN-LAST:event_btnMetodosPagoMouseExited

    private void btnMetodosPagoMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMetodosPagoMouseMoved
        panelMetodos.setBackground(new Color(240,240,240));
    }//GEN-LAST:event_btnMetodosPagoMouseMoved

    private void btnUsuariosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUsuariosMouseExited
        panelConexion.setBackground(new Color(255,255,255));
    }//GEN-LAST:event_btnUsuariosMouseExited

    private void btnUsuariosMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUsuariosMouseMoved
        panelConexion.setBackground(new Color(240,240,240));
    }//GEN-LAST:event_btnUsuariosMouseMoved

    private void botonEliminarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarClienteActionPerformed
        
        try {
            int fila = tablaCliente.getSelectedRow(); // Se obtiene la fila seleccionada en la tabla de clientes
            String valor = tablaCliente.getValueAt(fila, 0).toString(); // Se obtiene el valor de la columna de documento de la fila seleccionada
            Cliente.EliminarCliente(valor); // Se llama al método para eliminar el cliente con el documento seleccionado
            mostrarClientes(); // Se actualiza la tabla de clientes después de eliminar
        } catch (Exception e) { // Se captura cualquier excepción
            Object enunciado = "No se eliminó ningún Cliente"; // Mensaje de advertencia
            JOptionPane.showMessageDialog(null, enunciado, "Mensaje de Advertencia", JOptionPane.WARNING_MESSAGE); // Se muestra el mensaje de advertencia al usuario
        }
    }//GEN-LAST:event_botonEliminarClienteActionPerformed

    private void botonCancelarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarClienteActionPerformed
        
        // Se establecen los textos predeterminados en los campos de texto para el cliente
        txtDocumentoCliente.setText("Ingresa el Documento");
        txtNombreCliente.setText("Ingresa el Nombre");
        txtEmailCliente.setText("Ingresa el Email");
        txtDireccionCliente.setText("Ingresa la Dirección");
        txtCelularCliente.setText("Ingresa el Celular");

        // Se establece el color gris para los textos predeterminados en los campos de texto para el cliente
        this.txtDocumentoCliente.setForeground(Color.gray);
        this.txtNombreCliente.setForeground(Color.gray);
        this.txtEmailCliente.setForeground(Color.gray);
        this.txtDireccionCliente.setForeground(Color.gray);
        this.txtCelularCliente.setForeground(Color.gray);
    }//GEN-LAST:event_botonCancelarClienteActionPerformed

    private void botonActualizarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarClienteActionPerformed
        
        try{
            // Se obtiene la fila seleccionada en la tabla de clientes
            int fila = tablaCliente.getSelectedRow();

            // Se obtienen los valores de las celdas de la fila seleccionada y se convierten al tipo correspondiente
            int pDocumento = Integer.parseInt(this.tablaCliente.getValueAt(fila, 0).toString());
            String pNombre = tablaCliente.getValueAt(fila, 1).toString().toUpperCase();
            String pCorreoElectronico = tablaCliente.getValueAt(fila, 2).toString().toUpperCase();
            String pDireccion = tablaCliente.getValueAt(fila, 3).toString().toUpperCase();
            String pCelular = tablaCliente.getValueAt(fila, 4).toString().toUpperCase();

            // Se llama al método para actualizar cliente con los valores obtenidos y se vuelve a mostrar la lista de clientes actualizada
            Cliente.ActualizarCliente(pDocumento, pNombre, pCorreoElectronico, pDireccion, pCelular);
            mostrarClientes();
        }
        catch(Exception e){
            // Se define un mensaje de advertencia
            Object enunciado = "No se actualizó ningún Cliente";

            // Se muestra el mensaje de advertencia al usuario
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia", JOptionPane.WARNING_MESSAGE);

            // Se vuelve a mostrar la lista de clientes actualizada en la tabla
            mostrarClientes();    
        }
    }//GEN-LAST:event_botonActualizarClienteActionPerformed

    private void filtroClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filtroClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_filtroClienteActionPerformed

    private void txtDocumentoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDocumentoClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDocumentoClienteActionPerformed

    private void botonGuardarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarClienteActionPerformed
        
        try{
            int DocumentoCliente = Integer.parseInt(txtDocumentoCliente.getText());
            String NombreCliente = txtNombreCliente.getText().toUpperCase();
            String EmailCliente = txtEmailCliente.getText().toUpperCase();
            String DireccionCliente = txtDireccionCliente.getText().toUpperCase();
            String CelularCliente = txtCelularCliente.getText().toUpperCase();
            
            
            if(NombreCliente.equals("INGRESA EL NOMBRE") || EmailCliente.equals("INGRESA EL EMAIL") || DireccionCliente.equals("INGRESA LA DIRECCIÓN") || CelularCliente.equals("INGRESA EL CELULAR") ){
                Object enunciado = "Ingrese todos los campos";
                JOptionPane.showMessageDialog(null, enunciado , "Error",JOptionPane.ERROR_MESSAGE);
                
            }
            else{
                Cliente.IngresarCliente(DocumentoCliente, NombreCliente, EmailCliente, DireccionCliente, CelularCliente);
            }
            
            

            txtDocumentoCliente.setText("Ingresa el Documento");
            txtNombreCliente.setText("Ingresa el Nombre");
            txtEmailCliente.setText("Ingresa el Email");
            txtDireccionCliente.setText("Ingresa la Dirección");
            txtCelularCliente.setText("Ingresa el Celular");

            this.txtDocumentoCliente.setForeground(Color.gray);
            this.txtNombreCliente.setForeground(Color.gray);
            this.txtEmailCliente.setForeground(Color.gray);
            this.txtDireccionCliente.setForeground(Color.gray);
            this.txtCelularCliente.setForeground(Color.gray);

            mostrarClientes();
        }
        catch(Exception e){
            Object enunciado = "No se ingresó ningún Cliente";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
            
            txtDocumentoCliente.setText("Ingresa el Documento");
            txtNombreCliente.setText("Ingresa el Nombre");
            txtEmailCliente.setText("Ingresa el Email");
            txtDireccionCliente.setText("Ingresa la Dirección");
            txtCelularCliente.setText("Ingresa el Celular");

            this.txtDocumentoCliente.setForeground(Color.gray);
            this.txtNombreCliente.setForeground(Color.gray);
            this.txtEmailCliente.setForeground(Color.gray);
            this.txtDireccionCliente.setForeground(Color.gray);
            this.txtCelularCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_botonGuardarClienteActionPerformed

    private void txtEmailClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailClienteActionPerformed

    private void txtDocumentoClienteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDocumentoClienteMousePressed
        if (this.txtDocumentoCliente.getText().equals("Ingresa el Documento")) {
            this.txtDocumentoCliente.setText("");
            this.txtDocumentoCliente.setForeground(Color.black);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDocumentoClienteMousePressed

    private void txtNombreClienteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtNombreClienteMousePressed
        if (this.txtNombreCliente.getText().equals("Ingresa el Nombre")) {
            this.txtNombreCliente.setText("");
            this.txtNombreCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtNombreClienteMousePressed

    private void txtEmailClienteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEmailClienteMousePressed
        if (this.txtEmailCliente.getText().equals("Ingresa el Email")) {
            this.txtEmailCliente.setText("");
            this.txtEmailCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtEmailClienteMousePressed

    private void txtDireccionClienteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDireccionClienteMousePressed
        if (this.txtDireccionCliente.getText().equals("Ingresa la Dirección")) {
            this.txtDireccionCliente.setText("");
            this.txtDireccionCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDireccionClienteMousePressed

    private void txtCelularClienteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCelularClienteMousePressed
        if (this.txtCelularCliente.getText().equals("Ingresa el Celular")) {
            this.txtCelularCliente.setText("");
            this.txtCelularCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtCelularClienteMousePressed

    private void filtroClienteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filtroClienteMousePressed

        if (this.filtroCliente.getText().equals("Ingresa la busqueda")) {
            this.filtroCliente.setText("");
            this.filtroCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroClienteMousePressed

    private void botonCancelarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarEmpleadoActionPerformed
        txtIdentificacionEmpleado.setText("Ingresa la Identificación");
        txtNombreEmpleado.setText("Ingresa el Nombre");
        txtCargoEmpleado.setText("Ingresa el Cargo");
        txtSalarioEmpleado.setText("000000.00");
        txtEmailEmpleado.setText("Ingresa el Email");
        txtDireccionEmpleado.setText("Ingresa la Dirección");
        txtCelularEmpleado.setText("Ingresa el Celular");
        
        this.txtIdentificacionEmpleado.setForeground(Color.gray);
        this.txtNombreEmpleado.setForeground(Color.gray);
        this.txtCargoEmpleado.setForeground(Color.gray);
        this.txtSalarioEmpleado.setForeground(Color.gray);
        this.txtEmailEmpleado.setForeground(Color.gray);
        this.txtDireccionEmpleado.setForeground(Color.gray);
        this.txtCelularEmpleado.setForeground(Color.gray);
    }//GEN-LAST:event_botonCancelarEmpleadoActionPerformed

    private void txtIdentificacionEmpleadoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtIdentificacionEmpleadoMousePressed
        if (this.txtIdentificacionEmpleado.getText().equals("Ingresa la Identificación")) {
            this.txtIdentificacionEmpleado.setText("");
            this.txtIdentificacionEmpleado.setForeground(Color.black);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtIdentificacionEmpleadoMousePressed

    private void txtIdentificacionEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdentificacionEmpleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdentificacionEmpleadoActionPerformed

    private void txtNombreEmpleadoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtNombreEmpleadoMousePressed
        if (this.txtNombreEmpleado.getText().equals("Ingresa el Nombre")) {
            this.txtNombreEmpleado.setText("");
            this.txtNombreEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtNombreEmpleadoMousePressed

    private void txtCargoEmpleadoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCargoEmpleadoMousePressed
        if (this.txtCargoEmpleado.getText().equals("Ingresa el Cargo")) {
            this.txtCargoEmpleado.setText("");
            this.txtCargoEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtCargoEmpleadoMousePressed

    private void txtCargoEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCargoEmpleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCargoEmpleadoActionPerformed

    private void txtEmailEmpleadoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEmailEmpleadoMousePressed
        if (this.txtEmailEmpleado.getText().equals("Ingresa el Email")) {
            this.txtEmailEmpleado.setText("");
            this.txtEmailEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtEmailEmpleadoMousePressed

    private void txtSalarioEmpleadoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSalarioEmpleadoMousePressed
        if (this.txtSalarioEmpleado.getText().equals("000000.00")) {
            this.txtSalarioEmpleado.setText("");
            this.txtSalarioEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtSalarioEmpleadoMousePressed

    private void botonGuardarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarEmpleadoActionPerformed
        try{
            int IdentificacionEmpleado = Integer.parseInt(txtIdentificacionEmpleado.getText());
            String NombreEmpleado = txtNombreEmpleado.getText().toUpperCase();
            String CargoEmpleado = txtCargoEmpleado.getText().toUpperCase();
            double SalarioEmpleado = Double.parseDouble(txtSalarioEmpleado.getText());
            String EmailEmpleado = txtEmailEmpleado.getText().toUpperCase();
            String DireccionEmpleado = txtDireccionEmpleado.getText().toUpperCase();
            String CelularEmpleado = txtCelularEmpleado.getText().toUpperCase();           
            
            if(NombreEmpleado.equals("INGRESA EL NOMBRE") || CargoEmpleado.equals("INGRESA EL CARGO") || SalarioEmpleado == 0
                    || EmailEmpleado.equals("INGRESA EL EMAIL") || DireccionEmpleado.equals("INGRESA LA DIRECCIÓN") || CelularEmpleado.equals("INGRESA EL CELULAR")){
                Object enunciado = "Ingrese todos los campos";
                JOptionPane.showMessageDialog(null, enunciado , "Error",JOptionPane.ERROR_MESSAGE);
                
            }
            else{
                if (SalarioEmpleado < 0) {
                    Object enunciado2 = "El salario no puede ser menor a 0";
                    JOptionPane.showMessageDialog(null, enunciado2 , "Error",JOptionPane.ERROR_MESSAGE);
                }else{
                    Empleado.IngresarEmpleado(IdentificacionEmpleado, NombreEmpleado, CargoEmpleado, SalarioEmpleado, EmailEmpleado, DireccionEmpleado, CelularEmpleado);
                }
                
            }
            
            
            
            txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            txtNombreEmpleado.setText("Ingresa el Nombre");
            txtCargoEmpleado.setText("Ingresa el Cargo");
            txtSalarioEmpleado.setText("000000.00");
            txtEmailEmpleado.setText("Ingresa el Email");
            txtDireccionEmpleado.setText("Ingresa la Dirección");
            txtCelularEmpleado.setText("Ingresa el Celular");

            this.txtIdentificacionEmpleado.setForeground(Color.gray);
            this.txtNombreEmpleado.setForeground(Color.gray);
            this.txtCargoEmpleado.setForeground(Color.gray);
            this.txtSalarioEmpleado.setForeground(Color.gray);
            this.txtEmailEmpleado.setForeground(Color.gray);
            this.txtDireccionEmpleado.setForeground(Color.gray);
            this.txtCelularEmpleado.setForeground(Color.gray);
            
            mostrarEmpleados();
            
        }catch(Exception e){
            Object enunciado = "No se ingresó ningún Empleado";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);            
            
            txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            txtNombreEmpleado.setText("Ingresa el Nombre");
            txtCargoEmpleado.setText("Ingresa el Cargo");
            txtSalarioEmpleado.setText("000000.00");
            txtEmailEmpleado.setText("Ingresa el Email");
            txtDireccionEmpleado.setText("Ingresa la Dirección");
            txtCelularEmpleado.setText("Ingresa el Celular");

            this.txtIdentificacionEmpleado.setForeground(Color.gray);
            this.txtNombreEmpleado.setForeground(Color.gray);
            this.txtCargoEmpleado.setForeground(Color.gray);
            this.txtSalarioEmpleado.setForeground(Color.gray);
            this.txtEmailEmpleado.setForeground(Color.gray);
            this.txtDireccionEmpleado.setForeground(Color.gray);
            this.txtCelularEmpleado.setForeground(Color.gray);
            
            
        }
             
    }//GEN-LAST:event_botonGuardarEmpleadoActionPerformed

    private void botonActualizarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarEmpleadoActionPerformed
        try{
            int fila = tablaEmpleado.getSelectedRow();

            int pIdentificacion = Integer.parseInt(this.tablaEmpleado.getValueAt(fila, 0).toString());
            String pNombre = tablaEmpleado.getValueAt(fila, 1).toString().toUpperCase();
            String pCargo = tablaEmpleado.getValueAt(fila, 2).toString().toUpperCase();
            double pSalario = Double.parseDouble(tablaEmpleado.getValueAt(fila, 3).toString());
            String pCorreoElectronico = tablaEmpleado.getValueAt(fila, 4).toString().toUpperCase();
            String pDireccion = tablaEmpleado.getValueAt(fila, 5).toString().toUpperCase();
            String pCelular = tablaEmpleado.getValueAt(fila, 6).toString().toUpperCase();
            
            
            Empleado.ActualizarEmpleado(pIdentificacion, pNombre, pCargo, pSalario, pCorreoElectronico, pDireccion, pCelular);
            mostrarEmpleados();
        }
        catch(Exception e){
            Object enunciado = "No se actualizó ningún Empleado";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
            mostrarEmpleados();
            
        }
    }//GEN-LAST:event_botonActualizarEmpleadoActionPerformed

    private void botonEliminarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarEmpleadoActionPerformed
        try{
            int fila = tablaEmpleado.getSelectedRow();
            String valor = tablaEmpleado.getValueAt(fila, 0).toString();
            Empleado.EliminarEmpleado(valor);
            mostrarEmpleados();
        }
        catch(Exception e){
            Object enunciado = "No se eliminó ningún Empleado";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_botonEliminarEmpleadoActionPerformed

    private void filtroEmpleadoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filtroEmpleadoMousePressed
        if (this.filtroEmpleado.getText().equals("Ingresa la busqueda")) {
            this.filtroEmpleado.setText("");
            this.filtroEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa el Documento");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroEmpleadoMousePressed

    private void filtroEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filtroEmpleadoActionPerformed
        
    }//GEN-LAST:event_filtroEmpleadoActionPerformed

    private void txtCelularEmpleadoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCelularEmpleadoMousePressed
        if (this.txtCelularEmpleado.getText().equals("Ingresa el Celular")) {
            this.txtCelularEmpleado.setText("");
            this.txtCelularEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtCelularEmpleadoMousePressed

    private void txtDireccionEmpleadoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDireccionEmpleadoMousePressed
        if (this.txtDireccionEmpleado.getText().equals("Ingresa la Dirección")) {
            this.txtDireccionEmpleado.setText("");
            this.txtDireccionEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDireccionEmpleadoMousePressed

    private void filtroClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filtroClienteKeyReleased
        filtrarClientes();
    }//GEN-LAST:event_filtroClienteKeyReleased

    private void btnFinanzasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinanzasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFinanzasActionPerformed

    private void botonCancelarProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarProveedorActionPerformed
        txtIdentificacionProveedor.setText("Ingresa la Identificación");
        txtEmpresaProveedor.setText("Ingresa la Empresa");
        txtDireccionProveedor.setText("Ingresa la Dirección");
        txtTelefonoProveedor.setText("Ingresa el Teléfono");
        txtEmailProveedor.setText("Ingresa el Email");
        
        this.txtIdentificacionProveedor.setForeground(Color.gray);
        this.txtEmpresaProveedor.setForeground(Color.gray);
        this.txtDireccionProveedor.setForeground(Color.gray);
        this.txtTelefonoProveedor.setForeground(Color.gray);
        this.txtEmailProveedor.setForeground(Color.gray);
    }//GEN-LAST:event_botonCancelarProveedorActionPerformed

    private void txtIdentificacionProveedorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtIdentificacionProveedorMousePressed
        if (this.txtIdentificacionProveedor.getText().equals("Ingresa la Identificación")) {
            this.txtIdentificacionProveedor.setText("");
            this.txtIdentificacionProveedor.setForeground(Color.black);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtIdentificacionProveedorMousePressed

    private void txtIdentificacionProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdentificacionProveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdentificacionProveedorActionPerformed

    private void txtEmpresaProveedorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEmpresaProveedorMousePressed
        if (this.txtEmpresaProveedor.getText().equals("Ingresa la Empresa")) {
            this.txtEmpresaProveedor.setText("");
            this.txtEmpresaProveedor.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa la Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtEmpresaProveedorMousePressed

    private void txtDireccionProveedorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDireccionProveedorMousePressed
        if (this.txtDireccionProveedor.getText().equals("Ingresa la Dirección")) {
            this.txtDireccionProveedor.setText("");
            this.txtDireccionProveedor.setForeground(Color.black);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa la Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDireccionProveedorMousePressed

    private void txtDireccionProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionProveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDireccionProveedorActionPerformed

    private void txtEmailProveedorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEmailProveedorMousePressed
        if (this.txtEmailProveedor.getText().equals("Ingresa el Email")) {
            this.txtEmailProveedor.setText("");
            this.txtEmailProveedor.setForeground(Color.black);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa la Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtEmailProveedorMousePressed

    private void txtTelefonoProveedorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTelefonoProveedorMousePressed
        if (this.txtTelefonoProveedor.getText().equals("Ingresa el Teléfono")) {
            this.txtTelefonoProveedor.setText("");
            this.txtTelefonoProveedor.setForeground(Color.black);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa el Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtTelefonoProveedorMousePressed

    private void botonGuardarProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarProveedorActionPerformed
        try{
            int IdentificacionProveedor = Integer.parseInt(txtIdentificacionProveedor.getText());
            String EmpresaProveedor = txtEmpresaProveedor.getText().toUpperCase();
            String DireccionProveedor = txtDireccionProveedor.getText().toUpperCase();
            String TelefonoProveedor = txtTelefonoProveedor.getText().toUpperCase();
            String EmailProveedor = txtEmailProveedor.getText().toUpperCase();
            
            
            if(EmpresaProveedor.equals("INGRESA LA EMPRESA") || DireccionProveedor.equals("INGRESA LA DIRECCIÓN") || TelefonoProveedor.equals("INGRESA EL TELÉFONO") || EmailProveedor.equals("INGRESA EL EMAIL") ){
                Object enunciado = "Ingrese todos los campos";
                JOptionPane.showMessageDialog(null, enunciado , "Error",JOptionPane.ERROR_MESSAGE);
                
            }
            else{
                Proveedor.IngresarProveedor(IdentificacionProveedor, EmpresaProveedor, DireccionProveedor, TelefonoProveedor, EmailProveedor);
            }
            
            

            txtIdentificacionProveedor.setText("Ingresa la Identificación");
            txtEmpresaProveedor.setText("Ingresa la Empresa");
            txtDireccionProveedor.setText("Ingresa la Dirección");
            txtTelefonoProveedor.setText("Ingresa el Teléfono");
            txtEmailProveedor.setText("Ingresa el Email");

            this.txtIdentificacionProveedor.setForeground(Color.gray);
            this.txtEmpresaProveedor.setForeground(Color.gray);
            this.txtDireccionProveedor.setForeground(Color.gray);
            this.txtTelefonoProveedor.setForeground(Color.gray);
            this.txtEmailProveedor.setForeground(Color.gray);

            mostrarProveedores();
        }
        catch(Exception e){
            Object enunciado = "No se ingresó ningún Proveedor";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
            
            txtIdentificacionProveedor.setText("Ingresa la Identificación");
            txtEmpresaProveedor.setText("Ingresa la Empresa");
            txtDireccionProveedor.setText("Ingresa la Dirección");
            txtTelefonoProveedor.setText("Ingresa el Teléfono");
            txtEmailProveedor.setText("Ingresa el Email");

            this.txtIdentificacionProveedor.setForeground(Color.gray);
            this.txtEmpresaProveedor.setForeground(Color.gray);
            this.txtDireccionProveedor.setForeground(Color.gray);
            this.txtTelefonoProveedor.setForeground(Color.gray);
            this.txtEmailProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_botonGuardarProveedorActionPerformed

    private void botonActualizarProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarProveedorActionPerformed
        
        try{
            int fila = tablaProveedor.getSelectedRow();

            int pIdProveedor = Integer.parseInt(this.tablaProveedor.getValueAt(fila, 0).toString());
            String pEmpresa = tablaProveedor.getValueAt(fila, 1).toString().toUpperCase();
            String pDireccion = tablaProveedor.getValueAt(fila, 2).toString().toUpperCase();
            String pTelefono = tablaProveedor.getValueAt(fila, 3).toString().toUpperCase();
            String pCorreoElectronico = tablaProveedor.getValueAt(fila, 4).toString().toUpperCase();
            String pObservaciones = tablaProveedor.getValueAt(fila, 5).toString().toUpperCase();
            
            
            Proveedor.ActualizarProveedor(pIdProveedor, pEmpresa, pDireccion, pTelefono, pCorreoElectronico, pObservaciones);
            mostrarProveedores();
        }
        catch(Exception e){
            Object enunciado = "No se actualizó ningún Proveedor";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
            mostrarProveedores();
            
        }
    }//GEN-LAST:event_botonActualizarProveedorActionPerformed

    private void botonEliminarProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarProveedorActionPerformed
        
        try{
            int fila = tablaProveedor.getSelectedRow();
            String valor = tablaProveedor.getValueAt(fila, 0).toString();
            Proveedor.EliminarProveedor(valor);
            mostrarProveedores();
        }
        catch(Exception e){
            Object enunciado = "No se eliminó ningún Proveedor";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_botonEliminarProveedorActionPerformed

    private void filtroProveedorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filtroProveedorMousePressed
        if (this.filtroProveedor.getText().equals("Ingresa la busqueda")) {
            this.filtroProveedor.setText("");
            this.filtroProveedor.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa la Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroProveedorMousePressed

    private void filtroProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filtroProveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_filtroProveedorActionPerformed

    private void filtroProveedorKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filtroProveedorKeyReleased
        filtrarProveedores();
    }//GEN-LAST:event_filtroProveedorKeyReleased

    private void txtEmpresaProveedorKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEmpresaProveedorKeyReleased
        
    }//GEN-LAST:event_txtEmpresaProveedorKeyReleased

    private void txtEmpresaProveedorKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEmpresaProveedorKeyTyped
        
    }//GEN-LAST:event_txtEmpresaProveedorKeyTyped

    private void txtEmpresaProveedorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEmpresaProveedorMouseEntered
        
    }//GEN-LAST:event_txtEmpresaProveedorMouseEntered

    private void txtEmpresaProveedorKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEmpresaProveedorKeyPressed
        
    }//GEN-LAST:event_txtEmpresaProveedorKeyPressed

    private void txtEmpresaProveedorInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtEmpresaProveedorInputMethodTextChanged
        
    }//GEN-LAST:event_txtEmpresaProveedorInputMethodTextChanged

    private void txtEmpresaProveedorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEmpresaProveedorMouseClicked
        
    }//GEN-LAST:event_txtEmpresaProveedorMouseClicked

    private void txtEmpresaProveedorMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEmpresaProveedorMouseReleased
        
    }//GEN-LAST:event_txtEmpresaProveedorMouseReleased

    private void botonCancelarMetodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarMetodoActionPerformed
        txtNombreMetodo.setText("Ingresa el Nombre");
        txtDetallesMetodo.setText("Ingresa los Detalles");
       
        this.txtNombreMetodo.setForeground(Color.gray);
        this.txtDetallesMetodo.setForeground(Color.gray);
    }//GEN-LAST:event_botonCancelarMetodoActionPerformed

    private void txtNombreMetodoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtNombreMetodoMousePressed
        if (this.txtNombreMetodo.getText().equals("Ingresa el Nombre")) {
            this.txtNombreMetodo.setText("");
            this.txtNombreMetodo.setForeground(Color.black);
        }
        
        if (this.txtDetallesMetodo.getText().isEmpty()) {
            this.txtDetallesMetodo.setText("Ingresa los Detalles");
            this.txtDetallesMetodo.setForeground(Color.gray);
        }
        
        if (this.filtroMetodo.getText().isEmpty()) {
            this.filtroMetodo.setText("Ingresa la busqueda");
            this.filtroMetodo.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtNombreMetodoMousePressed

    private void txtNombreMetodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreMetodoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreMetodoActionPerformed

    private void txtDetallesMetodoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDetallesMetodoMousePressed
        if (this.txtDetallesMetodo.getText().equals("Ingresa los Detalles")) {
            this.txtDetallesMetodo.setText("");
            this.txtDetallesMetodo.setForeground(Color.black);
        }
        
        if (this.txtNombreMetodo.getText().isEmpty()) {
            this.txtNombreMetodo.setText("Ingresa el Nombre");
            this.txtNombreMetodo.setForeground(Color.gray);
        }
        
        if (this.filtroMetodo.getText().isEmpty()) {
            this.filtroMetodo.setText("Ingresa la busqueda");
            this.filtroMetodo.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDetallesMetodoMousePressed

    private void botonGuardarMetodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarMetodoActionPerformed
        try{
            String NombreMetodo = txtNombreMetodo.getText().toUpperCase();
            String DetallesMetodo = txtDetallesMetodo.getText().toUpperCase();
            
            if(NombreMetodo.equals("INGRESA EL NOMBRE") || DetallesMetodo.equals("INGRESA LOS DETALLES") ){
                Object enunciado = "Ingrese todos los campos";
                JOptionPane.showMessageDialog(null, enunciado , "Error",JOptionPane.ERROR_MESSAGE);
                
            }
            else{
                Metodos.IngresarMetodos(NombreMetodo, DetallesMetodo);
            }

            txtNombreMetodo.setText("Ingresa el Nombre");
            txtDetallesMetodo.setText("Ingresa los Detalles");

            this.txtNombreMetodo.setForeground(Color.gray);
            this.txtDetallesMetodo.setForeground(Color.gray);

            mostrarMetodos();
        }
        catch(Exception e){
            Object enunciado = "No se ingresó ningún Método de Pago";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
            
            txtNombreMetodo.setText("Ingresa el Nombre");
            txtDetallesMetodo.setText("Ingresa los Detalles");

            this.txtNombreMetodo.setForeground(Color.gray);
            this.txtDetallesMetodo.setForeground(Color.gray);
        }
    }//GEN-LAST:event_botonGuardarMetodoActionPerformed

    private void botonActualizarMetodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarMetodoActionPerformed
        
        try{
            int fila = tablaMetodo.getSelectedRow();

            int pIdPago = Integer.parseInt(this.tablaMetodo.getValueAt(fila, 0).toString());
            String pNombre= tablaMetodo.getValueAt(fila, 1).toString().toUpperCase();
            String pDetalles = tablaMetodo.getValueAt(fila, 2).toString().toUpperCase();
            
            Metodos.ActualizarMetodo(pIdPago, pNombre, pDetalles);
            mostrarMetodos();
        }
        catch(Exception e){
            Object enunciado = "No se actualizó ningún Método de Pago";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
            mostrarMetodos();
            
        }
    }//GEN-LAST:event_botonActualizarMetodoActionPerformed

    private void botonEliminarMetodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarMetodoActionPerformed
        try{
            int fila = tablaMetodo.getSelectedRow();
            String valor = tablaMetodo.getValueAt(fila, 0).toString();
            Metodos.EliminarMetodo(valor);
            mostrarMetodos();
        }
        catch(Exception e){
            Object enunciado = "No se eliminó ningún Método de Pago";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_botonEliminarMetodoActionPerformed

    private void filtroMetodoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filtroMetodoMousePressed
        if (this.filtroMetodo.getText().equals("Ingresa la busqueda")) {
            this.filtroMetodo.setText("");
            this.filtroMetodo.setForeground(Color.black);
        }
        
        if (this.txtNombreMetodo.getText().isEmpty()) {
            this.txtNombreMetodo.setText("Ingresa el Nombre");
            this.txtNombreMetodo.setForeground(Color.gray);
        }
        
        if (this.txtDetallesMetodo.getText().isEmpty()) {
            this.txtDetallesMetodo.setText("Ingresa los Detalles");
            this.txtDetallesMetodo.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroMetodoMousePressed

    private void filtroMetodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filtroMetodoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_filtroMetodoActionPerformed

    private void filtroMetodoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filtroMetodoKeyReleased
        filtrarMetodos ();
    }//GEN-LAST:event_filtroMetodoKeyReleased

    private void txtDetallesMetodoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDetallesMetodoFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDetallesMetodoFocusLost

    private void txtDetallesMetodoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDetallesMetodoFocusGained
        if (this.txtDetallesMetodo.getText().equals("Ingresa los Detalles")) {
            this.txtDetallesMetodo.setText("");
            this.txtDetallesMetodo.setForeground(Color.black);
        }
        
        if (this.txtNombreMetodo.getText().isEmpty()) {
            this.txtNombreMetodo.setText("Ingresa el Nombre");
            this.txtNombreMetodo.setForeground(Color.gray);
        }
        
        if (this.filtroMetodo.getText().isEmpty()) {
            this.filtroMetodo.setText("Ingresa la busqueda");
            this.filtroMetodo.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDetallesMetodoFocusGained

    private void txtDocumentoClienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDocumentoClienteFocusGained
        if (this.txtDocumentoCliente.getText().equals("Ingresa el Documento")) {
            this.txtDocumentoCliente.setText("");
            this.txtDocumentoCliente.setForeground(Color.black);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDocumentoClienteFocusGained

    private void txtNombreClienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNombreClienteFocusGained
        if (this.txtNombreCliente.getText().equals("Ingresa el Nombre")) {
            this.txtNombreCliente.setText("");
            this.txtNombreCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtNombreClienteFocusGained

    private void txtEmailClienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtEmailClienteFocusGained
        if (this.txtEmailCliente.getText().equals("Ingresa el Email")) {
            this.txtEmailCliente.setText("");
            this.txtEmailCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtEmailClienteFocusGained

    private void txtDireccionClienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDireccionClienteFocusGained
        if (this.txtDireccionCliente.getText().equals("Ingresa la Dirección")) {
            this.txtDireccionCliente.setText("");
            this.txtDireccionCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDireccionClienteFocusGained

    private void txtCelularClienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCelularClienteFocusGained
        if (this.txtCelularCliente.getText().equals("Ingresa el Celular")) {
            this.txtCelularCliente.setText("");
            this.txtCelularCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.filtroCliente.getText().isEmpty()) {
            this.filtroCliente.setText("Ingresa la busqueda");
            this.filtroCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtCelularClienteFocusGained

    private void filtroClienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_filtroClienteFocusGained
        if (this.filtroCliente.getText().equals("Ingresa la busqueda")) {
            this.filtroCliente.setText("");
            this.filtroCliente.setForeground(Color.black);
        }
        
        if (this.txtDocumentoCliente.getText().isEmpty()) {
            this.txtDocumentoCliente.setText("Ingresa el Documento");
            this.txtDocumentoCliente.setForeground(Color.gray);
        }
        
        if (this.txtEmailCliente.getText().isEmpty()) {
            this.txtEmailCliente.setText("Ingresa el Email");
            this.txtEmailCliente.setForeground(Color.gray);
        }
        
        if (this.txtDireccionCliente.getText().isEmpty()) {
            this.txtDireccionCliente.setText("Ingresa la Dirección");
            this.txtDireccionCliente.setForeground(Color.gray);
        }
        
        if (this.txtNombreCliente.getText().isEmpty()) {
            this.txtNombreCliente.setText("Ingresa el Nombre");
            this.txtNombreCliente.setForeground(Color.gray);
        }
        
        if (this.txtCelularCliente.getText().isEmpty()) {
            this.txtCelularCliente.setText("Ingresa el Celular");
            this.txtCelularCliente.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroClienteFocusGained

    private void botonGuardarClienteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonGuardarClienteKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
            botonGuardarCliente.doClick();
        }
    }//GEN-LAST:event_botonGuardarClienteKeyPressed

    private void botonGuardarClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonGuardarClienteKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_botonGuardarClienteKeyReleased

    private void txtIdentificacionEmpleadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtIdentificacionEmpleadoFocusGained
        if (this.txtIdentificacionEmpleado.getText().equals("Ingresa la Identificación")) {
            this.txtIdentificacionEmpleado.setText("");
            this.txtIdentificacionEmpleado.setForeground(Color.black);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtIdentificacionEmpleadoFocusGained

    private void txtNombreEmpleadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNombreEmpleadoFocusGained
        if (this.txtNombreEmpleado.getText().equals("Ingresa el Nombre")) {
            this.txtNombreEmpleado.setText("");
            this.txtNombreEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtNombreEmpleadoFocusGained

    private void txtCargoEmpleadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCargoEmpleadoFocusGained
        if (this.txtCargoEmpleado.getText().equals("Ingresa el Cargo")) {
            this.txtCargoEmpleado.setText("");
            this.txtCargoEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtCargoEmpleadoFocusGained

    private void txtSalarioEmpleadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSalarioEmpleadoFocusGained
        if (this.txtSalarioEmpleado.getText().equals("000000.00")) {
            this.txtSalarioEmpleado.setText("");
            this.txtSalarioEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtSalarioEmpleadoFocusGained

    private void txtEmailEmpleadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtEmailEmpleadoFocusGained
        if (this.txtEmailEmpleado.getText().equals("Ingresa el Email")) {
            this.txtEmailEmpleado.setText("");
            this.txtEmailEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtEmailEmpleadoFocusGained

    private void txtDireccionEmpleadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDireccionEmpleadoFocusGained
        if (this.txtDireccionEmpleado.getText().equals("Ingresa la Dirección")) {
            this.txtDireccionEmpleado.setText("");
            this.txtDireccionEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDireccionEmpleadoFocusGained

    private void txtCelularEmpleadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCelularEmpleadoFocusGained
        if (this.txtCelularEmpleado.getText().equals("Ingresa el Celular")) {
            this.txtCelularEmpleado.setText("");
            this.txtCelularEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa la Identificación");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.filtroEmpleado.getText().isEmpty()) {
            this.filtroEmpleado.setText("Ingresa la busqueda");
            this.filtroEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtCelularEmpleadoFocusGained

    private void filtroEmpleadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_filtroEmpleadoFocusGained
        if (this.filtroEmpleado.getText().equals("Ingresa la busqueda")) {
            this.filtroEmpleado.setText("");
            this.filtroEmpleado.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionEmpleado.getText().isEmpty()) {
            this.txtIdentificacionEmpleado.setText("Ingresa el Documento");
            this.txtIdentificacionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtNombreEmpleado.getText().isEmpty()) {
            this.txtNombreEmpleado.setText("Ingresa el Nombre");
            this.txtNombreEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCargoEmpleado.getText().isEmpty()) {
            this.txtCargoEmpleado.setText("Ingresa el Cargo");
            this.txtCargoEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtSalarioEmpleado.getText().isEmpty()) {
            this.txtSalarioEmpleado.setText("000000.00");
            this.txtSalarioEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtEmailEmpleado.getText().isEmpty()) {
            this.txtEmailEmpleado.setText("Ingresa el Email");
            this.txtEmailEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtDireccionEmpleado.getText().isEmpty()) {
            this.txtDireccionEmpleado.setText("Ingresa la Dirección");
            this.txtDireccionEmpleado.setForeground(Color.gray);
        }
        
        if (this.txtCelularEmpleado.getText().isEmpty()) {
            this.txtCelularEmpleado.setText("Ingresa el Celular");
            this.txtCelularEmpleado.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroEmpleadoFocusGained

    private void botonGuardarEmpleadoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonGuardarEmpleadoKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
            botonGuardarEmpleado.doClick();
        }
    }//GEN-LAST:event_botonGuardarEmpleadoKeyPressed

    private void txtIdentificacionProveedorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtIdentificacionProveedorFocusGained
        if (this.txtIdentificacionProveedor.getText().equals("Ingresa la Identificación")) {
            this.txtIdentificacionProveedor.setText("");
            this.txtIdentificacionProveedor.setForeground(Color.black);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtIdentificacionProveedorFocusGained

    private void txtEmpresaProveedorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtEmpresaProveedorFocusGained
        if (this.txtEmpresaProveedor.getText().equals("Ingresa la Empresa")) {
            this.txtEmpresaProveedor.setText("");
            this.txtEmpresaProveedor.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa la Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtEmpresaProveedorFocusGained

    private void txtDireccionProveedorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDireccionProveedorFocusGained
        if (this.txtDireccionProveedor.getText().equals("Ingresa la Dirección")) {
            this.txtDireccionProveedor.setText("");
            this.txtDireccionProveedor.setForeground(Color.black);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa la Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtDireccionProveedorFocusGained

    private void txtTelefonoProveedorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTelefonoProveedorFocusGained
        if (this.txtTelefonoProveedor.getText().equals("Ingresa el Teléfono")) {
            this.txtTelefonoProveedor.setText("");
            this.txtTelefonoProveedor.setForeground(Color.black);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa el Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtTelefonoProveedorFocusGained

    private void txtEmailProveedorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtEmailProveedorFocusGained
        if (this.txtEmailProveedor.getText().equals("Ingresa el Email")) {
            this.txtEmailProveedor.setText("");
            this.txtEmailProveedor.setForeground(Color.black);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa la Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.filtroProveedor.getText().isEmpty()) {
            this.filtroProveedor.setText("Ingresa la busqueda");
            this.filtroProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtEmailProveedorFocusGained

    private void filtroProveedorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_filtroProveedorFocusGained
        if (this.filtroProveedor.getText().equals("Ingresa la busqueda")) {
            this.filtroProveedor.setText("");
            this.filtroProveedor.setForeground(Color.black);
        }
        
        if (this.txtIdentificacionProveedor.getText().isEmpty()) {
            this.txtIdentificacionProveedor.setText("Ingresa la Identificación");
            this.txtIdentificacionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmpresaProveedor.getText().isEmpty()) {
            this.txtEmpresaProveedor.setText("Ingresa la Empresa");
            this.txtEmpresaProveedor.setForeground(Color.gray);
        }
        
        if (this.txtDireccionProveedor.getText().isEmpty()) {
            this.txtDireccionProveedor.setText("Ingresa la Dirección");
            this.txtDireccionProveedor.setForeground(Color.gray);
        }
        
        if (this.txtTelefonoProveedor.getText().isEmpty()) {
            this.txtTelefonoProveedor.setText("Ingresa el Teléfono");
            this.txtTelefonoProveedor.setForeground(Color.gray);
        }
        
        if (this.txtEmailProveedor.getText().isEmpty()) {
            this.txtEmailProveedor.setText("Ingresa el Email");
            this.txtEmailProveedor.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroProveedorFocusGained

    private void botonGuardarProveedorKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonGuardarProveedorKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
            botonGuardarProveedor.doClick();
        }
    }//GEN-LAST:event_botonGuardarProveedorKeyPressed

    private void txtNombreMetodoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNombreMetodoFocusGained
        if (this.txtNombreMetodo.getText().equals("Ingresa el Nombre")) {
            this.txtNombreMetodo.setText("");
            this.txtNombreMetodo.setForeground(Color.black);
        }
        
        if (this.txtDetallesMetodo.getText().isEmpty()) {
            this.txtDetallesMetodo.setText("Ingresa los Detalles");
            this.txtDetallesMetodo.setForeground(Color.gray);
        }
        
        if (this.filtroMetodo.getText().isEmpty()) {
            this.filtroMetodo.setText("Ingresa la busqueda");
            this.filtroMetodo.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtNombreMetodoFocusGained

    private void filtroMetodoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_filtroMetodoFocusGained
        if (this.filtroMetodo.getText().equals("Ingresa la busqueda")) {
            this.filtroMetodo.setText("");
            this.filtroMetodo.setForeground(Color.black);
        }
        
        if (this.txtNombreMetodo.getText().isEmpty()) {
            this.txtNombreMetodo.setText("Ingresa el Nombre");
            this.txtNombreMetodo.setForeground(Color.gray);
        }
        
        if (this.txtDetallesMetodo.getText().isEmpty()) {
            this.txtDetallesMetodo.setText("Ingresa los Detalles");
            this.txtDetallesMetodo.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroMetodoFocusGained

    private void botonGuardarMetodoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonGuardarMetodoKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
            botonGuardarMetodo.doClick();
        }
    }//GEN-LAST:event_botonGuardarMetodoKeyPressed

    private void filtroEmpleadoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filtroEmpleadoKeyReleased
        filtrarEmpleados();
    }//GEN-LAST:event_filtroEmpleadoKeyReleased

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSalirActionPerformed

    private void txtEmailEmpleadoMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEmailEmpleadoMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailEmpleadoMouseReleased

    private void botonCancelarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarUsuarioActionPerformed
        txtUsuario.setText("Ingresa el Usuario");
        txtContraseñaUsuario.setText("************");
        CheckClientes.setSelected(false);
        CheckEmpleados.setSelected(false);
        CheckVentas.setSelected(false);
        CheckCompras.setSelected(false);
        CheckInventario.setSelected(false);
        CheckFinanzas.setSelected(false);
        CheckProveedores.setSelected(false);
        CheckMetodos.setSelected(false);
        
        
        this.txtUsuario.setForeground(Color.gray);
        this.txtContraseñaUsuario.setForeground(Color.gray);
    }//GEN-LAST:event_botonCancelarUsuarioActionPerformed

    private void txtUsuarioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtUsuarioFocusGained
        if (this.txtUsuario.getText().equals("Ingresa el Usuario")) {
            this.txtUsuario.setText("");
            this.txtUsuario.setForeground(Color.black);
        }
        
        if (String.valueOf(this.txtContraseñaUsuario.getPassword()).equals("")) {
            this.txtContraseñaUsuario.setText("************");
            this.txtContraseñaUsuario.setForeground(Color.gray);
        }
        
        if (this.filtroUsuario.getText().isEmpty()) {
            this.filtroUsuario.setText("Ingresa la busqueda");
            this.filtroUsuario.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtUsuarioFocusGained

    private void txtUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtUsuarioMousePressed
        if (this.txtUsuario.getText().equals("Ingresa el Usuario")) {
            this.txtUsuario.setText("");
            this.txtUsuario.setForeground(Color.black);
        }
        
        if (String.valueOf(this.txtContraseñaUsuario.getPassword()).equals("")) {
            this.txtContraseñaUsuario.setText("************");
            this.txtContraseñaUsuario.setForeground(Color.gray);
        }
        
        if (this.filtroUsuario.getText().isEmpty()) {
            this.filtroUsuario.setText("Ingresa la busqueda");
            this.filtroUsuario.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtUsuarioMousePressed

    private void txtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsuarioActionPerformed

    private void botonGuardarusuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarusuarioActionPerformed
        
        try{
            String Usuario = txtUsuario.getText();
            String Contraseña = String.valueOf(txtContraseñaUsuario.getPassword());
            boolean PermisoClientes = CheckClientes.isSelected();
            boolean PermisoEmpleados = CheckEmpleados.isSelected();
            boolean PermisoVentas = CheckVentas.isSelected();
            boolean PermisoCompras = CheckCompras.isSelected();
            boolean PermisoInventario = CheckInventario.isSelected();
            boolean PermisoFinanzas = CheckFinanzas.isSelected();
            boolean PermisoProveedores = CheckProveedores.isSelected();
            boolean PermisoMetodos = CheckMetodos.isSelected();
            
            
            if(Usuario.equals("Ingresa el Usuario") || String.valueOf(txtContraseñaUsuario.getPassword()).equals("************") ){
                Object enunciado = "Ingrese todos los campos";
                JOptionPane.showMessageDialog(null, enunciado , "Error",JOptionPane.ERROR_MESSAGE);
                
                txtUsuario.setText("Ingresa el Usuario");
                txtContraseñaUsuario.setText("************");
                CheckClientes.setSelected(false);
                CheckEmpleados.setSelected(false);
                CheckVentas.setSelected(false);
                CheckCompras.setSelected(false);
                CheckInventario.setSelected(false);
                CheckFinanzas.setSelected(false);
                CheckProveedores.setSelected(false);
                CheckMetodos.setSelected(false);


                this.txtUsuario.setForeground(Color.gray);
                this.txtContraseñaUsuario.setForeground(Color.gray);
                
            }
            else{
                Usuarios.IngresarUsuarios(Usuario, Contraseña, PermisoClientes, PermisoEmpleados, 
                        PermisoVentas, PermisoCompras, PermisoInventario, PermisoFinanzas, PermisoProveedores, PermisoMetodos);
                
                txtUsuario.setText("Ingresa el Usuario");
                txtContraseñaUsuario.setText("************");
                CheckClientes.setSelected(false);
                CheckEmpleados.setSelected(false);
                CheckVentas.setSelected(false);
                CheckCompras.setSelected(false);
                CheckInventario.setSelected(false);
                CheckFinanzas.setSelected(false);
                CheckProveedores.setSelected(false);
                CheckMetodos.setSelected(false);


                this.txtUsuario.setForeground(Color.gray);
                this.txtContraseñaUsuario.setForeground(Color.gray);
                
            }

            mostrarUsuarios();
        }
        catch(Exception e){
            Object enunciado = "No se ingresó ningún Usuario";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
            
        }
    }//GEN-LAST:event_botonGuardarusuarioActionPerformed

    private void botonGuardarusuarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonGuardarusuarioKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
            botonGuardarusuario.doClick();
        }
        
        txtUsuario.setText("Ingresa el Usuario");
        txtContraseñaUsuario.setText("************");
        CheckClientes.setSelected(false);
        CheckEmpleados.setSelected(false);
        CheckVentas.setSelected(false);
        CheckCompras.setSelected(false);
        CheckInventario.setSelected(false);
        CheckFinanzas.setSelected(false);
        CheckProveedores.setSelected(false);
        CheckMetodos.setSelected(false);
        
        
        this.txtUsuario.setForeground(Color.gray);
        this.txtContraseñaUsuario.setForeground(Color.gray);
    }//GEN-LAST:event_botonGuardarusuarioKeyPressed

    private void botonActualizarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarUsuarioActionPerformed
        try{
            int fila = tablaUsuario.getSelectedRow();

            int pIdUsuario = Integer.parseInt(this.tablaUsuario.getValueAt(fila, 0).toString());
            String pUsuario= tablaUsuario.getValueAt(fila, 1).toString();
            String pHash = tablaUsuario.getValueAt(fila, 2).toString();
            boolean pPermisoClientes = Boolean.parseBoolean(this.tablaUsuario.getValueAt(fila, 3).toString());
            boolean pPermisoEmpleados = Boolean.parseBoolean(this.tablaUsuario.getValueAt(fila, 4).toString());
            boolean pPermisoVentas = Boolean.parseBoolean(this.tablaUsuario.getValueAt(fila, 5).toString());
            boolean pPermisoCompras = Boolean.parseBoolean(this.tablaUsuario.getValueAt(fila, 6).toString());
            boolean pPermisoInventario = Boolean.parseBoolean(this.tablaUsuario.getValueAt(fila, 7).toString());
            boolean pPermisoFinanzas = Boolean.parseBoolean(this.tablaUsuario.getValueAt(fila, 8).toString());
            boolean pPermisoProveedores = Boolean.parseBoolean(this.tablaUsuario.getValueAt(fila, 9).toString());
            boolean pPermisoMetodos = Boolean.parseBoolean(this.tablaUsuario.getValueAt(fila, 10).toString());
            
            Usuarios.ActualizarUsuario(pIdUsuario, pUsuario, pHash, pPermisoClientes, pPermisoEmpleados, pPermisoVentas, pPermisoCompras, pPermisoInventario, pPermisoFinanzas, pPermisoProveedores, pPermisoMetodos);
            mostrarUsuarios();
        }
        catch(Exception e){
            Object enunciado = "No se actualizó ningún Usuario";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
            mostrarUsuarios();
            
        }
    }//GEN-LAST:event_botonActualizarUsuarioActionPerformed

    private void botonEliminarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarUsuarioActionPerformed
        try{
            int fila = tablaUsuario.getSelectedRow();
            String valor = tablaUsuario.getValueAt(fila, 0).toString();
            Usuarios.EliminarUsuario(valor);
            mostrarUsuarios();
        }
        catch(Exception e){
            Object enunciado = "No se eliminó ningún usuario";
            JOptionPane.showMessageDialog(null, enunciado , "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_botonEliminarUsuarioActionPerformed

    private void filtroUsuarioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_filtroUsuarioFocusGained
        if (this.filtroUsuario.getText().equals("Ingresa la busqueda")) {
            this.filtroUsuario.setText("");
            this.filtroUsuario.setForeground(Color.black);
        }
        
        if (this.txtUsuario.getText().isEmpty()) {
            this.txtUsuario.setText("Ingresa el Usuario");
            this.txtUsuario.setForeground(Color.gray);
        }
        
        if (String.valueOf(this.txtContraseñaUsuario.getPassword()).equals("")) {
            this.txtContraseñaUsuario.setText("************");
            this.txtContraseñaUsuario.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroUsuarioFocusGained

    private void filtroUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filtroUsuarioMousePressed
        if (this.filtroUsuario.getText().equals("Ingresa la busqueda")) {
            this.filtroUsuario.setText("");
            this.filtroUsuario.setForeground(Color.black);
        }
        
        if (this.txtUsuario.getText().isEmpty()) {
            this.txtUsuario.setText("Ingresa el Usuario");
            this.txtUsuario.setForeground(Color.gray);
        }
        
        if (String.valueOf(this.txtContraseñaUsuario.getPassword()).equals("")) {
            this.txtContraseñaUsuario.setText("************");
            this.txtContraseñaUsuario.setForeground(Color.gray);
        }
    }//GEN-LAST:event_filtroUsuarioMousePressed

    private void filtroUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filtroUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_filtroUsuarioActionPerformed

    private void filtroUsuarioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_filtroUsuarioKeyReleased
        filtrarUsuarios ();
    }//GEN-LAST:event_filtroUsuarioKeyReleased

    private void btnUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUsuariosMouseClicked
        Pestañas.setSelectedIndex(9);
    }//GEN-LAST:event_btnUsuariosMouseClicked

    private void CheckMetodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckMetodosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CheckMetodosActionPerformed

    private void CheckClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckClientesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CheckClientesActionPerformed

    private void btnComprasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnComprasActionPerformed

    private void txtContraseñaUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtContraseñaUsuarioMousePressed
        if (String.valueOf(this.txtContraseñaUsuario.getPassword()).equals("************")) {
            this.txtContraseñaUsuario.setText("");
            this.txtContraseñaUsuario.setForeground(Color.black);
        }
        
        if (this.txtUsuario.getText().isEmpty()) {
            this.txtUsuario.setText("Ingresa el Usuario");
            this.txtUsuario.setForeground(Color.gray);
        }
        
        if (this.filtroUsuario.getText().isEmpty()) {
            this.filtroUsuario.setText("Ingresa la busqueda");
            this.filtroUsuario.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtContraseñaUsuarioMousePressed

    private void txtContraseñaUsuarioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtContraseñaUsuarioFocusGained
        if (String.valueOf(this.txtContraseñaUsuario.getPassword()).equals("************")) {
            this.txtContraseñaUsuario.setText("");
            this.txtContraseñaUsuario.setForeground(Color.black);
        }
        
        if (this.txtUsuario.getText().isEmpty()) {
            this.txtUsuario.setText("Ingresa el Usuario");
            this.txtUsuario.setForeground(Color.gray);
        }
        
        if (this.filtroUsuario.getText().isEmpty()) {
            this.filtroUsuario.setText("Ingresa la busqueda");
            this.filtroUsuario.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txtContraseñaUsuarioFocusGained

    private void CheckClientesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CheckClientesKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
           CheckClientes.doClick();
        }
    }//GEN-LAST:event_CheckClientesKeyPressed

    private void CheckEmpleadosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CheckEmpleadosKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
           CheckEmpleados.doClick();
        }
    }//GEN-LAST:event_CheckEmpleadosKeyPressed

    private void CheckVentasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CheckVentasKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
           CheckVentas.doClick();
        }
    }//GEN-LAST:event_CheckVentasKeyPressed

    private void CheckComprasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CheckComprasKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
           CheckCompras.doClick();
        }
    }//GEN-LAST:event_CheckComprasKeyPressed

    private void CheckInventarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CheckInventarioKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
           CheckInventario.doClick();
        }
    }//GEN-LAST:event_CheckInventarioKeyPressed

    private void CheckFinanzasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CheckFinanzasKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
           CheckFinanzas.doClick();
        }
    }//GEN-LAST:event_CheckFinanzasKeyPressed

    private void CheckProveedoresKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CheckProveedoresKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
           CheckProveedores.doClick();
        }
    }//GEN-LAST:event_CheckProveedoresKeyPressed

    private void CheckMetodosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CheckMetodosKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            // Realiza la acción asociada al botón Aceptar
           CheckMetodos.doClick();
        }
    }//GEN-LAST:event_CheckMetodosKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox CheckClientes;
    private javax.swing.JCheckBox CheckCompras;
    private javax.swing.JCheckBox CheckEmpleados;
    private javax.swing.JCheckBox CheckFinanzas;
    private javax.swing.JCheckBox CheckInventario;
    private javax.swing.JCheckBox CheckMetodos;
    private javax.swing.JCheckBox CheckProveedores;
    private javax.swing.JCheckBox CheckVentas;
    private javax.swing.JPanel Escritorio;
    private javax.swing.JPanel InterfazClientes;
    private javax.swing.JPanel InterfazCompras;
    private javax.swing.JPanel InterfazEmpleados;
    private javax.swing.JPanel InterfazFinanzas;
    private javax.swing.JPanel InterfazInicio;
    private javax.swing.JPanel InterfazInventario;
    private javax.swing.JPanel InterfazMetodos;
    private javax.swing.JPanel InterfazProveedores;
    private javax.swing.JPanel InterfazUsuarios;
    private javax.swing.JPanel InterfazVentas;
    private javax.swing.JPanel PanelIzquierdo;
    private javax.swing.JPanel PanelSuperior;
    private javax.swing.JTabbedPane Pestañas;
    private javax.swing.JButton botonActualizarCliente;
    private javax.swing.JButton botonActualizarEmpleado;
    private javax.swing.JButton botonActualizarMetodo;
    private javax.swing.JButton botonActualizarProveedor;
    private javax.swing.JButton botonActualizarUsuario;
    private javax.swing.JButton botonCancelarCliente;
    private javax.swing.JButton botonCancelarEmpleado;
    private javax.swing.JButton botonCancelarMetodo;
    private javax.swing.JButton botonCancelarProveedor;
    private javax.swing.JButton botonCancelarUsuario;
    private javax.swing.JButton botonEliminarCliente;
    private javax.swing.JButton botonEliminarEmpleado;
    private javax.swing.JButton botonEliminarMetodo;
    private javax.swing.JButton botonEliminarProveedor;
    private javax.swing.JButton botonEliminarUsuario;
    private javax.swing.JButton botonGuardarCliente;
    private javax.swing.JButton botonGuardarEmpleado;
    private javax.swing.JButton botonGuardarMetodo;
    private javax.swing.JButton botonGuardarProveedor;
    private javax.swing.JButton botonGuardarusuario;
    public javax.swing.JButton btnClientes;
    public javax.swing.JButton btnCompras;
    public javax.swing.JButton btnEmpleados;
    public javax.swing.JButton btnFinanzas;
    public javax.swing.JButton btnHome;
    public javax.swing.JButton btnInventario;
    public javax.swing.JButton btnMetodosPago;
    public javax.swing.JButton btnProveedores;
    private javax.swing.JButton btnSalir;
    public javax.swing.JButton btnUsuarios;
    public javax.swing.JButton btnVentas;
    private javax.swing.JTextField filtroCliente;
    private javax.swing.JTextField filtroEmpleado;
    private javax.swing.JTextField filtroMetodo;
    private javax.swing.JTextField filtroProveedor;
    private javax.swing.JTextField filtroUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JPanel panelClientes;
    private javax.swing.JPanel panelCompras;
    private javax.swing.JPanel panelConexion;
    private javax.swing.JPanel panelEmpleados;
    private javax.swing.JPanel panelFinanzas;
    private javax.swing.JPanel panelHome;
    private javax.swing.JPanel panelInventario;
    private javax.swing.JPanel panelMetodos;
    private javax.swing.JPanel panelProveedores;
    private javax.swing.JPanel panelSalir;
    private javax.swing.JPanel panelVentas;
    private javax.swing.JTable tablaCliente;
    private javax.swing.JTable tablaEmpleado;
    private javax.swing.JTable tablaMetodo;
    private javax.swing.JTable tablaProveedor;
    private javax.swing.JTable tablaUsuario;
    private javax.swing.JTextField txtCargoEmpleado;
    private javax.swing.JTextField txtCelularCliente;
    private javax.swing.JTextField txtCelularEmpleado;
    private javax.swing.JPasswordField txtContraseñaUsuario;
    private javax.swing.JTextField txtDetallesMetodo;
    private javax.swing.JTextField txtDireccionCliente;
    private javax.swing.JTextField txtDireccionEmpleado;
    private javax.swing.JTextField txtDireccionProveedor;
    private javax.swing.JTextField txtDocumentoCliente;
    private javax.swing.JTextField txtEmailCliente;
    private javax.swing.JTextField txtEmailEmpleado;
    private javax.swing.JTextField txtEmailProveedor;
    private javax.swing.JTextField txtEmpresaProveedor;
    private javax.swing.JTextField txtIdentificacionEmpleado;
    private javax.swing.JTextField txtIdentificacionProveedor;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtNombreEmpleado;
    private javax.swing.JTextField txtNombreMetodo;
    private javax.swing.JTextField txtSalarioEmpleado;
    private javax.swing.JTextField txtTelefonoProveedor;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
