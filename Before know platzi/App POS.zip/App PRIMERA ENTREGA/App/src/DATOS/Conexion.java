
package DATOS; // Declaración del paquete en el que se encuentra la clase

import java.sql.Connection; // Importación de la clase Connection del paquete java.sql
import java.sql.DriverManager; // Importación de la clase DriverManager del paquete java.sql
import java.sql.SQLException; // Importación de la clase SQLException del paquete java.sql

// Declaración de la clase Conexion en el paquete DATOS
public class Conexion {
    
    Connection enlazar = null; // Declaración de la variable enlazar para almacenar la conexión
    
    // Método para establecer la conexión con la base de datos
    public Connection conectar(){
        
        try {
            // Paso 1: Cargar el controlador JDBC necesario para interactuar con la base de datos MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Paso 2: Establecer la conexión con la base de datos
            enlazar = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/STORE", // URL de conexión a la base de datos MySQL
                "root", // Nombre de usuario de la base de datos
                ""); // Contraseña de la base de datos

        } catch (ClassNotFoundException | SQLException e) { // Captura de posibles excepciones
            
           
            
        }
        return enlazar; // Devolver la conexión establecida o null si hubo un error
        
    }  
}