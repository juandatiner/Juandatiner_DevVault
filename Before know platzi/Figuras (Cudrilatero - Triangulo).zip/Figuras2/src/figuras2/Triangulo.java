package figuras2;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;


public class Triangulo extends Figura {
    DecimalFormat formato = new DecimalFormat(".###");
    Punto2D vertices[];
    int aux,px,py;
    public Triangulo() {
        vertices = new Punto2D[3];
        for(int conta=0;conta<3;conta++){
            aux =conta+1;
            px = Integer.parseInt(JOptionPane.showInputDialog("Triangulo - Digite coordenada X del vertice "+aux));
            py = Integer.parseInt(JOptionPane.showInputDialog("Triangulo- Digite coordenada Y del vertice "+aux));
            vertices[conta]= new Punto2D(px,py);
        }
    } 
    @Override
    public int calcularArea() {
       
       double area, A,B,C,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))
               +(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))
               +(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[2].getX()),2))
               +(Math.pow((vertices[0].getY()-vertices[2].getY()),2)));
       S=(A+B+C)/2;
       area=Math.sqrt(S*(S-A)*(S-B)*(S-C));
       JOptionPane.showMessageDialog(null, "AREA DEL TRIÁNGULO: \n" + formato.format(area));
       return (int)area;
    }

    @Override
    public int calcularPerimetro() {
       double A,B,C,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))
               +(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))
               +(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[2].getX()),2))
               +(Math.pow((vertices[0].getY()-vertices[2].getY()),2)));
       S=(A+B+C);
       JOptionPane.showMessageDialog(null, "PERIMETRO DEL TRIÁNGULO: \n" + formato.format(S));
       return (int)S;
    }
    
    public int[] obtenerX() {
        
        int vectoresX[] = new int [3];
        for (int i = 0; i < 3; i++) {
            System.out.println("Vertices en X: " + vertices[i].getX());
        }
        return vectoresX;
    }
    
    public int[] obtenerY(){
        
        int vectoresY[] = new int [3];
        for (int i = 0; i < 3; i++) {
            System.out.println("vertices en Y: " + vertices[i].getY());
        }
        return vectoresY;
    }
}
