
package figuras2;
import java.awt.Graphics;
import java.util.HashMap;
import javax.swing.JOptionPane;

public class Figuras2 {

    public static void main(String args[]){
        menu();
    }
    
public static void menu(){
        
    String [] opciones ={"Elija una opción","Triángulo","Cuadrilátero","Salir"};
    String [] opciones3 ={"Elija una opción","Ingresar datos","Mostrar Información","Graficar","Cerrar gráfico","Volver"};
    String opcion, opcion2;
    HashMap listafiguras = new HashMap();
    
    Cuadrilatero cuadrilatero;
    Triangulo triangulo;
    
//    Vista grafica = new Vista();

    try{               
        do {    
        opcion = (String) JOptionPane.showInputDialog(null,"Selecciona una figura", "Elegir",JOptionPane.QUESTION_MESSAGE,null,opciones, opciones[0]);

            switch (opcion){
                case "Triángulo" -> {
                    try{
                    do {
                        opcion2 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Triángulo",JOptionPane.QUESTION_MESSAGE,null,opciones3, opciones3[0]);
                                                
                        switch (opcion2) {
                            case "Ingresar datos" -> {
                                Triangulo recibir_datos = new Triangulo();
                                listafiguras.put(1, recibir_datos);
                            }
                            case "Mostrar Información" -> {
                                if (listafiguras.containsKey(1)) {
                                    triangulo = (Triangulo) listafiguras.get(1);
                                    triangulo.calcularArea();
                                    triangulo.calcularPerimetro();
                                }
                                else{
                                    JOptionPane.showMessageDialog(null, "No se ha ingresado información del triángulo \n Intente: Ingresar datos");
                                }
                            }
//                          case "Graficar" -> {
//                              triangulo = (Triangulo) listafiguras.get(1);
//                              triangulo.obtenerX();
//                              triangulo.obtenerY();                                                 
//                          }                                                 
                        }
                    }while (!"Volver".equals(opcion2));
                }
                catch(NullPointerException q){
                    JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");}    
                }
                case "Cuadrilátero" ->  {
                    try{
                    do {
                        opcion2 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Cuadrilátero",JOptionPane.QUESTION_MESSAGE,null,opciones3, opciones3[0]);
                                                
                        switch (opcion2) {
                            case "Ingresar datos" -> {
                                Cuadrilatero recibir_datos = new Cuadrilatero();
                                listafiguras.put(2, recibir_datos);
                            }
                            case "Mostrar Información" -> {
                                if (listafiguras.containsKey(2)) {
                                    cuadrilatero = (Cuadrilatero) listafiguras.get(2);
                                    cuadrilatero.calcularArea();
                                    cuadrilatero.calcularPerimetro();
                                }
                                else{
                                    JOptionPane.showMessageDialog(null, "No se ha ingresado información del cuadrilátero \n Intente: Ingresar datos");
                                }
                            }
//                          case "Graficar" -> {
//                              cuadrilatero = (Cuadrilatero) listafiguras.get(2);
//                              cuadrilatero.obtenerX();
//                              cuadrilatero.obtenerY();                                                 
//                          }                                                 
                        }
                    }while (!"Volver".equals(opcion2));
                }
                catch(NullPointerException q){
                    JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");}    
                }    
            }
        }while (!"Salir".equals(opcion));
    }
    catch(NullPointerException q){
            JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");}
}
}

    
    
    
    
