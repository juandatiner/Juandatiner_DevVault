
package Trabajadores;

import Datos.Administrativo;

public class Boton extends Administrativo{
    
}
