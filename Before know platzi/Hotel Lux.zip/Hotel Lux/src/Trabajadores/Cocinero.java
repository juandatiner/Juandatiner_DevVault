
package Trabajadores;

import Datos.Administrativo;

public class Cocinero extends Administrativo{
    
}
