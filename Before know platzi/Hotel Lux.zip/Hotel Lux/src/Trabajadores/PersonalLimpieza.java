
package Trabajadores;

import Datos.Administrativo;

public class PersonalLimpieza extends Administrativo{
    
}
