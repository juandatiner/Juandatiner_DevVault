
package Trabajadores;

import Datos.Administrativo;

public class Masajista extends Administrativo{
       
}
