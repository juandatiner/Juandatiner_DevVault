
package Trabajadores;

import Datos.Administrativo;

public class Recepcionista extends Administrativo{
    
}
