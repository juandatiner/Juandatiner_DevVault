
package Datos;

import Funcionamiento.Conexion;
import java.awt.HeadlessException;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Administrativo extends Persona{
    
    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar();
    
    public int HoraIngreso;
    
    public int HoraSalida;
    
    public int HorasExtra;
    
    
    public int getHoraIngreso() {
        return HoraIngreso;
    }

    public void setHoraIngreso(int HoraIngreso) {
        this.HoraIngreso = HoraIngreso;
    }

    public int getHoraSalida() {
        return HoraSalida;
    }

    public void setHoraSalida(int HoraSalida) {
        this.HoraSalida = HoraSalida;
    }

    public int getHorasExtra() {
        return HorasExtra;
    }

    public void setHorasExtra(int HorasExtra) {
        this.HorasExtra = HorasExtra;
    }
    
    public Administrativo(){
    }
    
    public void Recibirdatos(int NroIdboton, String Nombreboton, String Apellidoboton, String Sexoboton, int Edadboton, String Profesionboton, 
            int HoraIngresoboton, int HoraSalidaboton, int HorasExtraboton) {
        
        String idCadena= String.valueOf(NroIdboton);
        String edadCadena= String.valueOf(Edadboton);
        String horaingresoCadena= String.valueOf(HoraIngresoboton);
        String horasalidaCadena= String.valueOf(HoraSalidaboton);
        String horasextraCadena= String.valueOf(HorasExtraboton);
        try {
            PreparedStatement guardar = connect.prepareStatement("INSERT INTO administrativos (idAdministrativos,Nombre,Apellido,Sexo,Edad,"
                    + "Profesion,HoraIngreso,HoraSalida,HorasExtra) VALUES (?,?,?,?,?,?,?,?,?)") ;
            guardar.setString(1, idCadena);
            guardar.setString(2, Nombreboton);
            guardar.setString(3, Apellidoboton);
            guardar.setString(4, Sexoboton);
            guardar.setString(5, edadCadena);
            guardar.setString(6, Profesionboton);
            guardar.setString(7, horaingresoCadena);
            guardar.setString(8, horasalidaCadena);
            guardar.setString(9, horasextraCadena);
            guardar.executeUpdate();
            JOptionPane.showMessageDialog(null, "Administrativo Ingresado con exitó");
            
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró Ingresar Administrativo");
        } 

    }
    
    public void Mostrardatos(String [] datos, DefaultTableModel TAdministrativos, int opcionbuscar, String valorbuscar){
        
        String codsql;
                
        if(opcionbuscar == 0 && valorbuscar == null){
            codsql = "SELECT * FROM administrativos";
        }else{
            if(opcionbuscar == 1 && valorbuscar != null){
                codsql = "SELECT * FROM administrativos WHERE idAdministrativos = '"+ valorbuscar+"'";
            }else{
                if(opcionbuscar == 2 && valorbuscar != null){
                    codsql = "SELECT * FROM administrativos WHERE Apellido = '"+ valorbuscar+"'";  
                }else{
                    if(opcionbuscar == 3 && valorbuscar != null){
                        codsql = "SELECT * FROM administrativos WHERE Sexo = '"+ valorbuscar+"'";
                    }else{
                        if(opcionbuscar == 4 && valorbuscar != null){
                            codsql = "SELECT * FROM administrativos WHERE Profesion = '"+ valorbuscar+"'";
                        }else{
                            codsql = "SELECT * FROM administrativos";
                        }
                    }    
                }
            }
        }        
        
        
        try {
            Statement leer = connect.createStatement();
            ResultSet resultado = leer.executeQuery(codsql);
            
            while (resultado.next()){
                datos [0] = resultado.getString(1);
                datos [1] = resultado.getString(2);
                datos [2] = resultado.getString(3);
                datos [3] = resultado.getString(4);
                datos [4] = resultado.getString(5);
                datos [5] = resultado.getString(6);
                datos [6] = resultado.getString(7);
                datos [7] = resultado.getString(8);
                datos [8] = resultado.getString(9);
                TAdministrativos.addRow(datos);
             
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " Error en la consulta");
        }  
    }
    
    public void Editardatos(int id, String nombre, String apellido, String sexo, int edad, String profesion, int horaingreso, int horasalida, int horasextra){
        
        try {
            PreparedStatement actualizar = connect.prepareStatement("UPDATE administrativos SET Nombre='"+nombre+"',Apellido='"+apellido+"'"
                    + ",Sexo='"+sexo+"',Edad='"+edad+"',Profesion='"+profesion+"',HoraIngreso='"+horaingreso+"',HoraSalida='"+horasalida+"',HorasExtra='"
                            +horasextra+"'"+"WHERE idAdministrativos='"+id+"'");
            actualizar.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró actualizar los datos");
        }   
    }
    
    public void Eliminardatos(String valor){
        
        try {
            PreparedStatement eliminar = connect.prepareStatement("DELETE FROM administrativos WHERE idAdministrativos='"+valor+"'");
            eliminar.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró eliminar el administrativo");
        }
        
    }
    
}