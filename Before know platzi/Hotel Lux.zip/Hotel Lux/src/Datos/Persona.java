
package Datos;

public abstract class Persona {
    
    
    protected int NroID;

    protected String nombres;

    protected String apellidos;
    
    protected String sexo;

    protected int edad;
    

    public int getNroID() {
        return NroID;
    }

    public void setNroID(int NroID) {
        this.NroID = NroID;
    }
    
    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getSexo(){
        return sexo;
    }
            
    public void setSexo(String sexo){
        this.sexo = sexo;
    }
    
    public int getEdad(){
        return edad;
    }
            
    public void setEdad(int edad){
        this.edad = edad;
    }

    public Persona(){
    }
    
    
}
