
package ServiciosAdicionales;

public class RoomService extends ServiciosAdicionales{
    
    public int ContadorRoomService = 1;
    
    public RoomService() {
        this.setValorServicioAdicional(30000);
    }
}
