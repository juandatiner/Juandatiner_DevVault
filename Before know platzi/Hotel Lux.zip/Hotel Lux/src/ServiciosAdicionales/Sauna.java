
package ServiciosAdicionales;

public class Sauna extends ServiciosAdicionales{
    
    public int ContadorSauna = 1;
    
    public Sauna() {
        this.setValorServicioAdicional(20000);
    }
}
