
package Habitaciones;

public class HabitacionDoble extends Habitaciones {
    
    public int ContadorDoble = 3;
    
    public HabitacionDoble() {
        this.setValorHabitacion(350000);
    }
    
}
