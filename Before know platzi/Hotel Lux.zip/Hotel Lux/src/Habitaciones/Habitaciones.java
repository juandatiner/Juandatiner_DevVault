
package Habitaciones;

import Funcionamiento.Conexion;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Habitaciones {
    
    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar();
    
    protected int ValorHabitacion;

    public int getValorHabitacion() {
        return ValorHabitacion;
    }

    public void setValorHabitacion(int ValorHabitacion) {
        this.ValorHabitacion = ValorHabitacion;
    }
   
    public Habitaciones(){
        
    }
    
    public void Mostrardatos(String [] datos, DefaultTableModel THabitaciones, int opcionbuscar, String valorbuscar){
        
        String codsql;
                
        if(opcionbuscar == 0 && valorbuscar == null){
            codsql = "SELECT * FROM habitaciones";
        }else{
            if(opcionbuscar == 1 && valorbuscar != null){
                codsql = "SELECT * FROM habitaciones WHERE Tipo = '"+ valorbuscar+"'";
            }else{
                codsql = "SELECT * FROM habitaciones";
            }
        }    
        
        try {
            Statement leer = connect.createStatement();
            ResultSet resultado = leer.executeQuery(codsql);
            
            while (resultado.next()){
                datos [0] = resultado.getString(1);
                datos [1] = resultado.getString(2);
                datos [2] = resultado.getString(3);
                datos [3] = resultado.getString(4);
                THabitaciones.addRow(datos);
             
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " Error en la consulta");
        }  
    }
    
    public void Editardatos(String tipo, int valor){
        
        try {
            PreparedStatement actualizar = connect.prepareStatement("UPDATE habitaciones SET Valor='"+valor+"'"+"WHERE Tipo='"+tipo+"'");
            actualizar.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró actualizar los datos");
        }   
    }
    
    public void Editarestado(String numero, String disponibilidad){
        
        try {
            PreparedStatement actualizar = connect.prepareStatement("UPDATE habitaciones SET Disponibilidad='"+disponibilidad+"'"+"WHERE Numero='"+numero+"'");
            actualizar.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e + " La habitación no pudo ser verificada");
        }
        
    }
    
    
}
