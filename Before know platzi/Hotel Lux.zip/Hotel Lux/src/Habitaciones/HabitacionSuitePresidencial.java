
package Habitaciones;

public class HabitacionSuitePresidencial extends Habitaciones{
    
    public int ContadorSuitePresidencial = 1;
    
    public HabitacionSuitePresidencial() {
        this.setValorHabitacion(950000);
    } 
}
