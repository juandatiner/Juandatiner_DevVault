
package Hotel_Lux;

import Datos.Huespedes;
import javax.swing.table.DefaultTableModel;

public final class EliminarHuespedes extends javax.swing.JInternalFrame {

    Huespedes mostrarHues= new Huespedes();
    Huespedes eliminarHues = new Huespedes();
    
    public EliminarHuespedes() {
        initComponents();
        mostrartabla(0,null);
    }
    
    public void mostrartabla(int opcionbuscar, String valorbuscar){
        
        
        DefaultTableModel THuespedes = new DefaultTableModel();
        THuespedes.addColumn("NroID");
        THuespedes.addColumn("NOMBRE");
        THuespedes.addColumn("APELLIDO");
        THuespedes.addColumn("SEXO");
        THuespedes.addColumn("EDAD");
        THuespedes.addColumn("HABITACION");
        THuespedes.addColumn("CORREO TITULAR");
        THuespedes.addColumn("DIAS");
        TablaHuespedes.setModel(THuespedes);

        String [] datos = new String[8];
        mostrarHues.Mostrardatos(datos, THuespedes, opcionbuscar, valorbuscar);
        TablaHuespedes.setModel(THuespedes);
    }
    
    public void eliminardatos(String valor){
        
        eliminarHues.Eliminardatos(valor);
        
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaHuespedes = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        ComboBoxBusquedaHuespedes = new javax.swing.JComboBox<>();
        ButtonBusquedaHuespedes = new javax.swing.JButton();
        TextBusquedaHuespedes = new javax.swing.JTextField();
        ButtonEliminarHuespedes = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Eliminar Huespedes");

        TablaHuespedes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(TablaHuespedes);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Buscar por:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 14))); // NOI18N

        ComboBoxBusquedaHuespedes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mostrar todos", "NroID", "Apellido", "Sexo", "Habitacion", " " }));
        ComboBoxBusquedaHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxBusquedaHuespedesActionPerformed(evt);
            }
        });

        ButtonBusquedaHuespedes.setBackground(new java.awt.Color(0, 255, 0));
        ButtonBusquedaHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        ButtonBusquedaHuespedes.setText("Buscar");
        ButtonBusquedaHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonBusquedaHuespedesActionPerformed(evt);
            }
        });

        TextBusquedaHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextBusquedaHuespedesActionPerformed(evt);
            }
        });

        ButtonEliminarHuespedes.setBackground(new java.awt.Color(255, 51, 51));
        ButtonEliminarHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        ButtonEliminarHuespedes.setText("Eliminar");
        ButtonEliminarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonEliminarHuespedesActionPerformed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/huespedes.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(ComboBoxBusquedaHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(TextBusquedaHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(ButtonBusquedaHuespedes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ButtonEliminarHuespedes)
                .addGap(27, 27, 27))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ComboBoxBusquedaHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextBusquedaHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ButtonBusquedaHuespedes)
                            .addComponent(ButtonEliminarHuespedes)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel3)))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 676, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComboBoxBusquedaHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxBusquedaHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxBusquedaHuespedesActionPerformed

    private void ButtonBusquedaHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonBusquedaHuespedesActionPerformed
        int opcionbuscar = ComboBoxBusquedaHuespedes.getSelectedIndex();
        String valorbuscar = TextBusquedaHuespedes.getText();
        mostrartabla(opcionbuscar,valorbuscar);
    }//GEN-LAST:event_ButtonBusquedaHuespedesActionPerformed

    private void TextBusquedaHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextBusquedaHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextBusquedaHuespedesActionPerformed

    private void ButtonEliminarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonEliminarHuespedesActionPerformed
        int fila = TablaHuespedes.getSelectedRow();
        String valor = TablaHuespedes.getValueAt(fila, 0).toString();
        eliminardatos(valor);
        mostrartabla(0,null);
    }//GEN-LAST:event_ButtonEliminarHuespedesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonBusquedaHuespedes;
    private javax.swing.JButton ButtonEliminarHuespedes;
    private javax.swing.JComboBox<String> ComboBoxBusquedaHuespedes;
    private javax.swing.JTable TablaHuespedes;
    private javax.swing.JTextField TextBusquedaHuespedes;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
