
package Hotel_Lux;

import Datos.Administrativo;
import javax.swing.table.DefaultTableModel;

public final class EditarAdministrativos extends javax.swing.JInternalFrame {

    Administrativo mostrarAdm = new Administrativo();
    Administrativo editarAdm = new Administrativo();
    
    public EditarAdministrativos() {
        initComponents();
        mostrartabla(0,null);
    }
    
    public void mostrartabla( int opcionbuscar, String valorbuscar){
        
        
        DefaultTableModel TAdministrativos = new DefaultTableModel();
        TAdministrativos.addColumn("NroID");
        TAdministrativos.addColumn("NOMBRE");
        TAdministrativos.addColumn("APELLIDO");
        TAdministrativos.addColumn("SEXO");
        TAdministrativos.addColumn("EDAD");
        TAdministrativos.addColumn("PROFESION");
        TAdministrativos.addColumn("HORA INGRESO");
        TAdministrativos.addColumn("HORA SALIDA");
        TAdministrativos.addColumn("HORAS EXTRA");
        TablaAdministrativos.setModel(TAdministrativos);

        String [] datos = new String[9];
        mostrarAdm.Mostrardatos(datos, TAdministrativos, opcionbuscar, valorbuscar);
        TablaAdministrativos.setModel(TAdministrativos);
        
    }
    
    public void actualizardatos(int id, String nombre, String apellido, String sexo, int edad, String profesion, int horaingreso, int horasalida, int horasextra){
        
        editarAdm.Editardatos(id, nombre, apellido, sexo, edad, profesion, horaingreso, horasalida, horasextra);

    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaAdministrativos = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        ComboBoxBusquedaAdministrativos = new javax.swing.JComboBox<>();
        ButtonBusquedaAdministrativos = new javax.swing.JButton();
        TextBusquedaAdministrativos = new javax.swing.JTextField();
        ButtonActualizarAdministrativos = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Editar Administrativos");

        TablaAdministrativos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(TablaAdministrativos);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Buscar por:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 14))); // NOI18N

        ComboBoxBusquedaAdministrativos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mostrar todos", "NroID", "Apellido", "Sexo", "Profesión", " " }));
        ComboBoxBusquedaAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxBusquedaAdministrativosActionPerformed(evt);
            }
        });

        ButtonBusquedaAdministrativos.setBackground(new java.awt.Color(0, 255, 0));
        ButtonBusquedaAdministrativos.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        ButtonBusquedaAdministrativos.setText("Buscar");
        ButtonBusquedaAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonBusquedaAdministrativosActionPerformed(evt);
            }
        });

        TextBusquedaAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextBusquedaAdministrativosActionPerformed(evt);
            }
        });

        ButtonActualizarAdministrativos.setBackground(new java.awt.Color(255, 255, 51));
        ButtonActualizarAdministrativos.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        ButtonActualizarAdministrativos.setText("Actualizar");
        ButtonActualizarAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonActualizarAdministrativosActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jLabel1.setText("Los NroID no pueden ser editados.");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/trabajo-en-equipo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(ComboBoxBusquedaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(TextBusquedaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(ButtonBusquedaAdministrativos)
                        .addGap(26, 26, 26)
                        .addComponent(ButtonActualizarAdministrativos))
                    .addComponent(jLabel1))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ComboBoxBusquedaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextBusquedaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ButtonBusquedaAdministrativos)
                            .addComponent(ButtonActualizarAdministrativos))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComboBoxBusquedaAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxBusquedaAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxBusquedaAdministrativosActionPerformed

    private void ButtonBusquedaAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonBusquedaAdministrativosActionPerformed
        int opcionbuscar = ComboBoxBusquedaAdministrativos.getSelectedIndex();
        String valorbuscar = TextBusquedaAdministrativos.getText();
        mostrartabla(opcionbuscar,valorbuscar);
    }//GEN-LAST:event_ButtonBusquedaAdministrativosActionPerformed

    private void TextBusquedaAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextBusquedaAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextBusquedaAdministrativosActionPerformed

    private void ButtonActualizarAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonActualizarAdministrativosActionPerformed
        
        int fila = TablaAdministrativos.getSelectedRow();
        
        int id = Integer.parseInt(this.TablaAdministrativos.getValueAt(fila, 0).toString());
        String nombre = TablaAdministrativos.getValueAt(fila, 1).toString();
        String apellido = TablaAdministrativos.getValueAt(fila, 2).toString();
        String sexo = TablaAdministrativos.getValueAt(fila, 3).toString();
        int edad = Integer.parseInt(this.TablaAdministrativos.getValueAt(fila, 4).toString());
        String profesion = TablaAdministrativos.getValueAt(fila, 5).toString();
        int horaingreso = Integer.parseInt(this.TablaAdministrativos.getValueAt(fila, 6).toString());
        int horasalida = Integer.parseInt(this.TablaAdministrativos.getValueAt(fila, 7).toString());
        int horasextra = Integer.parseInt(this.TablaAdministrativos.getValueAt(fila, 8).toString());
        
        actualizardatos(id, nombre, apellido, sexo, edad, profesion, horaingreso, horasalida, horasextra);
        
    }//GEN-LAST:event_ButtonActualizarAdministrativosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonActualizarAdministrativos;
    private javax.swing.JButton ButtonBusquedaAdministrativos;
    private javax.swing.JComboBox<String> ComboBoxBusquedaAdministrativos;
    private javax.swing.JTable TablaAdministrativos;
    private javax.swing.JTextField TextBusquedaAdministrativos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
