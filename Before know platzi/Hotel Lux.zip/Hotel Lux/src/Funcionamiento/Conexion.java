
package Funcionamiento;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {
    
    Connection enlazar = null;
    
    public Connection conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            enlazar = DriverManager.getConnection(
    "jdbc:mysql://aws.connect.psdb.cloud/hotellux?sslMode=VERIFY_IDENTITY",
    "q3scihtlq6qbq58ygjsw",
    "pscale_pw_pwRQAmWiQLtHQh3I8nerUcR6mdiFJl0YoO2RnKyCmBX");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No fue posible establecer la conexión");
        }
        return enlazar;
    }
    
}
