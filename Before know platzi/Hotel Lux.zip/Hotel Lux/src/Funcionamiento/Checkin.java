
package Funcionamiento;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Checkin {
    
    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar(); 
    
    public void Mostrardatos(String [] datos, DefaultTableModel THabitaciones){
        
        String codsql;
                
        codsql = "SELECT * FROM habitaciones WHERE Disponibilidad='"+"1"+"'";
           
        imprimirdatos(codsql,datos,THabitaciones); 
    }
    
    public void Disponibilidad(String [] datos, DefaultTableModel THabitaciones, int opcionbuscar){
        
        String codsql = "";
       
        switch(opcionbuscar){
           
            case 0 -> {
                if(codsql!=null){
                    codsql = "SELECT * FROM habitaciones WHERE TIPO='"+"Sencilla"+"'"+"AND Disponibilidad='"+"1"+"'";
                    imprimirdatos(codsql,datos,THabitaciones);
                }else{
                    JOptionPane.showMessageDialog(null," No hay habitaciones Sencillas disponibles");
                }
            }
            case 1 -> {
                if(codsql!=null){
                    codsql = "SELECT * FROM habitaciones WHERE TIPO='"+"Doble"+"'"+"AND Disponibilidad='"+"1"+"'";
                    imprimirdatos(codsql,datos,THabitaciones);
                }else{
                    JOptionPane.showMessageDialog(null," No hay habitaciones Dobles disponibles");
                }
            }
            case 2 -> {
                if (codsql!=null){
                    codsql = "SELECT * FROM habitaciones WHERE TIPO='"+"Suite Vista Ciudad"+"'"+"AND Disponibilidad='"+"1"+"'";
                    imprimirdatos(codsql,datos,THabitaciones);
                }else{
                    JOptionPane.showMessageDialog(null," No hay Suites Vista Ciudad disponibles");
                }
            }
            case 3 -> {
                if(codsql!=null){
                    codsql = "SELECT * FROM habitaciones WHERE TIPO='"+"Suite Vista Mar"+"'"+"AND Disponibilidad='"+"1"+"'";
                    imprimirdatos(codsql,datos,THabitaciones);
                }else{
                    JOptionPane.showMessageDialog(null," No hay Suites Vista Mar disponibles");
                }
            }
            case 4 -> {
                if(codsql!=null){
                    codsql = "SELECT * FROM habitaciones WHERE TIPO='"+"Suite Presidencial"+"'"+"AND Disponibilidad='"+"1"+"'";
                    imprimirdatos(codsql,datos,THabitaciones);
                }else{
                    JOptionPane.showMessageDialog(null," No hay Suite Presidencial disponibles");
                }
            }    
        }   
    
    }    
    
    
    public void imprimirdatos(String codsql, String [] datos, DefaultTableModel THabitaciones){
        
        try {
            Statement leer = connect.createStatement();
            ResultSet resultado = leer.executeQuery(codsql);
            
            while (resultado.next()){
                datos [0] = resultado.getString(1);
                datos [1] = resultado.getString(2);
                datos [2] = resultado.getString(3);
                datos [3] = resultado.getString(4);
                THabitaciones.addRow(datos);
             
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " Error en la consulta");
        }
    }    
    
    
}