package figuras;

import java.awt.Graphics;
import java.util.HashMap;
import javax.swing.JOptionPane;

public class Main {   
    public static void main(String args[]){
        menu();
    }
   
    public static void menu(){
        
            String [] opciones ={"Elija una opción","Triángulo","Cuadrilátero","Salir"}; 
            String [] opciones2 ={"Elija una opción","Triángulo Rectángulo","Triángulo Isosceles","Triángulo Escaleno","Volver"}; 
            String [] opciones3 ={"Elija una opción","Ingresar datos y características","Mostrar Info.","Graficar","Cerrar gráfico","Volver"}; 
            String [] opciones4 ={"Elija una opción","Cuadrilátero coordenadas","Trapecio","Volver"}; 
            String opcion, opcion2, opcion3, opcion4; 
            
            HashMap listafiguras = new HashMap();
            
            Triangulo triangulo_rectangulo;
            Triangulo triangulo_isosceles;
            Triangulo triangulo_escaleno;
            
            Cuadrilatero cuadrilatero_coordenadas;
            Cuadrilatero trapecio;
            
            Vista grafica = new Vista();
           
            try{               
                do {    
                opcion = (String) JOptionPane.showInputDialog(null,"Selecciona una figura", "Elegir",JOptionPane.QUESTION_MESSAGE,null,opciones, opciones[0]);
                
                    switch (opcion){
                        case "Triángulo" -> {
                            try{
                                do {
                                opcion2 = (String) JOptionPane.showInputDialog(null,"Selecciona un tipo de triángulo", "Triángulo",JOptionPane.QUESTION_MESSAGE,null,opciones2, opciones2[0]);
                                
                                switch (opcion2){
                                    case "Triángulo Escaleno" -> {
                                        try{
                                            do{
                                                opcion3 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Triángulo > Escaleno",JOptionPane.QUESTION_MESSAGE,null,opciones3, opciones3[0]);
                                                
                                                switch (opcion3) {
                                                    case "Ingresar datos y características" -> {
                                                        Triangulo recibir_datos = new Triangulo_Escaleno();
                                                        listafiguras.put(1, recibir_datos);
                                                    }
                                                    case "Mostrar Info." -> {
                                                        if (listafiguras.containsKey(1)) {
                                                            triangulo_escaleno = (Triangulo) listafiguras.get(1);
                                                            triangulo_escaleno.calcularArea();
                                                            triangulo_escaleno.calcularPerimetro();
                                                        }
                                                        else{
                                                            JOptionPane.showMessageDialog(null, "No se ha ingresado información del triángulo \n Intente- Ingresar datos y características");
                                                        }
                                                    }
//                                                    case "Graficar" -> {
//                                                        triangulo_escaleno = (Triangulo) listafiguras.get(1);
//                                                        triangulo_escaleno.obtenerX();
//                                                        triangulo_escaleno.obtenerY();                                                 
//                                                    }                                                 
                                                }
                                            }while (!"Volver".equals(opcion3));
                                        }
                                        catch(NullPointerException q){
                                        JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");
                                        }   
                                    }
                                    
                                    case "Triángulo Isosceles" -> {
                                        try{
                                            do {
                                                opcion3 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Triángulo > Isosceles",JOptionPane.QUESTION_MESSAGE,null,opciones3, opciones3[0]);
                                                
                                                switch (opcion3){
                                                    case "Ingresar datos y características" -> {
                                                        Triangulo recibir_datos = new Triangulo_Isosceles();
                                                        listafiguras.put(2, recibir_datos);
                                                    }
                                                    case "Mostrar Info." -> {  
                                                        if (listafiguras.containsKey(2)) {
                                                            triangulo_isosceles = (Triangulo) listafiguras.get(2);
                                                            triangulo_isosceles.calcularArea();
                                                            triangulo_isosceles.calcularPerimetro();
                                                        }
                                                        else{
                                                            JOptionPane.showMessageDialog(null, "No se ha ingresado información del triángulo \n Intente- Ingresar datos y características");
                                                        }   
                                                    }    
                                                }
                                            }while (!"Volver".equals(opcion3));
                                        }
                                        catch(NullPointerException q){
                                        JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");
                                        }
                                    }
                                    
                                    case "Triángulo Rectángulo" -> {
                                        try{
                                            do {
                                                
                                                opcion3 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Triángulo > Rectángulo",JOptionPane.QUESTION_MESSAGE,null,opciones3, opciones3[0]);
                                                
                                                switch (opcion3){
                                                    
                                                    case "Ingresar datos y características" -> {
                                                        Triangulo recibir_datos = new Triangulo_Rectangulo();
                                                        listafiguras.put(3, recibir_datos);
                                                    }
                                                    
                                                    case "Mostrar Info." -> {
                                                        
                                                        if (listafiguras.containsKey(3)) {
                                                            triangulo_rectangulo = (Triangulo) listafiguras.get(3);
                                                            triangulo_rectangulo.calcularArea();
                                                            triangulo_rectangulo.calcularPerimetro();
                                                        }
                                                        else{
                                                            JOptionPane.showMessageDialog(null, "No se ha ingresado información del triángulo \n Intente- Ingresar datos y características");
                                                        }    
                                                    }
                                                }                                             
                                            }while (!"Volver".equals(opcion3));
                                        }
                                        catch(NullPointerException q){
                                        JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");
                                        }
                                    }
                                }
                                }while (!"Volver".equals(opcion2));
                            }
                            catch(NullPointerException q){
                            JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");
                            }
                        }
       
                        case "Cuadrilátero" ->  {                
                            try{
                                do {
                                    opcion4 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Cuadrilátero",JOptionPane.QUESTION_MESSAGE,null,opciones4, opciones4[0]);

                                    switch(opcion4){
                                        case "Cuadrilátero coordenadas" -> {
                                            try{
                                            do {
                                                opcion3 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Cuadrilatero > Coordenadas",JOptionPane.QUESTION_MESSAGE,null,opciones3, opciones3[0]);
                                                
                                                switch(opcion3){                                                
                                                    case "Ingresar datos y características" -> {
                                                        Cuadrilatero recibir_datos = new Cuadrilatero_Regular();
                                                        listafiguras.put(4, recibir_datos);
                                                    }
                                                    case "Mostrar Info." -> {
                                                        if (listafiguras.containsKey(4)) {
                                                            cuadrilatero_coordenadas = (Cuadrilatero) listafiguras.get(4);
                                                            cuadrilatero_coordenadas.calcularArea();
                                                            cuadrilatero_coordenadas.calcularPerimetro();
                                                        }
                                                        else{
                                                            JOptionPane.showMessageDialog(null, "No se ha ingresado información del cuadrilátero \n Intente- Ingresar datos y características");
                                                        }
                                                    }                                                    
                                                }
                                            }while (!"Volver".equals(opcion3));
                                            }
                                            catch(NullPointerException q){
                                                JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");
                                            }
                                        }                                       
                                        case "Trapecio" -> {                                           
                                            try{
                                            do {
                                                opcion3 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Cuadrilátero > Trapecio",JOptionPane.QUESTION_MESSAGE,null,opciones3, opciones3[0]);
                                                
                                                switch(opcion3){
                                                    case "Ingresar datos y características" -> {                                                       
                                                        Cuadrilatero recibir_datos = new Cuadrilatero_Trapecio();
                                                        listafiguras.put(5, recibir_datos);
                                                    }                                                  
                                                    case "Mostrar Info." -> {                                                      
                                                        if (listafiguras.containsKey(5)) {
                                                            trapecio = (Cuadrilatero) listafiguras.get(5);
                                                            trapecio.calcularArea();
                                                            trapecio.calcularPerimetro();
                                                        }
                                                        else{
                                                            JOptionPane.showMessageDialog(null, "No se ha ingresado información del traprecio \n Intente- Ingresar datos y características");
                                                        }
                                                    }    
                                                }
                                            }while (!"Volver".equals(opcion3));
                                            }
                                            catch(NullPointerException q){
                                                JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");
                                            }
                                        }
                                    }
                                }while (!"Volver".equals(opcion4));
                            }
                            catch(NullPointerException q){
                            JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");
                            }
                        }
                    }
                } while (!"Salir".equals(opcion));   
            }
            catch(NullPointerException q){
            JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");
            }     
    }  
}

////                 ___====-_  _-====___
////           _--^^^#####//      \\#####^^^--_
////        _-^##########// (    ) \\##########^-_
////       -############//  |\^^/|  \\############-
////     _/############//   (@::@)   \\############\_
////    /#############((     \\//     ))#############\
////   -###############\\    (oo)    //###############-
////  -#################\\  / VV \  //#################-
//// -###################\\/      \//###################-
////_#/|##########/\######(   /\   )######/\##########|\#_
////|/ |#/\#/\#/\/  \#/\##\  |  |  /##/\#/  \/\#/\#/\#| \|
////`  |/  V  V  `   V  \#\| |  | |/#/  V   '  V  V  \|  '
////   `   `  `      `   / | |  | | \   '      '  '   '
////                    (  | |  | |  ) by~ Andrew
////                   __\ | |  | | /__
////                  (vvv(VVV)(VVV)vvv)
