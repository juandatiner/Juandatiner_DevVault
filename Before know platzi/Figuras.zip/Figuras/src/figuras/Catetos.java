package figuras;

public class Catetos {
    float c1, c2;

    public Catetos(int CATETO1, int CATETO2) {
        this.c1=CATETO1;
        this.c2=CATETO2;
    }
    
    public float getC1() {
        return c1;
    }

    public void setC1(float c1) {
        this.c1 = c1;
    }

    public float getC2() {
        return c2;
    }

    public void setC2(float c2) {
        this.c2 = c2;
    }
    
}
