
package figuras;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;


public class Triangulo_Isosceles extends Triangulo {
    DecimalFormat formato = new DecimalFormat(".###");
    Base_lado info[];
    float base, lado;
    public Triangulo_Isosceles(){
        info = new Base_lado[2];
           
            base = Integer.parseInt(JOptionPane.showInputDialog("Triangulo Isósceles- Ingrese la base del triangulo "));
            lado = Integer.parseInt(JOptionPane.showInputDialog("Triangulo Isósceles- Ingrese un lado del triángulo "));
            info[0]= new Base_lado(base,lado);
    } 
    
    @Override
    public int calcularArea() {
       
       double area,h;
       h = Math.hypot(base/2, lado);

       area=((base/2)*h)/2;
       JOptionPane.showMessageDialog(null, "AREA DEL TRIÁNGULO: \n" + formato.format(area));
       return (int)area;
    }

    @Override
    public int calcularPerimetro() { 
       double S = base+(lado*2);
       
       JOptionPane.showMessageDialog(null, "PERIMETRO DEL TRIÁNGULO: \n" + formato.format(S));
       return (int)S;
    }

    @Override
    public int[] obtenerX() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public int[] obtenerY() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
