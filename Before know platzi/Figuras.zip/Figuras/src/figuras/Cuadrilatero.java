package figuras;
import javax.swing.JOptionPane;
public abstract class Cuadrilatero extends Figura{

}
