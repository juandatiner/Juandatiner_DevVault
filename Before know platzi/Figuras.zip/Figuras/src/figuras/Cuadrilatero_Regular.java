package figuras;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;


public class Cuadrilatero_Regular extends Cuadrilatero{
    
    DecimalFormat formato = new DecimalFormat(".###");
    Punto2D vertices[];
    int px,py;
    public Cuadrilatero_Regular(){
        vertices = new Punto2D[4];
        for(int conta=0;conta<4;conta++){
            px = Integer.parseInt(JOptionPane.showInputDialog("Cuadrilátero - Digite coordenada X del vertice "+(conta+1)));
            py = Integer.parseInt(JOptionPane.showInputDialog("Cuadrilátero - Digite coordenada Y del vertice "+(conta+1)));
            vertices[conta]= new Punto2D(px,py);
        }
    } 
    @Override
    public int calcularArea() {
       
       double A, det1, det2; 

       det1 = (vertices[0].getX() * vertices[1].getY()) + (vertices[1].getX() * vertices[2].getY())
               + (vertices[2].getX() * vertices[3].getY()) + (vertices[3].getX() * vertices[0].getY());
       
       det2 = (vertices[0].getY() * vertices[1].getX()) + (vertices[1].getY() * vertices[2].getX())
               + (vertices[2].getY() * vertices[3].getX()) + (vertices[3].getY() * vertices[0].getX());
       
       A = (det1 - det2) /2;
        
       JOptionPane.showMessageDialog(null, "AREA DEL CUADRILATERO: \n" + formato.format(A));
       return (int)A;
    }

    @Override
    public int calcularPerimetro() {
       double A,B,C,D,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))
               +(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))
               +(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[3].getX()-vertices[2].getX()),2))
               +(Math.pow((vertices[3].getY()-vertices[2].getY()),2)));
       D= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[3].getX()),2))
               +(Math.pow((vertices[0].getY()-vertices[3].getY()),2)));
       S=(A+B+C+D);
       JOptionPane.showMessageDialog(null, "PERIMETRO DEL CUADRILATERO: \n" + formato.format(S));
       return (int)S;
    }

}
