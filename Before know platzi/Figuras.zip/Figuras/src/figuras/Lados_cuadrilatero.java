package figuras;

public class Lados_cuadrilatero {
    float base1, base2, h;
        
    public Lados_cuadrilatero(float BASE1, float BASE2, float H) {
        this.base1 = BASE1;
        this.base2 = BASE2;
        this.h = H;
    }
    public float getBase1() {
        return base1;
    }

    public void setBase1(float base1) {
        this.base1 = base1;
    }

    public float getBase2() {
        return base2;
    }

    public void setBase2(float base2) {
        this.base2 = base2;
    }

    public float getH() {
        return h;
    }

    public void setH(float h) {
        this.h = h;
    }

}
