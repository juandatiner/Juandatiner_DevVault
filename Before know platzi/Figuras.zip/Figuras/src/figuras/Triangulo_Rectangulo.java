package figuras;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;


public class Triangulo_Rectangulo extends Triangulo {
    
    DecimalFormat formato = new DecimalFormat(".###");
    Catetos catetos[];
    int cateto1, cateto2;
    public Triangulo_Rectangulo(){
        catetos = new Catetos[2];
            
            cateto1 = Integer.parseInt(JOptionPane.showInputDialog("Triangulo Rectángulo- Ingrese el cateto 1 \n (este cateto será tomado como la base)"));
            cateto2 = Integer.parseInt(JOptionPane.showInputDialog("Triangulo Rectángulo- Ingrese el cateto 2"));
            catetos[0]= new Catetos(cateto1,cateto2);

    } 
    
    @Override
    public int calcularArea() {
       
       double area;


       area=(cateto1*cateto2)/2;
       JOptionPane.showMessageDialog(null, "AREA DEL TRIÁNGULO: \n" + formato.format(area));
       return (int)area;
    }

    @Override
    public int calcularPerimetro() { 
       double S,h;
       h = Math.hypot(cateto1, cateto2);
       
       S = cateto1 + cateto2 + h;
       
       JOptionPane.showMessageDialog(null, "PERIMETRO DEL TRIÁNGULO: \n" + formato.format(S));
       return (int)S;
    }

    @Override
    public int[] obtenerX() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public int[] obtenerY() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
