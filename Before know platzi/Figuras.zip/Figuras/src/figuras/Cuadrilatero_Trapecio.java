package figuras;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class Cuadrilatero_Trapecio extends Cuadrilatero{
    
    DecimalFormat formato = new DecimalFormat(".###");
    Lados_cuadrilatero info[];
    float Base_mayor, Base_menor, h;
    
    public Cuadrilatero_Trapecio(){
        info = new Lados_cuadrilatero[1];
           
        Base_mayor = Float.parseFloat(JOptionPane.showInputDialog("Trapecio Regular- Ingrese la base mayor del Trapecio "));
        Base_menor = Float.parseFloat(JOptionPane.showInputDialog("Trapecio Regular- Ingrese la base menor del Trapecio "));
        h = Float.parseFloat(JOptionPane.showInputDialog("Trapecio Regular- Ingrese la altura del trapecio"));
        info[0]= new Lados_cuadrilatero(Base_mayor,Base_menor,h);
    } 
    
    @Override
    public int calcularArea() {
       
       double area;
       
       area = (((Base_mayor+Base_menor)/2) *h); 
       
       JOptionPane.showMessageDialog(null, "AREA DEL TRAPECIO: \n" + formato.format(area));
       return (int)area;
    }

    @Override
    public int calcularPerimetro() { 
       double S, cateto ,lado;
       
       cateto = (Base_mayor-Base_menor) /2;
       lado = Math.sqrt((Math.pow(cateto, 2)) + Math.pow(h, 2));
       S = ((lado*2) + Base_mayor + Base_menor);
       
       JOptionPane.showMessageDialog(null, "PERIMETRO DEL TRAPECIO: \n" + formato.format(S));
       return (int)S;
    }


}