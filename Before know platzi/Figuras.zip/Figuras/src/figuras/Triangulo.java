package figuras;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;
public abstract class Triangulo extends Figura {
    
    public abstract int[] obtenerX();
    public abstract int[] obtenerY();
}
