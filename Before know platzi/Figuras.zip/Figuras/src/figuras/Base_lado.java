package figuras;
public class Base_lado {
    float base, lado;
    public Base_lado(float BASE, float LADO) {
        this.base=BASE;
        this.lado=LADO;
    }

    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }
}
