
package Polimorfismo;

import javax.swing.JOptionPane;


public class Docente extends Persona {
    
    protected String idEscalafon;

    public String getIdEscalafon() {
        return idEscalafon;
    }

    public void setIdEscalafon(String idEscalafon) {
        this.idEscalafon = idEscalafon;
    }
    
    public Docente() {
        
        super();
        this.setIdEscalafon(JOptionPane.showInputDialog("Ingrese el id escalafon"));
    }
    
   @Override
   public void consultarInfoPersonal() {
       JOptionPane.showMessageDialog(null, "INFORMACIÓN PERSONAL DEL DOCENTE\n"
        + "ID: " +getNroID()+ "\n"
        + "Tipo ID: " +getTipoID()+ "\n"
        + "Nombres: " +getNombres()+ "\n"
        + "Apellidos: " +getApellidos()+ "\n"
        + "Direccion: " +getDireccion()+ "\n"
        + "IdEscalafon: "+getIdEscalafon()+ "\n");
   }
   
   @Override
    public void consultarHorario(){
        JOptionPane.showMessageDialog(null, "HORARIO DEL DOCENTE\n"
        + "ID: " +getNroID()+ "\n"
        + "Horario: " +getHorario()+ "\n");
    }
}
