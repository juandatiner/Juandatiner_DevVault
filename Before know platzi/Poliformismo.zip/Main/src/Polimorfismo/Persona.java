
package Polimorfismo;

import javax.swing.JOptionPane;


public class Persona {
    
    protected int NroID;

    protected String tipoID;

    protected String nombres;

    protected String apellidos;
    
    protected String direccion;
    
    protected String horario;
    
            
    
    public int getNroID() {
        return NroID;
    }


    public void setNroID(int NroID) {
        this.NroID = NroID;
    }

    public String getTipoID() {
        return tipoID;
    }

    public void setTipoID(String tipoID) {
        this.tipoID = tipoID;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }


    public Persona(){
        this.setNroID(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID")));
        this.setTipoID(JOptionPane.showInputDialog("Ingrese tipo ID"));
        this.setNombres(JOptionPane.showInputDialog("Ingrese nombres"));
        this.setApellidos(JOptionPane.showInputDialog("Ingrese apellidos"));
        this.setDireccion(JOptionPane.showInputDialog("Ingrese dirección"));
        this.setHorario(JOptionPane.showInputDialog("Ingrese horario"));
    }
    

    public void consultarInfoPersonal() {
        JOptionPane.showMessageDialog(null, "INFORMACIÓN PERSONAL\n"
        + "ID: " +getNroID()+ "\n"
        + "Tipo ID: " +getTipoID()+ "\n"
        + "Nombres: " +getNombres()+ "\n"
        + "Apellidos: " +getApellidos()+ "\n"
        + "Direccion: " +getDireccion()+ "\n");        
    }
    
    public void consultarHorario(){
        JOptionPane.showMessageDialog(null, "INFORMACIÓN PERSONAL\n"
        + "ID: " +getNroID()+ "\n"
        + "Horario: " +getHorario()+ "\n");        
    }
}
