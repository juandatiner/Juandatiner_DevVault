
package Polimorfismo;

import javax.swing.JOptionPane;

public class Estudiante extends Persona {
    
    protected float notaParcial;

    public float getNotaParcial() {
        return notaParcial;
    }

    public void setNotaParcial(float notaParcial) {
        this.notaParcial = notaParcial;
    }
    

    public Estudiante(){
        
        super();
        this.setNotaParcial(Float.parseFloat(JOptionPane.showInputDialog("Ingrese nota parcial")));
    }
    
    @Override
    public void consultarInfoPersonal() {
        JOptionPane.showMessageDialog(null, "INFORMACIÓN PERSONAL DEL ESTUDIANTE\n"
        + "ID: " +getNroID()+ "\n"
        + "Tipo ID: " +getTipoID()+ "\n"
        + "Nombres: " +getNombres()+ "\n"
        + "Apellidos: " +getApellidos()+ "\n"
        + "Direccion: " +getDireccion()+ "\n"        
        + "Nota Parcial: " +getNotaParcial()+ "\n");
    }
    
    @Override
    public void consultarHorario(){
        JOptionPane.showMessageDialog(null, "HORARIO DEL ESTUDIANTE\n"
        + "ID: " +getNroID()+ "\n"
        + "Horario: " +getHorario()+ "\n");
    }
}
