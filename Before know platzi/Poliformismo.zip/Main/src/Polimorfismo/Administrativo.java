
package Polimorfismo;

import javax.swing.JOptionPane;


public class Administrativo extends Persona{
    
    protected int salario;

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }
    
    public Administrativo (){
        
        super();
        this.setSalario(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el salario")));
    }
    
    @Override
    public void consultarInfoPersonal() {
        JOptionPane.showMessageDialog(null, "INFORMACIÓN PERSONAL DEL ADMINISTRATIVO\n"
        + "ID: " +getNroID()+ "\n"
        + "Tipo ID: " +getTipoID()+ "\n"
        + "Nombres: " +getNombres()+ "\n"
        + "Apellidos: " +getApellidos()+ "\n"
        + "Direccion: " +getDireccion()+ "\n" 
        + "Salario: " +getSalario()+ "\n");
    }
    
    @Override
    public void consultarHorario(){
        JOptionPane.showMessageDialog(null, "HORARIO DEL ADMINISTRATIVO\n"
        + "ID: " +getNroID()+ "\n"
        + "Horario: " +getHorario()+ "\n");
    }
}