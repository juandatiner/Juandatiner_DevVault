
package Polimorfismo;
import javax.swing.JOptionPane;

public class Main {


    public static void main(String[] args) {
        
        menu(); 
        
    }
    
    
    public static void menu(){
        
        String [] opciones ={"Selecciona una opción","1- Estudiantes","2- Docentes","3- Administrativos","4- Salir"};
        String [] opciones2 ={"Selecciona","1- Ingresar Estudiante","2- Consultar Estudiante","3- Consultar horario","4- Volver"};
        String [] opciones3 ={"Selecciona","1- Ingresar Docente","2- Consultar Docente","3- Consultar horario","4- Volver"};
        String [] opciones4 ={"Selecciona","1- Ingresar Administrativo","2- Consultar Administrativo","3- Consultar horario","4- Volver"};
        
        String opcion, opcion2, opcion3, opcion4;
        
        int key_estudiantes = 0;
        int key_docentes = 0;
        int key_administrativos = 0;
        boolean opcionseguire = false;
        boolean opcionseguird = false;
        boolean opcionseguira = false;
        Estudiante tempoEstudiante;
        Docente tempoDocente;
        Administrativo tempoAdministrativo;
        
        Estudiante [] est = new Estudiante [3];
        Docente [] doc = new Docente[3];
        Administrativo [] adm = new Administrativo[3];
        
        try{
        do {
            opcion = (String) JOptionPane.showInputDialog(null,"Bienvenido", "Elegir",JOptionPane.QUESTION_MESSAGE,null,opciones, opciones[0]);
            
            switch(opcion){
                
                case "1- Estudiantes":
                    do {
                    
                        opcion2 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Elegir",JOptionPane.QUESTION_MESSAGE,null,opciones2, opciones2[0]);
        
                        switch(opcion2){
                            
                            case "1- Ingresar Estudiante":
                                
                                try{
                                if (opcionseguire == false){
                                    for (key_estudiantes = 0; key_estudiantes < est.length ; key_estudiantes++) {
                                        est[key_estudiantes] = new Estudiante();
                                    }
                                    opcionseguire = true;
                                }else{
                                    JOptionPane.showMessageDialog(null, "Ya registraste 3 Estudiantes");
                                }
                                }catch(NumberFormatException e){
                                    JOptionPane.showMessageDialog(null, "Vuelve a ingresar la información");
                                }        
                            break;
                                    
                            case "2- Consultar Estudiante":
                                
                                try{
                                    for (int i = 0; i < est.length; i++) {
                                        tempoEstudiante = (Estudiante) est [i];
                                        tempoEstudiante.consultarInfoPersonal();    
                                    }
                                }catch (IndexOutOfBoundsException e){
                                    JOptionPane.showMessageDialog(null, "");
                                }catch (NullPointerException e){
                                    JOptionPane.showMessageDialog(null, "No hay estudiantes regitrados\n\n Intente:\n"
                                    + "1- Ingresar Estudiante \n\n");
                                }
                            
                            break;
                            
                            case "3- Consultar horario":
                            
                                try{
                                    for (int i = 0; i < est.length; i++) {
                                        tempoEstudiante = (Estudiante) est [i];
                                        tempoEstudiante.consultarHorario();    
                                    }
                                }catch (IndexOutOfBoundsException e){
                                    JOptionPane.showMessageDialog(null, "");
                                }catch (NullPointerException e){
                                    JOptionPane.showMessageDialog(null, "No hay estudiantes regitrados\n\n Intente:\n"
                                    + "1- Ingresar Estudiante \n\n");
                                }
                            }
                            break;       
                    }while (opcion2 != "4- Volver");
                break;
               
    
                case "2- Docentes":
                    do {
                    
                        opcion3 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Elegir",JOptionPane.QUESTION_MESSAGE,null,opciones3, opciones3[0]);
        
                        switch(opcion3){
                            
                            case "1- Ingresar Docente":
                                try{
                                if (opcionseguird == false){
                                    for (key_docentes = 0; key_docentes < doc.length ; key_docentes++) {
                                        doc[key_docentes] = new Docente();
                                    }
                                    opcionseguird = true;
                                }else{
                                    JOptionPane.showMessageDialog(null, "Ya registraste 3 Docentes");
                                }
                                }catch(NumberFormatException e){
                                    JOptionPane.showMessageDialog(null, "Vuelve a ingresar la información");
                                }  
                            break;
            
                            case "2- Consultar Docente":
                
                                try{
                                    for (int j = 0; j < doc.length; j++) {
                                        tempoDocente = (Docente) doc [j];
                                        tempoDocente.consultarInfoPersonal();    
                                    }
                                }catch (IndexOutOfBoundsException x){
                                    JOptionPane.showMessageDialog(null, "");
                                }catch (NullPointerException x){
                                    JOptionPane.showMessageDialog(null, "No hay docentes regitrados\n\n Intente:\n"
                                    + "1- Ingresar Docente \n\n");
                                }
                            break;    
                                
                            case "3- Consultar horario":
                            
                                try{
                                    for (int j = 0; j < doc.length; j++) {
                                        tempoDocente = (Docente) doc [j];
                                        tempoDocente.consultarHorario();    
                                    }
                                }catch (IndexOutOfBoundsException x){
                                    JOptionPane.showMessageDialog(null, "");
                                }catch (NullPointerException x){
                                    JOptionPane.showMessageDialog(null, "No hay docentes regitrados\n\n Intente:\n"
                                    + "1- Ingresar Docente \n\n");
                                } 
                            }
                            break;
                    }while (opcion3 != "4- Volver");    
                break;
                
                 
                case "3- Administrativos":
                    do {
                    
                        opcion4 = (String) JOptionPane.showInputDialog(null,"Selecciona una opción", "Elegir",JOptionPane.QUESTION_MESSAGE,null,opciones4, opciones4[0]);
        
                        switch(opcion4){
                            
                            case "1- Ingresar Administrativo":
                                try{
                                if (opcionseguira == false){
                                    for (key_administrativos = 0; key_administrativos < adm.length ; key_administrativos++) {
                                        adm[key_administrativos] = new Administrativo();
                                    }
                                    opcionseguira = true;
                                }else{
                                    JOptionPane.showMessageDialog(null, "Ya registraste 3 Administrativos");
                                }
                                }catch(NumberFormatException e){
                                    JOptionPane.showMessageDialog(null, "Vuelve a ingresar la información");
                                }  
                            break;
            
                            case "2- Consultar Administrativo":
                
                                try{
                                    for (int k = 0; k < adm.length; k++) {
                                        tempoAdministrativo = (Administrativo) adm [k];
                                        tempoAdministrativo.consultarInfoPersonal();    
                                    }
                                }catch (IndexOutOfBoundsException z){
                                    JOptionPane.showMessageDialog(null, "");
                                }catch (NullPointerException z){
                                    JOptionPane.showMessageDialog(null, "No hay administrativos regitrados\n\n Intente:\n"
                                    + "1- Ingresar Administrativo \n\n");
                                }
                            break;
                            
                            case "3- Consultar horario":
                            
                                try{
                                    for (int k = 0; k < adm.length; k++) {
                                        tempoAdministrativo = (Administrativo) adm [k];
                                        tempoAdministrativo.consultarHorario();    
                                    }
                                }catch (IndexOutOfBoundsException z){
                                    JOptionPane.showMessageDialog(null, "");
                                }catch (NullPointerException z){
                                    JOptionPane.showMessageDialog(null, "No hay administrativos regitrados\n\n Intente:\n"
                                    + "1- Ingresar Administrativo \n\n");
                                }
                            }    
                            break;       
                    }while (opcion3 != "4- Volver");    
                break;
            }
        }while (opcion != "4- Salir");
    }
    catch(NullPointerException q){
        JOptionPane.showMessageDialog(null, "       Cancelado con exito");
    }
}        
}    

        