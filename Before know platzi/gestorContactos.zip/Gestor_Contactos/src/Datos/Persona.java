
package Datos;

public abstract class Persona {
    
    
    protected int NroTelefono;

    protected String nombres;

    protected String apellidos;
    

    public int getNroID() {
        return NroTelefono;
    }

    public void setNroID(int NroID) {
        this.NroTelefono = NroID;
    }
    
    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }


    public Persona(){
    }
    
    
}
