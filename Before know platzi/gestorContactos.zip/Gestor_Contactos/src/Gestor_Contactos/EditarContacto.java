
package Gestor_Contactos;

import Datos.Contacto;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public final class EditarContacto extends javax.swing.JInternalFrame {

    Contacto mostrarContacto = new Contacto();
    Contacto editarContacto = new Contacto();
    
    public EditarContacto() {
        initComponents();
        mostrartabla(0,null);
    }
    
    public void mostrartabla( int opcionbuscar, String valorbuscar){
        
        
        DefaultTableModel TContactos = new DefaultTableModel();
        TContactos.addColumn("TELEFONO");
        TContactos.addColumn("NOMBRE");
        TContactos.addColumn("APELLIDO");
        TablaContactos.setModel(TContactos);

        String [] datos = new String[3];
        mostrarContacto.Mostrardatos(datos, TContactos, opcionbuscar, valorbuscar);
        TablaContactos.setModel(TContactos);
        
    }
    
    public void actualizardatos(Long id, String nombre, String apellido){
        
        editarContacto.Editardatos(id, nombre, apellido);

    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaContactos = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        ComboBoxBusqueda = new javax.swing.JComboBox<>();
        ButtonBusqueda = new javax.swing.JButton();
        TextBusqueda = new javax.swing.JTextField();
        ButtonActualizar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Editar Contacto");

        TablaContactos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(TablaContactos);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Buscar por:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 14))); // NOI18N

        ComboBoxBusqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mostrar todos", "NroTeléfono", "Nombre", "Apellido", " ", " " }));
        ComboBoxBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxBusquedaActionPerformed(evt);
            }
        });

        ButtonBusqueda.setBackground(new java.awt.Color(0, 255, 0));
        ButtonBusqueda.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        ButtonBusqueda.setText("Buscar");
        ButtonBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonBusquedaActionPerformed(evt);
            }
        });

        TextBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextBusquedaActionPerformed(evt);
            }
        });

        ButtonActualizar.setBackground(new java.awt.Color(255, 255, 51));
        ButtonActualizar.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        ButtonActualizar.setText("Actualizar");
        ButtonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonActualizarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jLabel1.setText("Los Numeros de Teléfono NO pueden ser editados.");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/formulario.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(ComboBoxBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(TextBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(ButtonBusqueda)
                        .addGap(26, 26, 26)
                        .addComponent(ButtonActualizar))
                    .addComponent(jLabel1))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ComboBoxBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ButtonBusqueda)
                            .addComponent(ButtonActualizar))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComboBoxBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxBusquedaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxBusquedaActionPerformed

    private void ButtonBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonBusquedaActionPerformed
        int opcionbuscar = ComboBoxBusqueda.getSelectedIndex();
        String valorbuscar = TextBusqueda.getText();
        mostrartabla(opcionbuscar,valorbuscar);
    }//GEN-LAST:event_ButtonBusquedaActionPerformed

    private void TextBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextBusquedaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextBusquedaActionPerformed

    private void ButtonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonActualizarActionPerformed
        
        try{
        int fila = TablaContactos.getSelectedRow();
        
        Long telefono = Long.parseLong(this.TablaContactos.getValueAt(fila, 0).toString());
        String nombre = TablaContactos.getValueAt(fila, 1).toString();
        String apellido = TablaContactos.getValueAt(fila, 2).toString();
        
        actualizardatos(telefono, nombre, apellido);
        
        }catch(ArrayIndexOutOfBoundsException e){
            JOptionPane.showMessageDialog(null, "No se ha modificado ningún dato");
        }
        
    }//GEN-LAST:event_ButtonActualizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonActualizar;
    private javax.swing.JButton ButtonBusqueda;
    private javax.swing.JComboBox<String> ComboBoxBusqueda;
    private javax.swing.JTable TablaContactos;
    private javax.swing.JTextField TextBusqueda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
