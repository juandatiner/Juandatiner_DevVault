package Gestor_Contactos;
import Funcionamiento.Conexion;
import Datos.Contacto;
import java.sql.Connection;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.Timer;

public final class Inicio extends javax.swing.JFrame {

    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar();
    Contacto mostrarContactos = new Contacto();
    Contacto vaciarla = new Contacto();
    
    public Inicio() {
        initComponents();
        //Escritorio.setBorder(new ImagenEscritorio());
        this.setExtendedState(Inicio.MAXIMIZED_BOTH);
        probarconexion();
        mostrartabla(0,null);
    }
   
    public void probarconexion (){
        if(connect == null){
            Object enunciado = "No se logró la conexión";
            JOptionPane.showMessageDialog(null, enunciado, "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
        }else{
            Object enunciado = "Conexion con exitó";
            JOptionPane.showMessageDialog(null, enunciado);
        }
    }
    
    public void mostrartabla( int opcionbuscar, String valorbuscar){
        
        int delay = 15000; // Delay en milisegundos (15 segundo = 15000 milisegundos)
        
        Timer timer = new Timer(delay, e -> mostrartabla(0, null));
        timer.start();
        
        DefaultTableModel TContactos = new DefaultTableModel();
        TContactos.addColumn("TELEFONO");
        TContactos.addColumn("NOMBRE");
        TContactos.addColumn("APELLIDO");
        TablaContactos.setModel(TContactos);

        String [] datos = new String[3];
        mostrarContactos.Mostrardatos(datos, TContactos, opcionbuscar, valorbuscar);
        TablaContactos.setModel(TContactos);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Escritorio = new javax.swing.JDesktopPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        botonBuscar = new javax.swing.JButton();
        botonAñadir = new javax.swing.JButton();
        botonVarios = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaContactos = new javax.swing.JTable();
        BotonVaciar = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        BarAdministrativos = new javax.swing.JMenu();
        ItemIngresarContacto = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        ItemEditarContacto = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        ItemEliminarContacto = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        ItemConsultarContacto = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        ItemEvaluarConexion = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        Escritorio.setToolTipText("");

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.setMaximumSize(new java.awt.Dimension(100, 100));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 36)); // NOI18N
        jLabel1.setText("CONTACTOS");

        botonBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Gestor_Contactos/buscar.png"))); // NOI18N
        botonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarActionPerformed(evt);
            }
        });

        botonAñadir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Gestor_Contactos/agregar-usuario (1).png"))); // NOI18N
        botonAñadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAñadirActionPerformed(evt);
            }
        });

        botonVarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Gestor_Contactos/usuario (1).png"))); // NOI18N
        botonVarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVariosActionPerformed(evt);
            }
        });

        TablaContactos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(TablaContactos);

        BotonVaciar.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        BotonVaciar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Gestor_Contactos/borrar.png"))); // NOI18N
        BotonVaciar.setText("Vaciar");
        BotonVaciar.setToolTipText("");
        BotonVaciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVaciarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane1)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(botonAñadir, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(botonBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(botonVarios, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(BotonVaciar, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(botonBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonAñadir, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonVarios, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(37, 37, 37)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 451, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonVaciar, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        Escritorio.setLayer(jPanel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout EscritorioLayout = new javax.swing.GroupLayout(Escritorio);
        Escritorio.setLayout(EscritorioLayout);
        EscritorioLayout.setHorizontalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addGap(143, 143, 143)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(411, Short.MAX_VALUE))
        );
        EscritorioLayout.setVerticalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        BarAdministrativos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/directorio-telefonico.png"))); // NOI18N
        BarAdministrativos.setText("Contactos");

        ItemIngresarContacto.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemIngresarContacto.setText("Ingresar");
        ItemIngresarContacto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemIngresarContactoActionPerformed(evt);
            }
        });
        BarAdministrativos.add(ItemIngresarContacto);
        BarAdministrativos.add(jSeparator1);

        ItemEditarContacto.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemEditarContacto.setText("Editar");
        ItemEditarContacto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemEditarContactoActionPerformed(evt);
            }
        });
        BarAdministrativos.add(ItemEditarContacto);
        BarAdministrativos.add(jSeparator2);

        ItemEliminarContacto.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemEliminarContacto.setText("Eliminar");
        ItemEliminarContacto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemEliminarContactoActionPerformed(evt);
            }
        });
        BarAdministrativos.add(ItemEliminarContacto);
        BarAdministrativos.add(jSeparator3);

        ItemConsultarContacto.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemConsultarContacto.setText("Consultar");
        ItemConsultarContacto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemConsultarContactoActionPerformed(evt);
            }
        });
        BarAdministrativos.add(ItemConsultarContacto);

        jMenuBar1.add(BarAdministrativos);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/reparar.png"))); // NOI18N
        jMenu1.setText("Ayuda");

        ItemEvaluarConexion.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.ALT_DOWN_MASK | java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemEvaluarConexion.setText("Evaluar Conexion");
        ItemEvaluarConexion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemEvaluarConexionActionPerformed(evt);
            }
        });
        jMenu1.add(ItemEvaluarConexion);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Escritorio)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Escritorio)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ItemIngresarContactoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemIngresarContactoActionPerformed
        IngresarContacto verventana = new IngresarContacto();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemIngresarContactoActionPerformed

    private void ItemEliminarContactoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemEliminarContactoActionPerformed
        EliminarConctacto verventana = new EliminarConctacto();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemEliminarContactoActionPerformed

    private void ItemEditarContactoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemEditarContactoActionPerformed
        EditarContacto verventana = new EditarContacto();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemEditarContactoActionPerformed

    private void ItemConsultarContactoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemConsultarContactoActionPerformed
        ConsultarContacto verventana = new ConsultarContacto();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemConsultarContactoActionPerformed

    private void ItemEvaluarConexionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemEvaluarConexionActionPerformed
        probarconexion();
    }//GEN-LAST:event_ItemEvaluarConexionActionPerformed

    private void botonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarActionPerformed
        ConsultarContacto verventana = new ConsultarContacto();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_botonBuscarActionPerformed

    private void botonAñadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAñadirActionPerformed
        IngresarContacto verventana = new IngresarContacto();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_botonAñadirActionPerformed

    private void botonVariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVariosActionPerformed
        EditarContacto verventana = new EditarContacto();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_botonVariosActionPerformed

    private void BotonVaciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVaciarActionPerformed
        
        int vaciar = JOptionPane.showConfirmDialog(null, "¿Desea Vaciar su lista de contactos?", "Confirmar Vaciar", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        
        if (vaciar == 0){
            vaciarla.Vaciarlista();
            JOptionPane.showMessageDialog(null, "Su lista se vacío con exito");
        }
        else{
            
        }
        
    }//GEN-LAST:event_BotonVaciarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new RunnableImpl());
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu BarAdministrativos;
    private javax.swing.JButton BotonVaciar;
    public static javax.swing.JDesktopPane Escritorio;
    private javax.swing.JMenuItem ItemConsultarContacto;
    private javax.swing.JMenuItem ItemEditarContacto;
    private javax.swing.JMenuItem ItemEliminarContacto;
    private javax.swing.JMenuItem ItemEvaluarConexion;
    private javax.swing.JMenuItem ItemIngresarContacto;
    private javax.swing.JTable TablaContactos;
    private javax.swing.JButton botonAñadir;
    private javax.swing.JButton botonBuscar;
    private javax.swing.JButton botonVarios;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    // End of variables declaration//GEN-END:variables

    private static class RunnableImpl implements Runnable {

        public RunnableImpl() {
        }

        @Override
        public void run() {
            new Inicio().setVisible(true);
        }
    }
}
