
package Funcionamiento;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {
    
    Connection enlazar = null;
    
    public Connection conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            enlazar = DriverManager.getConnection(
        "jdbc:mysql://aws.connect.psdb.cloud/gestorcontactos?sslMode=VERIFY_IDENTITY",
  "ojbi2if6ik24xhxuxwlf",
  "pscale_pw_HkiksNldtmybvDDVcHHdOThXHcZWnSntcgmCoKZQGOB");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No fue posible establecer la conexión");
        }
        return enlazar;
    }
    
}
