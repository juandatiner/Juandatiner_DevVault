
package clases.genericas;
public class GenericaK <K>{
    
    public K valor;
    
    public void setValor(K valor){
        this.valor = valor;
    }
    
    public K getValor(){
        return valor;
    }
    
    public void mostrarTipo(){
        System.out.println("El tipo de K es:"+valor.getClass().getName()
        +"\n"+"Vuelve a intentar bro");
    }
}
