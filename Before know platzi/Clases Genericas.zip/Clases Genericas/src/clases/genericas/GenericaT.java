
package clases.genericas;
public class GenericaT <T>{
    
    public T valor;
    
    public void setValor(T valor){
        this.valor = valor;
    }
    
    public T getValor(){
        return valor;
    }
    
    public void mostrarTipo(){
        System.out.println("El tipo de T es:"+valor.getClass().getName()
        +"\n"+"Vuelve a intentar bro");
    }
}
