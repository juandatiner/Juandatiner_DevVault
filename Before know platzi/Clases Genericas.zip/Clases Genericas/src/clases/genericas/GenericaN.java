
package clases.genericas;
public class GenericaN <N> {
   
    public N valor;
    
    public void setValor(N valor){
        this.valor = valor;
    }
    
    public N getValor(){
        return valor;
    }
    
    public void mostrarTipo(){
        System.out.println("El tipo de N es:"+valor.getClass().getName()
        +"\n"+"Vuelve a intentar bro");
    } 
}
