
package clases.genericas;
import java.util.Scanner;
public class ClasesGenericas {

    public static void main(String[] args) throws InterruptedException {
        Scanner entrada = new Scanner(System.in);
        GenericaT <Integer> genericaT = new GenericaT<Integer>();
        GenericaV <Double> genericaV = new GenericaV<Double>();
        GenericaK <String> genericaK = new GenericaK<String>();
        GenericaN <Boolean> genericaN = new GenericaN<Boolean>();
        genericaT.setValor(0);
        genericaV.setValor(0.0);
        genericaK.setValor("");
        genericaN.setValor(false);
        System.out.println("Todos los valores ingresados deben ser diferentes a 0");
        do{
        try{
            System.out.println("Ingrese el valor de T");
            int resultado = entrada.nextInt();
            genericaT.setValor(resultado);
            genericaT.getValor();
            if (genericaT.valor != 0){
                System.out.println("Valor: " +resultado);}
        }catch(java.util.InputMismatchException e){
            genericaT.mostrarTipo();
            break;
        }
        
        do{
        try{
            System.out.println("Ingrese el valor de V");
            double resultadoV = entrada.nextDouble();
            genericaV.setValor(resultadoV);
            genericaV.getValor();
            if (genericaV.valor != 0.0){
                System.out.println("Valor: " +resultadoV);}
        }catch(java.util.InputMismatchException e){
            genericaV.mostrarTipo();
            break;
        }
        
        do{
        try{
            System.out.println("Ingrese el valor de K");
            String resultado = entrada.next();
            genericaK.setValor(resultado);
            genericaK.getValor();
            if (genericaK.valor != ""){
                System.out.println("Valor: " +resultado);}
        }catch(java.util.InputMismatchException e){
            genericaK.mostrarTipo();
            break;
        }
        
        do{
        try{
            System.out.println("Ingrese el valor de N");
            Boolean resultado = entrada.nextBoolean();
            genericaN.setValor(resultado);
            genericaN.getValor();
            if (genericaN.valor != false){
                System.out.println("Valor: " +resultado);}
        }catch(java.util.InputMismatchException e){
            genericaN.mostrarTipo();
            break;
        }
        
        }while (genericaN.valor == false);
        }while (genericaK.valor == "");
        }while (genericaV.valor == 0.0);
        }while (genericaT.valor == 0);
    } 
}
