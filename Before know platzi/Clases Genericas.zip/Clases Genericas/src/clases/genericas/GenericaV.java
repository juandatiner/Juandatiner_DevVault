
package clases.genericas;
public class GenericaV <V>{
    
    public V valor;
    
    public void setValor(V valor){
        this.valor = valor;
    }
    
    public V getValor(){
        return valor;
    }
    
    public void mostrarTipo(){
        System.out.println("El tipo de V es:"+valor.getClass().getName()
        +"\n"+"Vuelve a intentar bro");
    }
}
