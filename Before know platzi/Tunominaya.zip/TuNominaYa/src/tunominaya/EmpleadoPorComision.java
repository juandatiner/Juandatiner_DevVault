
package tunominaya;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class EmpleadoPorComision extends Empleado {
    
    public int VentasTotales;
    public double ValorVenta;
    
    DecimalFormat objDF = new DecimalFormat();
    
    public int getVentasTotales() {
        return VentasTotales;
    }

    public void setVentasTotales(int VentasTotales) {
        this.VentasTotales = VentasTotales;
    }

    public double getValorVenta() {
        return ValorVenta;
    }

    public void setValorVenta(double ValorVenta) {
        this.ValorVenta = ValorVenta;
    }
    
    public EmpleadoPorComision(){
        super();
        this.setVentasTotales(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de ventas totales: ")));
        this.setValorVenta(2000);
    }
    
    @Override
    public void ConsultarInfo(){ 
        JOptionPane.showMessageDialog(null, "INFORMACION DEL EMPLEADO\n"
                + "Nombre: " + getNombre()+ "\n"
                + "Apellido: " + getApellido()+ "\n"
                + "N.S.S: " + getNumSSocial() + "\n" 
                + "Comisión por ventas: " + objDF.format (getValorVenta()* getVentasTotales()) + "\n");
    }
}