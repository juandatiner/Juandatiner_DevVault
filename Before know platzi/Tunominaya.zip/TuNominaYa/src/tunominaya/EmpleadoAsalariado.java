
package tunominaya;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;
public class EmpleadoAsalariado extends Empleado{

    public int salariobase;
    
    DecimalFormat objDF = new DecimalFormat();
    

    public int getSalariobase() {
        return salariobase;
    }

    public void setSalariobase(int salariobase) {
        this.salariobase = salariobase;
    }
    
    public EmpleadoAsalariado(){
        super();
        this.setSalariobase(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el salario base: ")));
    }
    
    @Override
    public void ConsultarInfo(){
        JOptionPane.showMessageDialog(null, "INFORMACION DEL EMPLEADO\n"
                + "Nombre: " + getNombre()+ "\n"
                + "Apellido: " + getApellido()+ "\n"
                + "N.S.S: " + getNumSSocial() + "\n"
                + "Salario: " + objDF.format (getSalariobase()) + "\n");
        
    } 
  }

