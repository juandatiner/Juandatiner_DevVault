
package tunominaya;

import javax.swing.JOptionPane;

public abstract class Empleado {

    public String Nombre;
    public String Apellido;
    public int NumSSocial;
       
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getNumSSocial() {
        return NumSSocial;
    }

    public void setNumSSocial(int NumSSocial) {
        this.NumSSocial = NumSSocial;
    }

    public Empleado(){
        this.setNombre(JOptionPane.showInputDialog("Ingrese el nombre: "));
        this.setApellido(JOptionPane.showInputDialog("Ingrese el apellido: "));
        this.setNumSSocial(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero de Seguro Social: ")));
    }
    
    public void ConsultarInfo(){
        JOptionPane.showMessageDialog(null, "INFORMACION DEL EMPLEADO\n"
                + "Nombre: " + getNombre()+ "\n"
                + "Apellido: " + getApellido()+ "\n"
                + "N.S.S: " + getNumSSocial() + "\n");
    }
}

