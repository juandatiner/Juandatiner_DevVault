
package TuNominaYa;
import java.util.HashMap;
import javax.swing.JOptionPane;
import tunominaya.EmpleadoAsalariado;
import tunominaya.EmpleadoBaseMasComision;
import tunominaya.EmpleadoPorComision;
import tunominaya.EmpleadoPorHoras;
public class Nomina{

   public static void main( String[] args ) {
       
       menu();
      
   } 

    private static void menu() {
    
        String [] opciones = {"Seleccione el tipo de empleado", "- Empleado Asalariado", "- Empleado por comisión", "- Empleado base más comisión", "- Empleado por horas", "- Salir"};
        String [] opciones2 = {"Selecciona una opción","- Ingresar Empleado", "- Editar Empleado", "- Eliminar Empleado", "- Mostrar empleados", "- Volver"};
        String opcion, opcion2;
        int key_Empleado = 0;
        EmpleadoAsalariado asalariado;
        EmpleadoPorComision comision;
        EmpleadoBaseMasComision mascomision;
        EmpleadoPorHoras porhoras;
        HashMap<Integer, EmpleadoAsalariado> listaAsalariado = new HashMap<Integer, EmpleadoAsalariado>();
        HashMap<Integer, EmpleadoPorComision> listaComision = new HashMap<Integer, EmpleadoPorComision>();
        HashMap<Integer, EmpleadoBaseMasComision> listaMascomision = new HashMap<Integer, EmpleadoBaseMasComision>();
        HashMap<Integer, EmpleadoPorHoras> listaHoras = new HashMap<Integer, EmpleadoPorHoras>();
        
        try{
            do{
                opcion = (String) JOptionPane.showInputDialog(null, "Bienvenido", "Tu nomina ya", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
            
                switch (opcion){
                
                    case "- Empleado Asalariado":
                        do{
                            opcion2 = (String) JOptionPane.showInputDialog(null, "- Empleado Asalariado", "Tu nomina ya", JOptionPane.QUESTION_MESSAGE, null, opciones2, opciones2[0]);
                            
                            switch (opcion2){
                                
                                case "- Ingresar Empleado":
                                    try{
                                    int num_añadir = (Integer.parseInt(JOptionPane.showInputDialog("¿Cuantos Empleados quieres ingresar?"))) + 1;
                                    
                                        for (int num_empleados = 1; num_empleados < num_añadir; num_empleados++) {
                                            
                                            EmpleadoAsalariado a = new EmpleadoAsalariado();
                                            listaAsalariado.put(key_Empleado, a );
                                            key_Empleado++;
                                            
                                        }JOptionPane.showMessageDialog(null, "       Ingreso con éxito");
                                    }catch(NumberFormatException x){
                                    JOptionPane.showMessageDialog(null, "Vuelve a ingresar la información");
                                }
                                break;    
    
                                case "- Editar Empleado":
                                    if (listaAsalariado.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado Asalariado registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaAsalariado.size() ; i++) {
                                        asalariado = (EmpleadoAsalariado) listaAsalariado.get(i);
                                        JOptionPane.showMessageDialog(null,"Empleado: "+ (i+1));
                                        asalariado.ConsultarInfo();
                                        }
                                        int edit = (Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuál empleado quiere editar?"))) - 1;
                                        if (listaAsalariado.containsKey(edit)){
                                            EmpleadoAsalariado a = new EmpleadoAsalariado();
                                            listaAsalariado.put(edit, a );
                                            JOptionPane.showMessageDialog(null, "       Editado con éxito");
                                        }else{
                                            JOptionPane.showMessageDialog(null, "No hay ningún Empleado con este identificador");  
                                        }
                                    }   
                                break;
                                
                                case "- Eliminar Empleado":
                                    if (listaAsalariado.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado Asalariado registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaAsalariado.size() ; i++) {
                                        asalariado = (EmpleadoAsalariado) listaAsalariado.get(i);
                                        JOptionPane.showMessageDialog(null,"Empleado: "+ (i+1));
                                        asalariado.ConsultarInfo();
                                        }
                                        int delete = (Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuál empleado quiere eliminar?"))) - 1;
                                        if (listaAsalariado.containsKey(delete)){                                           
                                            listaAsalariado.remove(delete);
                                            JOptionPane.showMessageDialog(null, "       Eliminado con éxito");
                                        }else{
                                            JOptionPane.showMessageDialog(null, "No hay ningún Empleado con este identificador");  
                                        }
                                    } 
                                break;
                                
                                case "- Mostrar empleados":
                                    
                                    if (listaAsalariado.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado Asalariado registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaAsalariado.size() ; i++) {
                                        asalariado = (EmpleadoAsalariado) listaAsalariado.get(i);
                                        asalariado.ConsultarInfo();
                                    }
                                    }
                                break;
                            }       
                        }while(opcion2 != "- Volver");
                    break;
                    
                    case "- Empleado por comisión":
                        do{
                            opcion2 = (String) JOptionPane.showInputDialog(null, "Selecciona una opcion", "Empleado por comisión", JOptionPane.QUESTION_MESSAGE, null, opciones2, opciones2[0]);
                            
                            switch (opcion2){
                                
                                case "- Ingresar Empleado":
                                    try{
                                    int num_añadir = (Integer.parseInt(JOptionPane.showInputDialog("¿Cuantos Empleados quieres ingresar?"))) + 1;
                                    
                                        for (int num_empleados = 1; num_empleados < num_añadir; num_empleados++) {
                                            
                                            EmpleadoPorComision c = new EmpleadoPorComision();
                                            listaComision.put(key_Empleado, c );
                                            key_Empleado++;
                                            
                                        }JOptionPane.showMessageDialog(null, "       Ingreso con éxito");
                                    }catch(NumberFormatException x){
                                    JOptionPane.showMessageDialog(null, "Vuelve a ingresar la información");
                                }
                                break;
                                
                                case "- Editar Empleado":
                                    if (listaComision.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado por Comisión registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaComision.size() ; i++) {
                                        comision = (EmpleadoPorComision) listaComision.get(i);
                                        JOptionPane.showMessageDialog(null,"Empleado: "+ (i+1));
                                        comision.ConsultarInfo();
                                        }
                                        int edit = (Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuál empleado quiere editar?"))) - 1;
                                        if (listaComision.containsKey(edit)){
                                            EmpleadoPorComision c = new EmpleadoPorComision();
                                            listaComision.put(edit, c );
                                            JOptionPane.showMessageDialog(null, "       Editado con éxito");
                                        }else{
                                            JOptionPane.showMessageDialog(null, "No hay ningún Empleado con este identificador");  
                                        }
                                    }   
                                break;
                                
                                case "- Eliminar Empleado":
                                    if (listaComision.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado por Comisión registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaComision.size() ; i++) {
                                        comision = (EmpleadoPorComision) listaComision.get(i);
                                        JOptionPane.showMessageDialog(null,"Empleado: "+ (i+1));
                                        comision.ConsultarInfo();
                                        }
                                        int delete = (Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuál empleado quiere eliminar?"))) - 1;
                                        if (listaComision.containsKey(delete)){                                           
                                            listaComision.remove(delete);
                                            JOptionPane.showMessageDialog(null, "       Eliminado con éxito");
                                        }else{
                                            JOptionPane.showMessageDialog(null, "No hay ningún Empleado con este identificador");  
                                        }
                                    } 
                                break;
                                
                                case "- Mostrar empleados":
                                    
                                    if (listaComision.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado por Comisión registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaComision.size() ; i++) {
                                        comision = (EmpleadoPorComision) listaComision.get(i);
                                        comision.ConsultarInfo();
                                    }
                                    }
                                break;
                            }   
                        }while(opcion2 != "- Volver");
                    break;
                    
                    case "- Empleado base más comisión":
                        do{
                            opcion2 = (String) JOptionPane.showInputDialog(null, "Selecciona una opcion", "Empleado base más comisión", JOptionPane.QUESTION_MESSAGE, null, opciones2, opciones2[0]);
                            
                            switch (opcion2){
                                
                                case "- Ingresar Empleado":
                                    try{
                                    int num_añadir = (Integer.parseInt(JOptionPane.showInputDialog("¿Cuantos Empleados quieres ingresar?"))) + 1;
                                    
                                        for (int num_empleados = 1; num_empleados < num_añadir; num_empleados++) {
                                            
                                            EmpleadoBaseMasComision m = new EmpleadoBaseMasComision();
                                            listaMascomision.put(key_Empleado, m );
                                            key_Empleado++;
                                            
                                        }JOptionPane.showMessageDialog(null, "       Ingreso con éxito");
                                    }catch(NumberFormatException x){
                                    JOptionPane.showMessageDialog(null, "Vuelve a ingresar la información");
                                }
                                break;
                                
                                case "- Editar Empleado":
                                    if (listaMascomision.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado base más comisión registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaMascomision.size() ; i++) {
                                        mascomision = (EmpleadoBaseMasComision) listaMascomision.get(i);
                                        JOptionPane.showMessageDialog(null,"Empleado: "+ (i+1));
                                        mascomision.ConsultarInfo();
                                        }
                                        int edit = (Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuál empleado quiere editar?"))) - 1;
                                        if (listaMascomision.containsKey(edit)){
                                            EmpleadoBaseMasComision m = new EmpleadoBaseMasComision();
                                            listaMascomision.put(edit, m );
                                            JOptionPane.showMessageDialog(null, "       Editado con éxito");
                                        }else{
                                            JOptionPane.showMessageDialog(null, "No hay ningún Empleado con este identificador");  
                                        }
                                    }   
                                break;
                                
                                case "- Eliminar Empleado":
                                    if (listaMascomision.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado base más comisión registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaMascomision.size() ; i++) {
                                        mascomision = (EmpleadoBaseMasComision) listaMascomision.get(i);
                                        JOptionPane.showMessageDialog(null,"Empleado: "+ (i+1));
                                        mascomision.ConsultarInfo();
                                        }
                                        int delete = (Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuál empleado quiere eliminar?"))) - 1;
                                        if (listaMascomision.containsKey(delete)){                                           
                                            listaMascomision.remove(delete);
                                            JOptionPane.showMessageDialog(null, "       Eliminado con éxito");
                                        }else{
                                            JOptionPane.showMessageDialog(null, "No hay ningún Empleado con este identificador");  
                                        }
                                    } 
                                break;
                                
                                case "- Mostrar empleados":
                                    
                                    if (listaMascomision.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado base más comisión registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaMascomision.size() ; i++) {
                                        mascomision = (EmpleadoBaseMasComision) listaMascomision.get(i);
                                        mascomision.ConsultarInfo();
                                    }
                                    }
                                break;
                            }   
                        }while(opcion2 != "- Volver");
                    break;    
                    
                    case "- Empleado por horas":
                        do{
                            opcion2 = (String) JOptionPane.showInputDialog(null, "Selecciona una opcion", "Empleado por horas", JOptionPane.QUESTION_MESSAGE, null, opciones2, opciones2[0]);
                            
                            switch (opcion2){
                                
                                case "- Ingresar Empleado":
                                    try{
                                    int num_añadir = (Integer.parseInt(JOptionPane.showInputDialog("¿Cuantos Empleados quieres ingresar?"))) + 1;
                                    
                                        for (int num_empleados = 1; num_empleados < num_añadir; num_empleados++) {
                                            
                                            EmpleadoPorHoras h = new EmpleadoPorHoras();
                                            listaHoras.put(key_Empleado, h );
                                            key_Empleado++;
                                            
                                        }JOptionPane.showMessageDialog(null, "       Ingreso con éxito");
                                    }catch(NumberFormatException x){
                                    JOptionPane.showMessageDialog(null, "Vuelve a ingresar la información");
                                }
                                break;
                                
                                case "- Editar Empleado":
                                    if (listaHoras.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado por horas registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaHoras.size() ; i++) {
                                        porhoras = (EmpleadoPorHoras) listaHoras.get(i);
                                        JOptionPane.showMessageDialog(null,"Empleado: "+ (i+1));
                                        porhoras.ConsultarInfo();
                                        }
                                        int edit = (Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuál empleado quiere editar?"))) - 1;
                                        if (listaHoras.containsKey(edit)){
                                            EmpleadoPorHoras h = new EmpleadoPorHoras();
                                            listaHoras.put(edit, h );
                                            JOptionPane.showMessageDialog(null, "       Editado con éxito");
                                        }else{
                                            JOptionPane.showMessageDialog(null, "No hay ningún Empleado con este identificador");  
                                        }
                                    }   
                                break;
                                
                                case "- Eliminar Empleado":
                                    if (listaHoras.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado por horas registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaHoras.size() ; i++) {
                                        porhoras = (EmpleadoPorHoras) listaHoras.get(i);
                                        JOptionPane.showMessageDialog(null,"Empleado: "+ (i+1));
                                        porhoras.ConsultarInfo();
                                        }
                                        int delete = (Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuál empleado quiere eliminar?"))) - 1;
                                        if (listaHoras.containsKey(delete)){                                           
                                            listaHoras.remove(delete);
                                            JOptionPane.showMessageDialog(null, "       Eliminado con éxito");
                                        }else{
                                            JOptionPane.showMessageDialog(null, "No hay ningún Empleado con este identificador");  
                                        }
                                    } 
                                break;
                                
                                case "- Mostrar empleados":
                                    
                                    if (listaHoras.isEmpty()){
                                        JOptionPane.showMessageDialog(null, "No hay ningún Empleado por horas registrado\n\n Intente:\n"
                                        + "- Ingresar Empleado \n");
                                    }else{
                                        for (int i = 0; i < listaHoras.size() ; i++) {
                                        porhoras = (EmpleadoPorHoras) listaHoras.get(i);
                                        porhoras.ConsultarInfo();
                                    }
                                    }
                                break;
                            }  
                        }while(opcion2 != "- Volver");
                    break;    
                } 
            }while(opcion != "- Salir");    
        }
        catch(NullPointerException q){
            JOptionPane.showMessageDialog(null,  "       Cancelado con éxito");
        }
    }
} 