
package tunominaya;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;
public class EmpleadoPorHoras extends Empleado{

    public int Horas;
    public double ValorHora;
    
    DecimalFormat objDF = new DecimalFormat();
    
    public int getHoras() {
        return Horas;
    }

    public void setHoras(int Horas) {
        this.Horas = Horas;
    }

    public double getValorHora() {
        return ValorHora;
    }

    public void setValorHora(double ValorHora) {
        this.ValorHora = ValorHora;
    }
    
    public EmpleadoPorHoras(){
        super();
        this.setHoras(Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de horas trabajadas: ")));
        this.setValorHora(4200);
    }
    
    @Override
    public void ConsultarInfo(){
        JOptionPane.showMessageDialog(null, "INFORMACION DEL EMPLEADO\n"
                + "Nombre: " + getNombre()+ "\n"
                + "Apellido: " + getApellido()+ "\n"
                + "N.S.S: " + getNumSSocial() + "\n" 
                + "Salario por horas: " + objDF.format (getHoras()* getValorHora()) + "\n");
    }
}
