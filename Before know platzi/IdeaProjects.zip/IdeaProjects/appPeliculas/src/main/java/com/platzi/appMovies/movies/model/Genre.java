package com.platzi.appMovies.movies.model;

public enum Genre {

    ACTION, COMEDY, DRAMA, HORROR, THRILLER
}
