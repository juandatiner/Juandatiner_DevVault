package CAPA_PRESENTACION;

import CAPA_NEGOCIO.DataArticulo;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author cosmo
 */

public class Formulario_Articulo extends javax.swing.JFrame {

    TableRowSorter<DefaultTableModel>sorter;
    
    public Formulario_Articulo() {
        initComponents();
        ListarArticulos();
    }

    public void ListarArticulos(){
        DefaultTableModel tabla=new DefaultTableModel();
        DataArticulo objart=new DataArticulo();
        ArrayList<DataArticulo> lista2=new ArrayList();
        lista2=objart.ListaArticulos();
        tabla.addColumn("Codigo");
        tabla.addColumn("Nombre");
        tabla.addColumn("Unidad");
        tabla.addColumn("Precio");
        tabla.addColumn("Stock");
        tabla.addColumn("Marca");
        tabla.setRowCount(lista2.size());
        int i=0;
        for (DataArticulo x: lista2){
            tabla.setValueAt(x.getArt_cod(), i, 0);
            tabla.setValueAt(x.getArt_nom(), i, 1);
            tabla.setValueAt(x.getArt_uni(), i, 2);
            tabla.setValueAt(x.getArt_pre(), i, 3);
            tabla.setValueAt(x.getArt_stk(), i, 4);
            tabla.setValueAt(x.getArt_marca(), i, 5);
            i++;
        }
        this.Tabla.setModel(tabla);

        //METODO PARA FILTRAR
        Tabla.setAutoCreateRowSorter(true);
        sorter = new TableRowSorter<>(tabla);
        Tabla.setRowSorter(sorter);

    }
    
    private void filtrar(){
        //FILTRAR
        try{
            sorter.setRowFilter(RowFilter.regexFilter(TEXTFILTRAR.getText().toUpperCase()));
        }catch(Exception e){

        }
    }
    
    public void limpiar(){
        this.TEXTCODIGO.setText("");
        this.TEXTNOMBRE.setText("");
        this.TEXTUNIDAD.setText("");
        this.TEXTPRECIO.setText("");
        this.TEXTSTOCK.setText("");
        this.TEXTMARCA.setText("");
    }
    
    public void editar(){    
        DataArticulo objart=new DataArticulo();
        objart.setArt_cod(this.TEXTCODIGO.getText());
        objart.setArt_nom(this.TEXTNOMBRE.getText());
        objart.setArt_uni(this.TEXTUNIDAD.getText());
        objart.setArt_pre(Double.parseDouble(this.TEXTPRECIO.getText()));
        objart.setArt_stk(Integer.parseInt(this.TEXTSTOCK.getText()));
        objart.setArt_marca(this.TEXTMARCA.getText());
        JOptionPane.showMessageDialog(null, objart.EditarArticulo());
        ListarArticulos();
    }
    
    public void eliminar(){
        int Res=JOptionPane.showConfirmDialog(null, "Esta seguro de Eliminar el Articulo: "+this.TEXTCODIGO.getText());
        if(Res==0){
            DataArticulo objart=new DataArticulo();
            objart.setArt_cod(this.TEXTCODIGO.getText());
            JOptionPane.showMessageDialog(null, objart.EliminarArticulo());
            ListarArticulos();
            JOptionPane.showMessageDialog(null, "Articulo Eliminado");
        }
    }
    
    public void crear(){
        DataArticulo objart=new DataArticulo();
        objart.setArt_cod(this.TEXTCODIGO.getText());
        objart.setArt_nom(this.TEXTNOMBRE.getText());
        objart.setArt_uni(this.TEXTUNIDAD.getText());
        objart.setArt_pre(Double.parseDouble(this.TEXTPRECIO.getText()));
        objart.setArt_stk(Integer.parseInt(this.TEXTSTOCK.getText()));
        objart.setArt_marca(this.TEXTMARCA.getText());
        JOptionPane.showMessageDialog(null, objart.CrearArticulo());
        ListarArticulos();
    }
    
    public void salir(){
        int r=JOptionPane.showConfirmDialog(null, "Esta Seguro?");
        if(r==0){
            System.exit(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane10 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        BOTONCREAR = new javax.swing.JButton();
        BOTONEDITAR = new javax.swing.JButton();
        BOTONELIMINAR = new javax.swing.JButton();
        BOTONLIMPIAR = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        BOTONSALIR = new javax.swing.JButton();
        TEXTCODIGO = new javax.swing.JTextField();
        TEXTNOMBRE = new javax.swing.JTextField();
        TEXTUNIDAD = new javax.swing.JTextField();
        TEXTPRECIO = new javax.swing.JTextField();
        TEXTSTOCK = new javax.swing.JTextField();
        TEXTMARCA = new javax.swing.JTextField();
        TEXTFILTRAR = new javax.swing.JTextField();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jScrollPane10.setViewportView(jEditorPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TablaMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(Tabla);

        jLabel1.setText("CODIGO");

        BOTONCREAR.setText("CREAR");
        BOTONCREAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOTONCREARActionPerformed(evt);
            }
        });

        BOTONEDITAR.setText("EDITAR");
        BOTONEDITAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOTONEDITARActionPerformed(evt);
            }
        });

        BOTONELIMINAR.setText("ELIMINAR");
        BOTONELIMINAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOTONELIMINARActionPerformed(evt);
            }
        });

        BOTONLIMPIAR.setText("LIMPIAR");
        BOTONLIMPIAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOTONLIMPIARActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 2, 36)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("ARTICULO");

        jLabel3.setText("NOMBRE");

        jLabel4.setText("UNIDAD");

        jLabel5.setText("PRECIO");

        jLabel6.setText("MARCA");

        jLabel7.setText("STOCK");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setText("Filtrar");
        jLabel8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jLabel8KeyReleased(evt);
            }
        });

        BOTONSALIR.setText("SALIR");
        BOTONSALIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOTONSALIRActionPerformed(evt);
            }
        });

        TEXTCODIGO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TEXTCODIGOActionPerformed(evt);
            }
        });

        TEXTFILTRAR.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TEXTFILTRARKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(407, 407, 407)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6))
                .addGap(188, 188, 188)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(TEXTCODIGO)
                    .addComponent(TEXTMARCA, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                    .addComponent(TEXTSTOCK)
                    .addComponent(TEXTPRECIO)
                    .addComponent(TEXTUNIDAD)
                    .addComponent(TEXTNOMBRE))
                .addGap(240, 240, 240))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(BOTONSALIR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BOTONEDITAR)
                .addGap(92, 92, 92)
                .addComponent(BOTONELIMINAR)
                .addGap(93, 93, 93)
                .addComponent(BOTONLIMPIAR)
                .addGap(95, 95, 95))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TEXTFILTRAR, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BOTONCREAR)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 667, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(67, 67, 67))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(TEXTCODIGO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(TEXTNOMBRE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(TEXTUNIDAD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TEXTPRECIO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TEXTSTOCK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(14, 14, 14)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TEXTMARCA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(274, 274, 274)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TEXTFILTRAR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BOTONLIMPIAR)
                    .addComponent(BOTONELIMINAR)
                    .addComponent(BOTONEDITAR)
                    .addComponent(BOTONCREAR)
                    .addComponent(BOTONSALIR))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BOTONCREARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOTONCREARActionPerformed
        crear();
    }//GEN-LAST:event_BOTONCREARActionPerformed

    private void BOTONEDITARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOTONEDITARActionPerformed
        editar();
    }//GEN-LAST:event_BOTONEDITARActionPerformed

    private void BOTONELIMINARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOTONELIMINARActionPerformed
        eliminar();
    }//GEN-LAST:event_BOTONELIMINARActionPerformed

    private void BOTONLIMPIARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOTONLIMPIARActionPerformed
        limpiar();
    }//GEN-LAST:event_BOTONLIMPIARActionPerformed

    private void TablaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaMousePressed
        int rec=this.Tabla.getSelectedRow();
        this.TEXTCODIGO.setText(Tabla.getValueAt(rec, 0).toString());
        this.TEXTNOMBRE.setText(Tabla.getValueAt(rec, 1).toString());
        this.TEXTUNIDAD.setText(Tabla.getValueAt(rec, 2).toString());
        this.TEXTPRECIO.setText(Tabla.getValueAt(rec, 3).toString());
        this.TEXTSTOCK.setText(Tabla.getValueAt(rec, 4).toString());
        this.TEXTMARCA.setText(Tabla.getValueAt(rec, 5).toString());
    }//GEN-LAST:event_TablaMousePressed

    private void BOTONSALIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOTONSALIRActionPerformed
        salir();
    }//GEN-LAST:event_BOTONSALIRActionPerformed

    private void TEXTCODIGOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TEXTCODIGOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TEXTCODIGOActionPerformed

    private void jLabel8KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jLabel8KeyReleased
        
    }//GEN-LAST:event_jLabel8KeyReleased

    private void TEXTFILTRARKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TEXTFILTRARKeyReleased
        filtrar();
    }//GEN-LAST:event_TEXTFILTRARKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Formulario_Articulo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Formulario_Articulo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Formulario_Articulo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Formulario_Articulo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Formulario_Articulo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BOTONCREAR;
    private javax.swing.JButton BOTONEDITAR;
    private javax.swing.JButton BOTONELIMINAR;
    private javax.swing.JButton BOTONLIMPIAR;
    private javax.swing.JButton BOTONSALIR;
    private javax.swing.JTextField TEXTCODIGO;
    private javax.swing.JTextField TEXTFILTRAR;
    private javax.swing.JTextField TEXTMARCA;
    private javax.swing.JTextField TEXTNOMBRE;
    private javax.swing.JTextField TEXTPRECIO;
    private javax.swing.JTextField TEXTSTOCK;
    private javax.swing.JTextField TEXTUNIDAD;
    private javax.swing.JTable Tabla;
    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
