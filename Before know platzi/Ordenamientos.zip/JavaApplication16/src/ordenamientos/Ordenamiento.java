package ordenamientos;

import javax.swing.JOptionPane;
import java.lang.Math;
import java.util.Arrays;

public class Ordenamiento {

    public static void main(String[] args) {

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la cantidad de numeros que quiere organizar"));
        int[] arreglo = new int[cantidad];
        int min = Integer.parseInt(JOptionPane.showInputDialog(null, "¿Desde que numero quiere el ordenamiento?"));
        int max = Integer.parseInt(JOptionPane.showInputDialog(null, "¿Hasta que numero quiere el ordenamiento?"));
        int range = max - min + 1;

        for (int i = 0; i < cantidad; i++) {
            int rand = (int) (Math.random() * range) + min; 
            arreglo[i] = rand;
        }
        
        int [] piboteburbuja = arreglo.clone();
        int [] piboteinsercion = arreglo.clone();
        int [] piboteseleccion = arreglo.clone();
        int [] piboteshell = arreglo.clone();
        int [] pibotequick = arreglo.clone();
        
        //Arreglo original
        System.out.println("El arreglo actual es:");
        System.out.println(Arrays.toString(arreglo));

               
        //Burbuja
        bubbleSort(piboteburbuja);
        System.out.println("Metodo Burbuja:");
        System.out.println(Arrays.toString(piboteburbuja));
        
        
        //Insercion
        insertionSort(piboteinsercion);
        System.out.println("Metodo Inserción:");
        System.out.println(Arrays.toString(piboteinsercion));
        
        
        //Seleccion
        selectionSort(piboteseleccion);
        System.out.println("Metodo Selección:");
        System.out.println(Arrays.toString(piboteseleccion));
        
        
        //Shell
        shellSort(piboteshell);
        System.out.println("Metodo Shell:");
        System.out.println(Arrays.toString(piboteshell));
        
        
        //Quick Sort
        quickSort(pibotequick, 0, pibotequick.length - 1);
        System.out.println("Metodo Quick Sort:");
        System.out.println(Arrays.toString(pibotequick));
    }
    
    
    
    public static void bubbleSort(int[] piboteburbuja) {
        int n = piboteburbuja.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (piboteburbuja[j] > piboteburbuja[j + 1]) {
                    int temp = piboteburbuja[j];
                    piboteburbuja[j] = piboteburbuja[j + 1];
                    piboteburbuja[j + 1] = temp;
                }
            }
        }
    }
    
    public static void insertionSort(int[] piboteinsercion) {
        int n = piboteinsercion.length;
        for (int i = 1; i < n; i++) {
            int key = piboteinsercion[i];
            int j = i - 1;
            while (j >= 0 && piboteinsercion[j] > key) {
                piboteinsercion[j + 1] = piboteinsercion[j];
                j = j - 1;
            }
            piboteinsercion[j + 1] = key;
        }
    }
    
    public static void selectionSort(int[] piboteseleccion) {
        int n = piboteseleccion.length;

        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++) {
                if (piboteseleccion[j] < piboteseleccion[minIdx]) {
                    minIdx = j;
                }
            }

            int temp = piboteseleccion[minIdx];
            piboteseleccion[minIdx] = piboteseleccion[i];
            piboteseleccion[i] = temp;
        }
    }
    
    public static void shellSort(int[] piboteshell) {
        int n = piboteshell.length;
        // Determinar el tamaño inicial de los subgrupos
        int gap = n / 2;
        while (gap > 0) {
            // Aplicar el algoritmo de ordenamiento por inserción a cada subgrupo
            for (int i = gap; i < n; i++) {
                int temp = piboteshell[i];
                int j = i;

                while (j >= gap && piboteshell[j - gap] > temp) {
                    piboteshell[j] = piboteshell[j - gap];
                    j -= gap;
                }

                piboteshell[j] = temp;
            }
            // Reducir el tamaño de los subgrupos
            gap /= 2;
        }
    }
    
    
    public static void quickSort(int[] pibotequick, int left, int right) {
        if (left < right) {
            // Seleccionar un pivote aleatorio
            int pivotIndex = left + (int) (Math.random() * (right - left + 1));
            int pivot = pibotequick[pivotIndex];

            // Particionar el array
            int i = left;
            int j = right;

            while (i <= j) {
                while (pibotequick[i] < pivot) {
                    i++;
                }

                while (pibotequick[j] > pivot) {
                    j--;
                }

                if (i <= j) {
                    int temp = pibotequick[i];
                    pibotequick[i] = pibotequick[j];
                    pibotequick[j] = temp;
                    i++;
                    j--;
                }
            }

            // Aplicar quicksort a las dos partes del array
            quickSort(pibotequick, left, j);
            quickSort(pibotequick, i, right);
        }
    }
    

}
